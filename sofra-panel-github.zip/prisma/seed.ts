// Demo verisi: kullanıcılar, salon, menü ve son 14 güne yayılmış ödenmiş siparişler.
// Çalıştırma: npm run db:seed  (yeniden çalıştırılırsa mevcut kayıtları atlar)
import { PrismaClient } from '@prisma/client'
import { hashPassword } from '../src/lib/password'

const db = new PrismaClient()
const PASSWORD = process.env.SEED_PASSWORD ?? 'demo1234'
const kurus = (tl: number) => Math.round(tl * 100)

// Deterministik sözde-rastgele (aynı seed → aynı demo verisi)
let seed = 42
const rand = () => ((seed = (seed * 1664525 + 1013904223) % 4294967296) / 4294967296)
const pick = <T,>(arr: T[]) => arr[Math.floor(rand() * arr.length)]

async function main() {
  if ((await db.user.count()) > 0) {
    console.log('Veritabanı dolu görünüyor; seed atlandı. Sıfırlamak için: npm run db:reset')
    return
  }

  const passwordHash = await hashPassword(PASSWORD)
  await db.user.createMany({
    data: [
      { username: 'admin', name: 'Yönetici', role: 'ADMIN', passwordHash },
      { username: 'kasiyer', name: 'Kasiyer', role: 'CASHIER', passwordHash },
      { username: 'mutfak', name: 'Mutfak', role: 'KITCHEN', passwordHash },
    ],
  })

  // Salon
  const zones = await Promise.all(
    [
      ['Salon', 0, 8],
      ['Bahçe', 1, 6],
      ['Teras', 2, 4],
    ].map(async ([name, sortOrder, count]) => {
      const zone = await db.zone.create({ data: { name: name as string, sortOrder: sortOrder as number } })
      for (let i = 1; i <= (count as number); i++) {
        await db.table.create({ data: { zoneId: zone.id, name: `${(name as string)[0]}${i}`, seats: i % 3 === 0 ? 6 : 4 } })
      }
      return zone
    })
  )
  void zones

  // Tanımlar
  const adet = await db.unit.create({ data: { name: 'Adet' } })
  await db.unit.createMany({ data: [{ name: 'Porsiyon' }, { name: 'Kg' }] })
  const kdv10 = await db.vatRate.create({ data: { rate: 10 } })
  await db.vatRate.createMany({ data: [{ rate: 1 }, { rate: 20 }] })
  const [izgara, soguk, tatli, bar] = await Promise.all(
    ['Izgara', 'Soğuk', 'Tatlı', 'Bar'].map((name) => db.kitchenGroup.create({ data: { name } }))
  )
  await db.discount.createMany({
    data: [
      { name: 'Personel', kind: 'PERCENT', value: 20 },
      { name: 'Öğrenci', kind: 'PERCENT', value: 10 },
      { name: 'İkram', kind: 'PERCENT', value: 100 },
      { name: '50₺ indirim', kind: 'AMOUNT', value: kurus(50) },
    ],
  })
  await db.feature.createMany({
    data: [
      { name: 'Ekstra peynir', price: kurus(15) },
      { name: 'Acısız', price: 0 },
      { name: 'Çift porsiyon', price: kurus(60) },
    ],
  })
  await db.noteTemplate.createMany({
    data: ['Servis notu', 'Paket notu', 'Acısız', 'Az pişmiş', 'Soğansız'].map((name) => ({ name })),
  })
  await db.customer.createMany({
    data: [
      { name: 'Ayşe Yılmaz', phone: '0532 000 00 01', address: 'Örnek Mah. 12. Sk. No:4' },
      { name: 'Mehmet Demir', phone: '0533 000 00 02' },
    ],
  })

  // Menü
  const menu: Record<string, { emoji: string; items: [string, number, number][]; group: string }> = {
    Çorbalar: { emoji: '🍲', group: 'soguk', items: [['Mercimek çorbası', 85, 1], ['Ezogelin çorbası', 85, 2]] },
    'Ana Yemekler': { emoji: '🍽️', group: 'izgara', items: [['Izgara köfte', 260, 1], ['Tavuk şiş', 240, 2], ['Karışık ızgara', 380, 3], ['Adana kebap', 290, 4]] },
    Pideler: { emoji: '🥙', group: 'izgara', items: [['Kaşarlı pide', 190, 1], ['Kuşbaşılı pide', 230, 2]] },
    Salatalar: { emoji: '🥗', group: 'soguk', items: [['Çoban salata', 95, 1], ['Mevsim salata', 110, 2]] },
    İçecekler: { emoji: '🥤', group: 'bar', items: [['Ayran', 35, 1], ['Kola', 50, 2], ['Çay', 20, 3], ['Türk kahvesi', 55, 4], ['Limonata', 65, 5]] },
    Tatlılar: { emoji: '🍰', group: 'tatli', items: [['Künefe', 150, 1], ['Sütlaç', 95, 2], ['Baklava', 170, 3]] },
  }
  const groupId: Record<string, string> = { izgara: izgara.id, soguk: soguk.id, tatli: tatli.id, bar: bar.id }
  let order = 0
  for (const [name, def] of Object.entries(menu)) {
    const cat = await db.category.create({ data: { name, emoji: def.emoji, sortOrder: order++ } })
    for (const [pname, price, sortOrder] of def.items) {
      await db.product.create({
        data: {
          categoryId: cat.id,
          name: pname,
          price: kurus(price),
          sortOrder,
          popular: sortOrder === 1,
          unitId: adet.id,
          vatRateId: kdv10.id,
          kitchenGroupId: groupId[def.group],
        },
      })
    }
  }

  // Geçmiş siparişler (raporlar dolu görünsün)
  const products = await db.product.findMany()
  const tables = await db.table.findMany()
  const admin = await db.user.findUniqueOrThrow({ where: { username: 'kasiyer' } })
  let number = 1
  const now = new Date()
  for (let daysBack = 13; daysBack >= 0; daysBack--) {
    const perDay = 8 + Math.floor(rand() * 10)
    for (let n = 0; n < perDay; n++) {
      const paidAt = new Date(now)
      paidAt.setDate(now.getDate() - daysBack)
      paidAt.setHours(Math.floor(11 + rand() * 12), Math.floor(rand() * 60), 0, 0)
      if (paidAt > now) continue

      const lines = Array.from({ length: 1 + Math.floor(rand() * 4) }, () => ({ product: pick(products), quantity: 1 + Math.floor(rand() * 3) }))
      const subtotal = lines.reduce((s, l) => s + l.product.price * l.quantity, 0)
      const discountTotal = rand() < 0.1 ? Math.round(subtotal * 0.1) : 0
      const table = rand() < 0.8 ? pick(tables) : null
      await db.order.create({
        data: {
          number: number++,
          type: table ? 'TABLE' : pick(['DELIVERY', 'PICKUP'] as const),
          status: 'PAID',
          tableId: table?.id,
          tableName: table?.name,
          guests: table ? 1 + Math.floor(rand() * 5) : null,
          subtotal,
          discountTotal,
          total: subtotal - discountTotal,
          paymentMethod: pick(['CASH', 'CARD', 'CARD'] as const),
          paidAt,
          createdAt: new Date(paidAt.getTime() - 40 * 60_000),
          createdById: admin.id,
          items: { create: lines.map((l) => ({ productId: l.product.id, name: l.product.name, unitPrice: l.product.price, quantity: l.quantity })) },
        },
      })
    }
  }

  await db.expense.createMany({
    data: [
      { title: 'Kira', amount: kurus(25000), group: 'Kira', spentAt: new Date(now.getFullYear(), now.getMonth(), 1, 12) },
      { title: 'Elektrik faturası', amount: kurus(3200), group: 'Fatura', spentAt: new Date(now.getTime() - 3 * 86_400_000) },
      { title: 'Sebze-meyve alımı', amount: kurus(1800), group: 'Malzeme', spentAt: new Date(now.getTime() - 86_400_000) },
    ],
  })
  await db.waste.create({ data: { productName: 'Domates', quantity: 3, cost: kurus(120), reason: 'Bozulma', wastedAt: new Date(now.getTime() - 86_400_000) } })

  console.log(`Seed tamam. Giriş: admin / kasiyer / mutfak — şifre: ${PASSWORD}`)
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(() => db.$disconnect())
