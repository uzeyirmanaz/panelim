'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { api } from '@/lib/api-client'

/** GET isteği + yükleniyor/hata durumu + manuel yenileme. url=null ise istek atılmaz. */
export function useApi<T>(url: string | null) {
  const [data, setData] = useState<T | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(Boolean(url))
  const urlRef = useRef(url)
  urlRef.current = url

  const reload = useCallback(async () => {
    const target = urlRef.current
    if (!target) return
    try {
      const result = await api.get<T>(target)
      if (urlRef.current === target) {
        setData(result)
        setError(null)
      }
    } catch (e) {
      if (urlRef.current === target) setError((e as Error).message)
    } finally {
      if (urlRef.current === target) setLoading(false)
    }
  }, [])

  useEffect(() => {
    setLoading(Boolean(url))
    setData(null)
    void reload()
  }, [url, reload])

  return { data, error, loading, reload, setData }
}
