'use client'

import { useEffect, useState } from 'react'

/** Metinden QR kodu (PNG data URL) üretir; kütüphane yalnızca gerektiğinde yüklenir. */
export function useQr(text: string | null, size = 320) {
  const [url, setUrl] = useState<string | null>(null)
  useEffect(() => {
    let cancelled = false
    if (!text) return setUrl(null)
    import('qrcode')
      .then((m) => m.toDataURL(text, { width: size, margin: 1, errorCorrectionLevel: 'M' }))
      .then((u) => !cancelled && setUrl(u))
      .catch(() => !cancelled && setUrl(null))
    return () => {
      cancelled = true
    }
  }, [text, size])
  return url
}
