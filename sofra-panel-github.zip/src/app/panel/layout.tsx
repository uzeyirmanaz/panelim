import { requirePage } from '@/lib/auth'
import { Shell } from '@/components/panel/shell'

export default async function PanelLayout({ children }: { children: React.ReactNode }) {
  const user = await requirePage()
  return <Shell user={user}>{children}</Shell>
}
