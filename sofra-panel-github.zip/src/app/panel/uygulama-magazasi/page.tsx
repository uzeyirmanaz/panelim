import { requirePage } from '@/lib/auth'
import { Icon } from '@/components/ui/icon'
import { Badge, Card, PageHeader } from '@/components/ui/misc'

export const metadata = { title: 'Uygulama Mağazası' }

const APPS = [
  { name: 'Mutfak Ekranı', icon: 'ChefHat', desc: 'Mutfakta canlı sipariş akışı ve hazırlık durumu.', active: true },
  { name: 'Dijital Menü (QR)', icon: 'QrCode', desc: 'Masalara özel QR kodla menüyü paylaşın.', active: true },
  { name: 'Online rezervasyon', icon: 'CalendarCheck', desc: 'Müşteriler web üzerinden masa ayırtsın.', active: false },
  { name: 'Sadakat programı', icon: 'BadgePercent', desc: 'Puan ve indirimle müşteriyi geri getirin.', active: false },
  { name: 'Stok takibi', icon: 'PackageX', desc: 'Tarif kartı ile otomatik stok düşümü.', active: false },
  { name: 'Çoklu şube', icon: 'Store', desc: 'Tüm şubeleri tek panelden yönetin.', active: false },
  { name: 'Müşteri ekranı', icon: 'LayoutGrid', desc: 'Kasada müşteriye dönük sipariş göstergesi.', active: false },
]

export default async function AppStorePage() {
  await requirePage('defs.read')
  return (
    <>
      <PageHeader title="Uygulama Mağazası" subtitle="İşletmenize özel modüller. Etkin olanlar zaten panelin parçasıdır." />
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {APPS.map((a) => (
          <Card key={a.name} className="flex flex-col gap-3 p-4">
            <div className="flex items-start justify-between">
              <span className="grid size-11 place-items-center rounded-xl bg-brand-50 text-brand-600"><Icon name={a.icon} size={21} /></span>
              {a.active ? <Badge tone="green">Etkin</Badge> : <Badge>Yakında</Badge>}
            </div>
            <div>
              <h3 className="font-semibold">{a.name}</h3>
              <p className="mt-0.5 text-sm text-slate-500">{a.desc}</p>
            </div>
          </Card>
        ))}
      </div>
    </>
  )
}
