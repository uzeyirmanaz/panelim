import { requirePage } from '@/lib/auth'
import { OrdersList } from '@/components/panel/orders-list'

export const metadata = { title: 'Siparişler' }

export default async function OrdersPage() {
  await requirePage('order.write')
  return <OrdersList />
}
