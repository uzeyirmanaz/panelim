'use client'

import { useMemo, useState } from 'react'
import { toast } from 'sonner'
import { api } from '@/lib/api-client'
import { useApi } from '@/hooks/use-api'
import { formatMoney } from '@/lib/format'
import { Input } from '@/components/ui/field'
import { Icon } from '@/components/ui/icon'
import { Card, EmptyState, PageHeader, Spinner } from '@/components/ui/misc'

type Product = { id: string; name: string; price: number; externalCode: string | null; category: { name: string } }

// Her menü ürününe, dış sistemdeki (paket servis platformu, muhasebe vb.) ürün kodu girilir.
export function ProductMapping({ canEdit }: { canEdit: boolean }) {
  const { data, loading, reload } = useApi<Product[]>('/api/r/products')
  const [search, setSearch] = useState('')
  const [drafts, setDrafts] = useState<Record<string, string>>({})

  const rows = useMemo(() => {
    const q = search.trim().toLocaleLowerCase('tr-TR')
    return (data ?? []).filter((p) => !q || p.name.toLocaleLowerCase('tr-TR').includes(q) || (p.externalCode ?? '').toLocaleLowerCase('tr-TR').includes(q))
  }, [data, search])

  async function save(p: Product) {
    const value = (drafts[p.id] ?? p.externalCode ?? '').trim()
    if (value === (p.externalCode ?? '')) return
    try {
      await api.patch(`/api/r/products/${p.id}`, { externalCode: value })
      toast.success(`${p.name}: kod kaydedildi`)
      await reload()
    } catch (e) {
      toast.error((e as Error).message)
    }
  }

  return (
    <>
      <PageHeader
        title="Ürün Eşleştirme Ekranı"
        subtitle={canEdit ? 'Menü ürünlerini dış sistemlerdeki ürün kodlarıyla eşleştirin. Alanı değiştirip dışına tıklayınca kaydedilir.' : 'Yalnızca yönetici kodları düzenleyebilir.'}
        actions={
          <div className="relative">
            <Icon name="Search" size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Ürün veya kod ara…" className="w-56 pl-9" aria-label="Ara" />
          </div>
        }
      />
      <Card className="overflow-x-auto">
        {loading ? (
          <Spinner />
        ) : rows.length === 0 ? (
          <EmptyState icon="Link2" text="Ürün bulunamadı." />
        ) : (
          <table className="w-full text-sm">
            <thead className="border-b border-line bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-500">
              <tr>
                <th className="px-4 py-2.5 font-medium">Ürün</th>
                <th className="px-4 py-2.5 font-medium">Kategori</th>
                <th className="px-4 py-2.5 text-right font-medium">Fiyat</th>
                <th className="w-56 px-4 py-2.5 font-medium">Harici ürün kodu</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {rows.map((p) => (
                <tr key={p.id}>
                  <td className="px-4 py-2 font-medium">{p.name}</td>
                  <td className="px-4 py-2 text-slate-500">{p.category.name}</td>
                  <td className="px-4 py-2 text-right tabular-nums">{formatMoney(p.price)}</td>
                  <td className="px-4 py-1.5">
                    <Input
                      className="h-9"
                      disabled={!canEdit}
                      value={drafts[p.id] ?? p.externalCode ?? ''}
                      onChange={(e) => setDrafts((d) => ({ ...d, [p.id]: e.target.value }))}
                      onBlur={() => void save(p)}
                      placeholder="—"
                      aria-label={`${p.name} harici kodu`}
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>
    </>
  )
}
