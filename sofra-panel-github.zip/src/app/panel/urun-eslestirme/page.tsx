import { requirePage } from '@/lib/auth'
import { can } from '@/lib/permissions'
import { ProductMapping } from './product-mapping'

export const metadata = { title: 'Ürün Eşleştirme Ekranı' }

export default async function ProductMappingPage() {
  const user = await requirePage('defs.read')
  return <ProductMapping canEdit={can(user.role, 'defs.write')} />
}
