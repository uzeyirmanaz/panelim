import { requirePage } from '@/lib/auth'
import { OrderScreen } from '@/components/panel/order-screen'

export const metadata = { title: 'Sipariş' }

type SP = { id?: string; islem?: string }

// /panel/siparis/{masaId}  |  /panel/siparis/paket?id=…  |  /panel/siparis/gelal
export default async function OrderPage({ params, searchParams }: { params: Promise<{ masa: string }>; searchParams: Promise<SP> }) {
  await requirePage('order.write')
  const { masa } = await params
  const { id, islem } = await searchParams
  const type = masa === 'paket' ? 'DELIVERY' : masa === 'gelal' ? 'PICKUP' : undefined
  const dialog = islem === 'ode' ? 'pay' : islem === 'tasi' ? 'move' : undefined
  return <OrderScreen key={`${masa}:${id ?? ''}`} orderId={id} tableId={type ? undefined : masa} type={type} initialDialog={dialog} />
}
