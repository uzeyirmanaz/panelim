'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import { api } from '@/lib/api-client'
import { Button } from '@/components/ui/button'
import { Field, Input } from '@/components/ui/field'
import { Card, PageHeader } from '@/components/ui/misc'

export function ProfileForm({ initialName, username }: { initialName: string; username: string }) {
  const router = useRouter()
  const [name, setName] = useState(initialName)
  const [currentPassword, setCurrent] = useState('')
  const [newPassword, setNew] = useState('')
  const [busy, setBusy] = useState(false)

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    setBusy(true)
    try {
      await api.patch('/api/auth/password', {
        name,
        ...(newPassword ? { currentPassword, newPassword } : {}),
      })
      toast.success('Hesabınız güncellendi')
      setCurrent('')
      setNew('')
      router.refresh()
    } catch (err) {
      toast.error((err as Error).message)
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="max-w-lg">
      <PageHeader title="Hesabım" subtitle={`Kullanıcı adı: ${username}`} />
      <Card className="p-5">
        <form onSubmit={submit} className="space-y-4">
          <Field label="Ad soyad">
            <Input value={name} onChange={(e) => setName(e.target.value)} required />
          </Field>
          <hr className="border-line" />
          <p className="text-sm font-medium text-slate-600">Şifre değiştir</p>
          <Field label="Mevcut şifre">
            <Input type="password" value={currentPassword} onChange={(e) => setCurrent(e.target.value)} autoComplete="current-password" />
          </Field>
          <Field label="Yeni şifre" hint="En az 6 karakter. Boş bırakırsanız şifre değişmez.">
            <Input type="password" value={newPassword} onChange={(e) => setNew(e.target.value)} autoComplete="new-password" />
          </Field>
          <Button type="submit" disabled={busy}>{busy ? 'Kaydediliyor…' : 'Kaydet'}</Button>
        </form>
      </Card>
    </div>
  )
}
