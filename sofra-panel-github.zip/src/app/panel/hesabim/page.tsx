import { requirePage } from '@/lib/auth'
import { ProfileForm } from './profile-form'

export const metadata = { title: 'Hesabım' }

export default async function ProfilePage() {
  const user = await requirePage()
  return <ProfileForm initialName={user.name} username={user.username} />
}
