import { requirePage } from '@/lib/auth'
import { ROLE_LABELS } from '@/lib/constants'
import { CAPABILITIES, can, type Capability } from '@/lib/permissions'
import { Icon } from '@/components/ui/icon'
import { Card, PageHeader } from '@/components/ui/misc'

export const metadata = { title: 'Yetkiler' }

// Tablo lib/permissions.ts'ten üretilir: oradaki değişiklik API, menü, sayfa ve bu ekrana birlikte yansır.
const ROWS = Object.entries(CAPABILITIES) as [Capability, { label: string }][]

const Mark = ({ on }: { on: boolean }) =>
  on ? <Icon name="CheckCircle2" className="mx-auto text-emerald-600" /> : <span className="block text-center text-slate-300">—</span>

export default async function PermissionsPage() {
  await requirePage('users.manage')
  return (
    <>
      <PageHeader title="Yetkiler" subtitle="Rollere göre modül erişimi. Roller sabittir; bir kullanıcının rolünü Kullanıcılar sayfasından değiştirebilirsiniz." />
      <Card className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="border-b border-line bg-slate-50 text-xs uppercase tracking-wide text-slate-500">
            <tr>
              <th className="px-4 py-2.5 text-left font-medium">Yetki</th>
              {(['ADMIN', 'CASHIER', 'KITCHEN'] as const).map((r) => (
                <th key={r} className="w-28 px-4 py-2.5 text-center font-medium">{ROLE_LABELS[r]}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {ROWS.map(([cap, m]) => (
              <tr key={cap}>
                <td className="px-4 py-3">{m.label}</td>
                {(['ADMIN', 'CASHIER', 'KITCHEN'] as const).map((r) => (
                  <td key={r} className="px-4 py-3"><Mark on={can(r, cap)} /></td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </>
  )
}
