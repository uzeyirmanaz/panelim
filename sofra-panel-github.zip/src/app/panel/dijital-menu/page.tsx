import { requirePage } from '@/lib/auth'
import { DigitalMenu } from './digital-menu'

export const metadata = { title: 'Dijital Menü' }

export default async function DigitalMenuPage() {
  await requirePage('defs.read')
  return <DigitalMenu />
}
