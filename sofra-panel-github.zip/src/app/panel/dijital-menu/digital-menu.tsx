'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { toast } from 'sonner'
import { useApi } from '@/hooks/use-api'
import { useQr } from '@/hooks/use-qr'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/field'
import { Icon } from '@/components/ui/icon'
import { Card, PageHeader } from '@/components/ui/misc'
import type { CategoryDTO } from '@/lib/types'

export function DigitalMenu() {
  const menu = useApi<CategoryDTO[]>('/api/menu')
  const [url, setUrl] = useState('')
  useEffect(() => setUrl(`${location.origin}/menu`), [])
  const qr = useQr(url || null)

  const products = (menu.data ?? []).reduce((s, c) => s + c.products.length, 0)

  async function copy() {
    try {
      await navigator.clipboard.writeText(url)
      toast.success('Bağlantı kopyalandı')
    } catch {
      toast.error('Kopyalanamadı; bağlantıyı elle seçip kopyalayın.')
    }
  }

  return (
    <>
      <PageHeader title="Dijital Menü" subtitle="Müşterileriniz QR kodu okutarak güncel menünüzü telefonlarından görsün." />
      <div className="grid gap-4 lg:grid-cols-[320px_1fr]">
        <Card className="grid place-items-center p-6">
          {qr ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={qr} alt="Menü QR kodu" className="size-64" />
          ) : (
            <div className="grid size-64 place-items-center text-sm text-slate-400">QR hazırlanıyor…</div>
          )}
        </Card>
        <Card className="space-y-4 p-5">
          <div>
            <p className="mb-1 text-[13px] font-medium text-slate-600">Menü bağlantısı</p>
            <div className="flex gap-2">
              <Input readOnly value={url} onFocus={(e) => e.currentTarget.select()} aria-label="Menü bağlantısı" />
              <Button variant="secondary" onClick={copy}><Icon name="Copy" size={16} /> Kopyala</Button>
            </div>
          </div>
          <p className="text-sm text-slate-500">
            Menüde şu an <strong>{products}</strong> satışta ürün görünüyor. Ürünleri ve fiyatları <Link href="/panel/menu" className="text-brand-700 underline">Menü / Ürünler</Link> sayfasından yönetirsiniz; değişiklikler anında yansır.
          </p>
          <div className="flex flex-wrap gap-2">
            <a href="/menu" target="_blank" rel="noreferrer" className="inline-flex h-10 items-center gap-2 rounded-lg bg-brand-600 px-4 text-sm font-medium text-white hover:bg-brand-700">
              <Icon name="QrCode" size={16} /> Menüyü aç
            </a>
            <Link href="/panel/ayarlar" className="inline-flex h-10 items-center gap-2 rounded-lg border border-line bg-white px-4 text-sm font-medium hover:bg-slate-50">
              Masaya özel QR kodları
            </Link>
          </div>
        </Card>
      </div>
    </>
  )
}
