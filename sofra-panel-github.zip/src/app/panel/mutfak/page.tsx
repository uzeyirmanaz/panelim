import { requirePage } from '@/lib/auth'
import { can } from '@/lib/permissions'
import { Kitchen } from '@/components/panel/kitchen'

export const metadata = { title: 'Mutfak' }

export default async function KitchenPage() {
  const user = await requirePage('kitchen.view')
  return <Kitchen canServe={can(user.role, 'order.write')} />
}
