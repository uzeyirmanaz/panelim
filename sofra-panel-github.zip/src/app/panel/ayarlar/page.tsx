import { requirePage } from '@/lib/auth'
import { ROLE_LABELS } from '@/lib/constants'
import { Card, PageHeader } from '@/components/ui/misc'
import { TableQrList } from './table-qr-list'

export const metadata = { title: 'Ayarlar' }

export default async function SettingsPage() {
  const user = await requirePage('defs.read')
  return (
    <>
      <PageHeader title="Ayarlar" />
      <div className="space-y-4">
        <Card className="p-5">
          <h2 className="mb-3 text-sm font-semibold">Hesap</h2>
          <dl className="grid gap-3 text-sm sm:grid-cols-3">
            <div><dt className="text-slate-500">Ad</dt><dd className="font-medium">{user.name}</dd></div>
            <div><dt className="text-slate-500">Kullanıcı adı</dt><dd className="font-medium">{user.username}</dd></div>
            <div><dt className="text-slate-500">Rol</dt><dd className="font-medium">{ROLE_LABELS[user.role]}</dd></div>
          </dl>
        </Card>
        <TableQrList />
      </div>
    </>
  )
}
