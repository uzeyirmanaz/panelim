'use client'

import { useEffect, useState } from 'react'
import { useApi } from '@/hooks/use-api'
import { useQr } from '@/hooks/use-qr'
import { Dialog } from '@/components/ui/dialog'
import { Icon } from '@/components/ui/icon'
import { Card, EmptyState, Spinner } from '@/components/ui/misc'

type Table = { id: string; name: string; zone: { name: string } }

export function TableQrList() {
  const tables = useApi<Table[]>('/api/r/tables')
  const [selected, setSelected] = useState<Table | null>(null)
  const [origin, setOrigin] = useState('')
  useEffect(() => setOrigin(location.origin), [])
  const link = selected && origin ? `${origin}/menu?masa=${selected.id}` : null
  const qr = useQr(link, 480)

  return (
    <Card className="p-5">
      <h2 className="mb-1 text-sm font-semibold">Masa QR kodları</h2>
      <p className="mb-4 text-sm text-slate-500">Her masa için ayrı bir QR kodu oluşturun, yazdırıp masaya koyun. Okutan müşteri menüyü masa adıyla görür.</p>
      {tables.loading ? (
        <Spinner />
      ) : (tables.data ?? []).length === 0 ? (
        <EmptyState icon="Armchair" text="Önce masa tanımlayın." />
      ) : (
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-6">
          {tables.data!.map((t) => (
            <button key={t.id} onClick={() => setSelected(t)} className="flex items-center gap-2 rounded-lg border border-line px-3 py-2.5 text-left text-sm hover:border-brand-300 hover:bg-brand-50">
              <Icon name="QrCode" size={16} className="text-slate-400" />
              <span><span className="block font-medium">{t.name}</span><span className="block text-xs text-slate-400">{t.zone.name}</span></span>
            </button>
          ))}
        </div>
      )}

      <Dialog open={Boolean(selected)} onClose={() => setSelected(null)} title={selected ? `${selected.name} · QR kodu` : ''} size="max-w-sm">
        <div className="space-y-3 text-center">
          {qr ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={qr} alt={`${selected?.name} QR kodu`} className="mx-auto size-60" />
          ) : (
            <div className="grid size-60 place-items-center text-sm text-slate-400">Hazırlanıyor…</div>
          )}
          <p className="break-all text-xs text-slate-400">{link}</p>
          {qr && (
            <a href={qr} download={`qr-${selected?.name ?? 'masa'}.png`} className="inline-flex h-9 items-center gap-2 rounded-lg border border-line px-3 text-sm font-medium hover:bg-slate-50">
              <Icon name="Download" size={15} /> PNG indir
            </a>
          )}
        </div>
      </Dialog>
    </Card>
  )
}
