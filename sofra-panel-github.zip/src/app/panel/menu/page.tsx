import { requirePage } from '@/lib/auth'
import { ResourceTabs } from '@/components/panel/resource-page'

export const metadata = { title: 'Menü / Ürünler' }

export default async function MenuPage() {
  const user = await requirePage('defs.read')
  return <ResourceTabs slugs={['urunler', 'kategoriler']} role={user.role} />
}
