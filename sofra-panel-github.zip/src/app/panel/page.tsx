import { requirePage } from '@/lib/auth'
import { Dashboard } from '@/components/panel/dashboard'

export const metadata = { title: 'Ana Sayfa' }

export default async function HomePage() {
  await requirePage('panel.view')
  return <Dashboard />
}
