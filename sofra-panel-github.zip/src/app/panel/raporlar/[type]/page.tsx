import { notFound } from 'next/navigation'
import { requirePage } from '@/lib/auth'
import { REPORT_TITLES, ReportView, type ReportType } from '@/components/panel/report-view'

export async function generateMetadata({ params }: { params: Promise<{ type: string }> }) {
  return { title: REPORT_TITLES[(await params).type as ReportType] }
}

export default async function ReportPage({ params }: { params: Promise<{ type: string }> }) {
  await requirePage('reports.read')
  const { type } = await params
  if (!(type in REPORT_TITLES)) notFound()
  return <ReportView type={type as ReportType} />
}
