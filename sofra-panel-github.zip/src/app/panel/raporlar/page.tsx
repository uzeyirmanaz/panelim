import { redirect } from 'next/navigation'

export default function ReportsIndex() {
  redirect('/panel/raporlar/urun-satis')
}
