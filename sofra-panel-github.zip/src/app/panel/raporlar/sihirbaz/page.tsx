import Link from 'next/link'
import { requirePage } from '@/lib/auth'
import { Icon } from '@/components/ui/icon'
import { Card, PageHeader } from '@/components/ui/misc'

export const metadata = { title: 'Rapor Sihirbazı' }

const QUESTIONS = [
  { q: 'Hangi ürünler ne kadar sattı?', to: '/panel/raporlar/urun-satis', icon: 'LineChart', hint: 'Ürün bazında adet, ciro ve pay' },
  { q: 'Günün kasası tuttu mu?', to: '/panel/raporlar/gun-sonu', icon: 'CalendarCheck', hint: 'Nakit/kart dağılımı, gider ve net sonuç' },
  { q: 'Hangi vardiya daha yoğun?', to: '/panel/raporlar/vardiya', icon: 'Clock', hint: 'Sabah, akşam ve gece vardiyaları' },
  { q: 'Satışlar nereden geliyor?', to: '/panel/raporlar/istatistik', icon: 'BarChart3', hint: 'Sipariş türü, bölge ve saat dağılımı' },
  { q: 'Ne kadar zayi oldu?', to: '/panel/raporlar/fire', icon: 'PackageX', hint: 'Zayi kayıtlarının maliyet özeti' },
  { q: 'Hangi kategori öne çıkıyor?', to: '/panel/raporlar/maliyet', icon: 'TrendingUp', hint: 'Kategori bazında ciro payı' },
]

export default async function ReportWizardPage() {
  await requirePage('reports.read')
  return (
    <>
      <PageHeader title="Rapor Sihirbazı" subtitle="Merak ettiğiniz soruyu seçin, ilgili rapora gidin." />
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        {QUESTIONS.map((x) => (
          <Link key={x.to} href={x.to}>
            <Card className="flex h-full gap-3 p-4 transition-colors hover:border-brand-300">
              <span className="grid size-10 shrink-0 place-items-center rounded-full bg-brand-50 text-brand-600"><Icon name={x.icon} /></span>
              <span>
                <span className="block font-semibold">{x.q}</span>
                <span className="mt-0.5 block text-sm text-slate-500">{x.hint}</span>
              </span>
            </Card>
          </Link>
        ))}
      </div>
    </>
  )
}
