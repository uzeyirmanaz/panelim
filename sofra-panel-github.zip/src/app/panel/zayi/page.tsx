import { requirePage } from '@/lib/auth'
import { ResourcePage } from '@/components/panel/resource-page'

export const metadata = { title: 'Zayi İşlemleri' }

export default async function Page() {
  const user = await requirePage('defs.read')
  return <ResourcePage slug="zayi" role={user.role} />
}
