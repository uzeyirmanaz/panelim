import { requirePage } from '@/lib/auth'
import { Icon } from '@/components/ui/icon'
import { Badge, Card, PageHeader } from '@/components/ui/misc'

export const metadata = { title: 'Entegrasyon İşlemleri' }

// Henüz çalışan entegrasyon yok; kartlar planlanan alanları gösterir ve bağlantı vaat etmez.
const PLANNED = [
  { name: 'Yemek platformları', icon: 'Truck', desc: 'Online yemek siparişlerini adisyon olarak panele alma.' },
  { name: 'Kurye servisi', icon: 'ShoppingBag', desc: 'Paket siparişler için anlık kurye çağırma.' },
  { name: 'e-Fatura / e-Arşiv', icon: 'ReceiptText', desc: 'Kapanan adisyonlardan elektronik belge üretimi.' },
  { name: 'Muhasebe programları', icon: 'Wallet', desc: 'Gün sonu ve gider verisini muhasebe yazılımına aktarma.' },
  { name: 'Fiziksel POS ve yazıcı', icon: 'CreditCard', desc: 'Kart cihazı ve fiş/mutfak yazıcısı bağlantısı.' },
]

export default async function IntegrationsPage() {
  await requirePage('defs.read')
  return (
    <>
      <PageHeader title="Entegrasyon İşlemleri" subtitle="Planlanan bağlantılar. Henüz etkin olanı yok." />
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {PLANNED.map((p) => (
          <Card key={p.name} className="flex flex-col gap-3 p-4">
            <div className="flex items-start justify-between">
              <span className="grid size-11 place-items-center rounded-xl bg-brand-50 text-brand-600"><Icon name={p.icon} size={21} /></span>
              <Badge>Yakında</Badge>
            </div>
            <div>
              <h3 className="font-semibold">{p.name}</h3>
              <p className="mt-0.5 text-sm text-slate-500">{p.desc}</p>
            </div>
          </Card>
        ))}
      </div>
    </>
  )
}
