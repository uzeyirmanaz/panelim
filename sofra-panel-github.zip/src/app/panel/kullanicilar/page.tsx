import { requirePage } from '@/lib/auth'
import { ResourcePage } from '@/components/panel/resource-page'

export const metadata = { title: 'Kullanıcılar' }

export default async function UsersPage() {
  await requirePage('users.manage')
  return <ResourcePage slug="kullanicilar" />
}
