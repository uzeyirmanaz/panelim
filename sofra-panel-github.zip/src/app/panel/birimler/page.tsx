import { requirePage } from '@/lib/auth'
import { ResourcePage } from '@/components/panel/resource-page'

export const metadata = { title: 'Birimler' }

export default async function Page() {
  const user = await requirePage('defs.read')
  return <ResourcePage slug="birimler" role={user.role} />
}
