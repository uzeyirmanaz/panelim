import { requirePage } from '@/lib/auth'
import { Floor } from '@/components/panel/floor'

export const metadata = { title: 'Masalar' }

export default async function FloorPage() {
  await requirePage('order.write')
  return <Floor />
}
