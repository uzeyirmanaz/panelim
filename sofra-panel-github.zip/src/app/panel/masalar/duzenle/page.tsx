import { requirePage } from '@/lib/auth'
import { ResourceTabs } from '@/components/panel/resource-page'

export const metadata = { title: 'Masa / Bölge Tanımları' }

export default async function TableSetupPage() {
  const user = await requirePage('defs.read')
  return <ResourceTabs slugs={['masalar', 'bolgeler']} role={user.role} />
}
