import type { Metadata, Viewport } from 'next'
import { Toaster } from 'sonner'
import './globals.css'

export const metadata: Metadata = {
  title: { default: 'Sofra — Restoran Paneli', template: '%s · Sofra' },
  description: 'Adisyon, masa, mutfak ve raporlama için restoran yönetim paneli.',
}

export const viewport: Viewport = { themeColor: '#c92c2c', width: 'device-width', initialScale: 1 }

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="tr">
      <body>
        {children}
        <Toaster position="top-center" richColors closeButton />
      </body>
    </html>
  )
}
