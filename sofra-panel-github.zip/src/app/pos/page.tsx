import { redirect } from 'next/navigation'

export default function PosRedirect() {
  redirect('/panel')
}
