import { db } from '@/lib/db'
import { formatMoney } from '@/lib/format'

export const dynamic = 'force-dynamic'
export const metadata = { title: 'Menü' }

// Herkese açık, salt okunur dijital menü (QR kodla paylaşılabilir). Sipariş almaz.
export default async function PublicMenuPage({ searchParams }: { searchParams: Promise<{ masa?: string }> }) {
  const { masa } = await searchParams
  const table = masa ? await db.table.findUnique({ where: { id: masa }, select: { name: true } }).catch(() => null) : null
  const categories = await db.category.findMany({
    orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }],
    include: { products: { where: { available: true }, orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }] } },
  })
  const filled = categories.filter((c) => c.products.length > 0)

  return (
    <main className="mx-auto max-w-2xl px-4 py-8">
      <h1 className="mb-1 text-center text-3xl font-semibold tracking-tight">Menü</h1>
      <p className="mb-6 text-center text-sm text-slate-500">{table ? `${table.name} · ` : ''}Fiyatlar güncel menüye göredir</p>
      {filled.length === 0 && <p className="text-center text-slate-500">Menü henüz hazırlanmadı.</p>}
      <nav className="sticky top-0 z-10 -mx-4 mb-6 flex gap-2 overflow-x-auto bg-surface/95 px-4 py-2 backdrop-blur">
        {filled.map((c) => (
          <a key={c.id} href={`#${c.id}`} className="shrink-0 rounded-full bg-white px-3.5 py-1.5 text-sm ring-1 ring-line">
            {c.emoji} {c.name}
          </a>
        ))}
      </nav>
      <div className="space-y-8">
        {filled.map((c) => (
          <section key={c.id} id={c.id} className="scroll-mt-16">
            <h2 className="mb-3 text-lg font-semibold">{c.emoji} {c.name}</h2>
            <ul className="divide-y divide-line rounded-2xl border border-line bg-white">
              {c.products.map((p) => (
                <li key={p.id} className="flex items-start justify-between gap-4 p-4">
                  <div>
                    <p className="font-medium">{p.emoji} {p.name}</p>
                    {p.description && <p className="mt-0.5 text-sm text-slate-500">{p.description}</p>}
                  </div>
                  <span className="shrink-0 font-semibold tabular-nums text-brand-700">{formatMoney(p.price)}</span>
                </li>
              ))}
            </ul>
          </section>
        ))}
      </div>
    </main>
  )
}
