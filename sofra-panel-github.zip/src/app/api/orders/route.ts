import { z } from 'zod'
import type { Prisma } from '@prisma/client'
import { db } from '@/lib/db'
import { requireCan } from '@/lib/auth'
import { handle, readJson } from '@/lib/http'
import { createOrder, orderInclude, toOrderDTO } from '@/lib/orders'
import { OPEN_STATUSES, ORDER_TYPES } from '@/lib/constants'
import { dayEnd, dayStart } from '@/lib/format'

const DAY = /^\d{4}-\d{2}-\d{2}$/

// GET /api/orders?scope=open|kitchen|closed|all &tableId= &from=YYYY-MM-DD &to=YYYY-MM-DD &type=
export const GET = handle(async (req) => {
  await requireCan('kitchen.view')
  const sp = req.nextUrl.searchParams
  const scope = sp.get('scope') ?? 'open'
  const where: Prisma.OrderWhereInput = {}

  if (scope === 'open') where.status = { in: OPEN_STATUSES }
  else if (scope === 'kitchen') where.status = { in: ['NEW', 'PREPARING', 'READY'] }
  else if (scope === 'closed') where.status = { in: ['PAID', 'CANCELLED'] }

  const tableId = sp.get('tableId')
  if (tableId) where.tableId = tableId
  const type = sp.get('type')
  if (type && (ORDER_TYPES as readonly string[]).includes(type)) where.type = type as (typeof ORDER_TYPES)[number]

  const from = sp.get('from')
  const to = sp.get('to')
  if (from && DAY.test(from)) where.createdAt = { gte: dayStart(from), ...(to && DAY.test(to) ? { lte: dayEnd(to) } : {}) }

  const rows = await db.order.findMany({
    where,
    include: orderInclude,
    orderBy: { createdAt: scope === 'kitchen' ? 'asc' : 'desc' },
    take: 300,
  })
  return rows.map(toOrderDTO)
})

const itemSchema = z.object({
  productId: z.string().min(1),
  quantity: z.coerce.number().int().min(1).max(99),
  note: z.string().trim().max(200).nullish(),
})

const createSchema = z.object({
  type: z.enum(ORDER_TYPES),
  tableId: z.string().nullish(),
  customerId: z.string().nullish(),
  customerName: z.string().trim().max(80).nullish(),
  note: z.string().trim().max(300).nullish(),
  guests: z.coerce.number().int().min(1).max(100).nullish(),
  items: z.array(itemSchema).min(1, 'Sepet boş').max(100),
})

export const POST = handle(async (req) => {
  const user = await requireCan('order.write')
  const body = createSchema.parse(await readJson(req))
  return createOrder(body, user.id)
})

