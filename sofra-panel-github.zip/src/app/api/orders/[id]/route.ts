import { z } from 'zod'
import { db } from '@/lib/db'
import { requireCan } from '@/lib/auth'
import { handle, HttpError, readJson } from '@/lib/http'
import { cancelOrder, orderInclude, setStatus, toOrderDTO, updateMeta } from '@/lib/orders'
import { ORDER_STATUSES } from '@/lib/constants'

export const GET = handle<{ id: string }>(async (_req, { params }) => {
  await requireCan('kitchen.view')
  const order = await db.order.findUnique({ where: { id: (await params).id }, include: orderInclude })
  if (!order) throw new HttpError(404, 'Sipariş bulunamadı.')
  return toOrderDTO(order)
})

const patchSchema = z.object({
  status: z.enum(ORDER_STATUSES).optional(),
  note: z.string().trim().max(300).nullish(),
  guests: z.coerce.number().int().min(1).max(100).nullish(),
  customerId: z.string().nullish(),
  customerName: z.string().trim().max(80).nullish(),
  discountTotal: z.coerce.number().int().min(0).max(100_000_000).optional(),
})

export const PATCH = handle<{ id: string }>(async (req, { params }) => {
  const { id } = await params
  const user = await requireCan('kitchen.view')
  const { status, ...meta } = patchSchema.parse(await readJson(req))

  // Mutfak yalnızca hazırlık durumunu ilerletebilir.
  if (user.role === 'KITCHEN') {
    if (Object.keys(meta).length > 0 || !status || !['PREPARING', 'READY'].includes(status)) {
      throw new HttpError(403, 'Mutfak yalnızca "Hazırlanıyor" / "Hazır" durumunu ayarlayabilir.')
    }
  }

  let result
  if (Object.keys(meta).length > 0) result = await updateMeta(id, meta)
  if (status) result = await setStatus(id, status, { kitchenOnly: user.role === 'KITCHEN' })
  if (!result) throw new HttpError(400, 'Güncellenecek alan yok.')
  return result
})

// Adisyonu iptal eder (silmez; raporlarda iz kalır)
export const DELETE = handle<{ id: string }>(async (_req, { params }) => {
  await requireCan('order.write')
  return cancelOrder((await params).id)
})
