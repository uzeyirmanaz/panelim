import { z } from 'zod'
import { requireCan } from '@/lib/auth'
import { handle, readJson } from '@/lib/http'
import { removeItem, updateItem } from '@/lib/orders'

const schema = z.object({
  quantity: z.coerce.number().int().min(0).max(99).optional(),
  note: z.string().trim().max(200).nullish(),
})

export const PATCH = handle<{ id: string; itemId: string }>(async (req, { params }) => {
  await requireCan('order.write')
  const { id, itemId } = await params
  return updateItem(id, itemId, schema.parse(await readJson(req)))
})

export const DELETE = handle<{ id: string; itemId: string }>(async (_req, { params }) => {
  await requireCan('order.write')
  const { id, itemId } = await params
  return removeItem(id, itemId)
})
