import { z } from 'zod'
import { requireCan } from '@/lib/auth'
import { handle, readJson } from '@/lib/http'
import { addItems } from '@/lib/orders'

const schema = z.object({
  items: z
    .array(
      z.object({
        productId: z.string().min(1),
        quantity: z.coerce.number().int().min(1).max(99),
        note: z.string().trim().max(200).nullish(),
      })
    )
    .min(1)
    .max(100),
})

export const POST = handle<{ id: string }>(async (req, { params }) => {
  await requireCan('order.write')
  const { items } = schema.parse(await readJson(req))
  return addItems((await params).id, items)
})
