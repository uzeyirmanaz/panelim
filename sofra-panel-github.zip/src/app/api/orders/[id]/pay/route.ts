import { z } from 'zod'
import { requireCan } from '@/lib/auth'
import { handle, readJson } from '@/lib/http'
import { payOrder } from '@/lib/orders'
import { PAYMENT_METHODS } from '@/lib/constants'

const schema = z.object({
  method: z.enum(PAYMENT_METHODS),
  discountTotal: z.coerce.number().int().min(0).max(100_000_000).optional(),
})

export const POST = handle<{ id: string }>(async (req, { params }) => {
  await requireCan('order.write')
  return payOrder((await params).id, schema.parse(await readJson(req)))
})
