import { z } from 'zod'
import { requireCan } from '@/lib/auth'
import { handle, readJson } from '@/lib/http'
import { moveToTable } from '@/lib/orders'

const schema = z.object({ tableId: z.string().min(1) })

export const POST = handle<{ id: string }>(async (req, { params }) => {
  await requireCan('order.write')
  const { tableId } = schema.parse(await readJson(req))
  return moveToTable((await params).id, tableId)
})
