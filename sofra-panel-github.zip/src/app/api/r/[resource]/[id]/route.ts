import { requireRole } from '@/lib/auth'
import { publish } from '@/lib/events'
import { handle, HttpError, readJson } from '@/lib/http'
import { RESOURCES } from '@/lib/resources'

function resolve(name: string) {
  const def = RESOURCES[name]
  if (!def) throw new HttpError(404, 'Bilinmeyen kaynak.')
  return def
}

export const PATCH = handle<{ resource: string; id: string }>(async (req, { params }) => {
  const { resource, id } = await params
  const def = resolve(resource)
  await requireRole(def.write)
  const data = def.schema.partial().parse(await readJson(req))
  const updated = await def.model.update({ where: { id }, data, include: def.include })
  publish({ type: 'menu' })
  return updated
})

export const DELETE = handle<{ resource: string; id: string }>(async (_req, { params }) => {
  const { resource, id } = await params
  const def = resolve(resource)
  await requireRole(def.write)
  await def.model.delete({ where: { id } })
  publish({ type: 'menu' })
  return { ok: true }
})
