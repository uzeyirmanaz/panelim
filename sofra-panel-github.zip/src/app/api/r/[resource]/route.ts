import { requireCan, requireRole } from '@/lib/auth'
import { publish } from '@/lib/events'
import { handle, HttpError, readJson } from '@/lib/http'
import { RESOURCES } from '@/lib/resources'

function resolve(name: string) {
  const def = RESOURCES[name]
  if (!def) throw new HttpError(404, 'Bilinmeyen kaynak.')
  return def
}

export const GET = handle<{ resource: string }>(async (_req, { params }) => {
  const def = resolve((await params).resource)
  await requireCan('defs.read')
  return def.model.findMany({ orderBy: def.orderBy, include: def.include })
})

export const POST = handle<{ resource: string }>(async (req, { params }) => {
  const def = resolve((await params).resource)
  await requireRole(def.write)
  const data = def.schema.parse(await readJson(req))
  const created = await def.model.create({ data, include: def.include })
  publish({ type: 'menu' })
  return created
})
