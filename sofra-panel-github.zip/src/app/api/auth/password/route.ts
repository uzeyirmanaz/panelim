import { z } from 'zod'
import { db } from '@/lib/db'
import { hashPassword, requireUser, verifyPassword } from '@/lib/auth'
import { handle, HttpError, readJson } from '@/lib/http'

const schema = z.object({
  name: z.string().trim().min(1).max(80).optional(),
  currentPassword: z.string().optional(),
  newPassword: z.string().min(6, 'Şifre en az 6 karakter olmalı').max(100).optional(),
})

// Kendi profilini güncelle: ad ve/veya şifre
export const PATCH = handle(async (req) => {
  const me = await requireUser()
  const body = schema.parse(await readJson(req))
  const data: { name?: string; passwordHash?: string } = {}
  if (body.name) data.name = body.name

  if (body.newPassword) {
    const user = await db.user.findUniqueOrThrow({ where: { id: me.id } })
    if (!body.currentPassword || !(await verifyPassword(body.currentPassword, user.passwordHash))) {
      throw new HttpError(400, 'Mevcut şifre hatalı.')
    }
    data.passwordHash = await hashPassword(body.newPassword)
  }

  await db.user.update({ where: { id: me.id }, data })
  return { ok: true }
})
