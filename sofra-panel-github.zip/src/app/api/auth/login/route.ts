import { z } from 'zod'
import { db } from '@/lib/db'
import { createSession, verifyPassword } from '@/lib/auth'
import { handle, HttpError, readJson } from '@/lib/http'

const schema = z.object({ username: z.string().trim().min(1), password: z.string().min(1) })

// Kaba kuvvet koruması: kullanıcı+IP başına 10 dakikada en fazla 8 başarısız deneme (süreç içi).
const attempts = new Map<string, { count: number; reset: number }>()
const WINDOW = 10 * 60_000
const MAX_FAILS = 8

export const POST = handle(async (req) => {
  const { username, password } = schema.parse(await readJson(req))
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ?? 'local'
  const key = `${ip}:${username.toLowerCase()}`
  const now = Date.now()
  const entry = attempts.get(key)
  if (entry && entry.reset > now && entry.count >= MAX_FAILS) {
    throw new HttpError(429, 'Çok fazla başarısız deneme. Birkaç dakika sonra tekrar deneyin.')
  }

  const user = await db.user.findUnique({ where: { username: username.toLowerCase() } })
  const ok = user ? await verifyPassword(password, user.passwordHash) : false
  if (!user || !ok || !user.active) {
    const cur = entry && entry.reset > now ? entry : { count: 0, reset: now + WINDOW }
    attempts.set(key, { count: cur.count + 1, reset: cur.reset })
    throw new HttpError(401, 'Kullanıcı adı veya şifre hatalı.')
  }

  attempts.delete(key)
  await createSession(user.id, req.headers.get('user-agent'))
  return { id: user.id, name: user.name, role: user.role }
})
