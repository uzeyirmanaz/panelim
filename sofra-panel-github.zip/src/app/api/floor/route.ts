import { db } from '@/lib/db'
import { requireCan } from '@/lib/auth'
import { handle } from '@/lib/http'
import { OPEN_STATUSES } from '@/lib/constants'
import type { FloorZoneDTO } from '@/lib/types'

// Salon görünümü: bölgeler → masalar (+ varsa açık adisyon özeti)
export const GET = handle(async () => {
  await requireCan('panel.view')
  const [zones, open] = await Promise.all([
    db.zone.findMany({
      orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }],
      include: { tables: { orderBy: { name: 'asc' } } },
    }),
    db.order.findMany({
      where: { type: 'TABLE', status: { in: OPEN_STATUSES } },
      select: { id: true, tableId: true, status: true, total: true, createdAt: true, updatedAt: true, _count: { select: { items: true } } },
    }),
  ])
  const byTable = new Map(open.map((o) => [o.tableId, o]))
  const data: FloorZoneDTO[] = zones.map((z) => ({
    id: z.id,
    name: z.name,
    tables: z.tables.map((t) => {
      const o = byTable.get(t.id)
      return {
        id: t.id,
        name: t.name,
        seats: t.seats,
        order: o
          ? { id: o.id, status: o.status, total: o.total, itemCount: o._count.items, createdAt: o.createdAt.toISOString(), updatedAt: o.updatedAt.toISOString() }
          : null,
      }
    }),
  }))
  return data
})
