import { db } from '@/lib/db'
import { requireCan } from '@/lib/auth'
import { handle, HttpError } from '@/lib/http'
import { dayEnd, dayKey, dayStart, todayKey } from '@/lib/format'

const DAY = /^\d{4}-\d{2}-\d{2}$/
const MAX_DAYS = 366
const SHIFTS = [
  { name: '08:00 – 16:00', from: 8, to: 16 },
  { name: '16:00 – 00:00', from: 16, to: 24 },
  { name: '00:00 – 08:00', from: 0, to: 8 },
]

// GET /api/reports/{urun-satis|gun-sonu|vardiya|istatistik|fire|maliyet}?from=YYYY-MM-DD&to=YYYY-MM-DD
// Satış raporları "ödeme zamanına" (paidAt) göre kapanmış adisyonları kullanır.
export const GET = handle<{ type: string }>(async (req, { params }) => {
  await requireCan('reports.read')
  const { type } = await params
  const sp = req.nextUrl.searchParams
  const fromKey = sp.get('from') && DAY.test(sp.get('from')!) ? sp.get('from')! : todayKey()
  const toKey = sp.get('to') && DAY.test(sp.get('to')!) ? sp.get('to')! : fromKey
  const from = dayStart(fromKey)
  const to = dayEnd(toKey)
  if (to < from) throw new HttpError(400, 'Bitiş tarihi başlangıçtan önce olamaz.')
  if ((to.getTime() - from.getTime()) / 86_400_000 > MAX_DAYS) throw new HttpError(400, 'En fazla 1 yıllık aralık seçilebilir.')

  // Fire raporu satış verisi kullanmaz
  if (type === 'fire') {
    const wastes = await db.waste.findMany({ where: { wastedAt: { gte: from, lte: to } }, orderBy: { wastedAt: 'desc' } })
    const byName = new Map<string, { count: number; quantity: number; cost: number }>()
    for (const w of wastes) {
      const cur = byName.get(w.productName) ?? { count: 0, quantity: 0, cost: 0 }
      cur.count += 1
      cur.quantity += w.quantity
      cur.cost += w.cost
      byName.set(w.productName, cur)
    }
    return {
      rows: [...byName.entries()].map(([name, v]) => ({ name, ...v })).sort((a, b) => b.cost - a.cost),
      totalCost: wastes.reduce((s, w) => s + w.cost, 0),
      totalQuantity: wastes.reduce((s, w) => s + w.quantity, 0),
      recordCount: wastes.length,
    }
  }

  const orders = await db.order.findMany({
    where: { status: 'PAID', paidAt: { gte: from, lte: to } },
    select: {
      type: true,
      total: true,
      discountTotal: true,
      paymentMethod: true,
      paidAt: true,
      table: { select: { zone: { select: { name: true } } } },
      items: {
        select: {
          name: true,
          unitPrice: true,
          quantity: true,
          product: { select: { category: { select: { name: true } } } },
        },
      },
    },
    orderBy: { paidAt: 'asc' },
  })
  const totalRevenue = orders.reduce((s, o) => s + o.total, 0)

  switch (type) {
    case 'urun-satis': {
      const map = new Map<string, { category: string; quantity: number; revenue: number }>()
      for (const o of orders)
        for (const i of o.items) {
          const cur = map.get(i.name) ?? { category: i.product?.category.name ?? 'Diğer', quantity: 0, revenue: 0 }
          cur.quantity += i.quantity
          cur.revenue += i.unitPrice * i.quantity
          map.set(i.name, cur)
        }
      const rows = [...map.entries()].map(([name, v]) => ({ name, ...v })).sort((a, b) => b.revenue - a.revenue)
      return {
        rows,
        totalRevenue: rows.reduce((s, r) => s + r.revenue, 0),
        totalQuantity: rows.reduce((s, r) => s + r.quantity, 0),
        orderCount: orders.length,
      }
    }

    case 'maliyet': {
      // Ürün maliyeti tutulmadığı için kategori bazında ciro payı gösterilir.
      const map = new Map<string, { quantity: number; revenue: number }>()
      for (const o of orders)
        for (const i of o.items) {
          const name = i.product?.category.name ?? 'Diğer'
          const cur = map.get(name) ?? { quantity: 0, revenue: 0 }
          cur.quantity += i.quantity
          cur.revenue += i.unitPrice * i.quantity
          map.set(name, cur)
        }
      const rows = [...map.entries()].map(([name, v]) => ({ name, ...v })).sort((a, b) => b.revenue - a.revenue)
      return { rows, totalRevenue: rows.reduce((s, r) => s + r.revenue, 0), orderCount: orders.length }
    }

    case 'vardiya': {
      const rows = SHIFTS.map((s) => ({ name: s.name, revenue: 0, orders: 0 }))
      for (const o of orders) {
        const h = o.paidAt!.getHours()
        const idx = SHIFTS.findIndex((s) => h >= s.from && h < s.to)
        rows[idx].revenue += o.total
        rows[idx].orders += 1
      }
      return { rows, totalRevenue, orderCount: orders.length }
    }

    case 'istatistik': {
      const byType = {
        TABLE: { orders: 0, revenue: 0 },
        DELIVERY: { orders: 0, revenue: 0 },
        PICKUP: { orders: 0, revenue: 0 },
      }
      const zones = new Map<string, number>()
      const hours = Array.from({ length: 24 }, (_, hour) => ({ hour, orders: 0, revenue: 0 }))
      for (const o of orders) {
        byType[o.type].orders += 1
        byType[o.type].revenue += o.total
        const zone = o.table?.zone.name ?? 'Paket / Gel-Al'
        zones.set(zone, (zones.get(zone) ?? 0) + o.total)
        const h = hours[o.paidAt!.getHours()]
        h.orders += 1
        h.revenue += o.total
      }
      return {
        totalRevenue,
        orderCount: orders.length,
        average: orders.length ? Math.round(totalRevenue / orders.length) : 0,
        byType,
        byZone: [...zones.entries()].map(([zone, revenue]) => ({ zone, revenue })).sort((a, b) => b.revenue - a.revenue),
        hours,
        busiestHour: orders.length ? hours.reduce((a, b) => (b.revenue > a.revenue ? b : a)).hour : null,
      }
    }

    case 'gun-sonu': {
      type Day = { date: string; orders: number; revenue: number; discount: number; cash: number; card: number; other: number; expenses: number }
      const days = new Map<string, Day>()
      const get = (key: string): Day => {
        let d = days.get(key)
        if (!d) days.set(key, (d = { date: key, orders: 0, revenue: 0, discount: 0, cash: 0, card: 0, other: 0, expenses: 0 }))
        return d
      }
      for (const o of orders) {
        const d = get(dayKey(o.paidAt!))
        d.orders += 1
        d.revenue += o.total
        d.discount += o.discountTotal
        if (o.paymentMethod === 'CASH') d.cash += o.total
        else if (o.paymentMethod === 'CARD') d.card += o.total
        else d.other += o.total
      }
      const [expenses, wastes] = await Promise.all([
        db.expense.findMany({ where: { spentAt: { gte: from, lte: to } }, select: { amount: true, spentAt: true } }),
        db.waste.aggregate({ where: { wastedAt: { gte: from, lte: to } }, _sum: { cost: true } }),
      ])
      for (const e of expenses) get(dayKey(e.spentAt)).expenses += e.amount

      const rows = [...days.values()].sort((a, b) => b.date.localeCompare(a.date))
      const sum = (k: keyof Day) => rows.reduce((s, r) => s + (r[k] as number), 0)
      const wasteCost = wastes._sum.cost ?? 0
      return {
        rows,
        totals: {
          orders: sum('orders'),
          revenue: sum('revenue'),
          discount: sum('discount'),
          cash: sum('cash'),
          card: sum('card'),
          other: sum('other'),
          expenses: sum('expenses'),
          wasteCost,
          net: sum('revenue') - sum('expenses') - wasteCost,
        },
      }
    }

    default:
      throw new HttpError(404, 'Bilinmeyen rapor türü.')
  }
})
