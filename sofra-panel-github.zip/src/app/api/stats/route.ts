import { db } from '@/lib/db'
import { requireCan } from '@/lib/auth'
import { handle } from '@/lib/http'
import { OPEN_STATUSES } from '@/lib/constants'
import { dayKey } from '@/lib/format'

// Ana sayfa özeti: bugün, son 7 gün, açık adisyonlar, en çok satanlar
export const GET = handle(async () => {
  await requireCan('panel.view')
  const now = new Date()
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate())
  const weekStart = new Date(today)
  weekStart.setDate(weekStart.getDate() - 6)

  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1)
  const [paid, open, tableCount, productCount, categoryCount, userCount, month] = await Promise.all([
    db.order.findMany({
      where: { status: 'PAID', paidAt: { gte: weekStart } },
      select: { total: true, paidAt: true, items: { select: { name: true, unitPrice: true, quantity: true } } },
    }),
    db.order.aggregate({ where: { status: { in: OPEN_STATUSES } }, _sum: { total: true }, _count: true }),
    db.table.count(),
    db.product.count(),
    db.category.count(),
    db.user.count(),
    db.order.aggregate({ where: { status: 'PAID', paidAt: { gte: monthStart } }, _sum: { total: true } }),
  ])

  const days = new Map<string, { revenue: number; orders: number }>()
  for (let i = 0; i < 7; i++) {
    const d = new Date(weekStart)
    d.setDate(d.getDate() + i)
    days.set(dayKey(d), { revenue: 0, orders: 0 })
  }
  const hours = Array.from({ length: 24 }, () => 0)
  const products = new Map<string, { quantity: number; revenue: number }>()
  let todayRevenue = 0
  let todayOrders = 0

  for (const o of paid) {
    const at = o.paidAt!
    const day = days.get(dayKey(at))
    if (day) {
      day.revenue += o.total
      day.orders += 1
    }
    if (at >= today) {
      todayRevenue += o.total
      todayOrders += 1
      hours[at.getHours()] += o.total
    }
    for (const i of o.items) {
      const p = products.get(i.name) ?? { quantity: 0, revenue: 0 }
      p.quantity += i.quantity
      p.revenue += i.unitPrice * i.quantity
      products.set(i.name, p)
    }
  }

  return {
    today: { revenue: todayRevenue, orders: todayOrders, average: todayOrders ? Math.round(todayRevenue / todayOrders) : 0 },
    open: { count: open._count, total: open._sum.total ?? 0 },
    tableCount,
    productCount,
    categoryCount,
    userCount,
    monthRevenue: month._sum.total ?? 0,
    week: [...days.entries()].map(([date, v]) => ({ date, ...v })),
    hours,
    topProducts: [...products.entries()]
      .map(([name, v]) => ({ name, ...v }))
      .sort((a, b) => b.quantity - a.quantity)
      .slice(0, 6),
  }
})
