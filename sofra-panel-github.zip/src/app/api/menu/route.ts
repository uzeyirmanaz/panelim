import { db } from '@/lib/db'
import { requireUser } from '@/lib/auth'
import { handle } from '@/lib/http'
import type { CategoryDTO } from '@/lib/types'

// Sipariş ekranı için kategori + satıştaki ürünler
export const GET = handle(async () => {
  await requireUser()
  const categories = await db.category.findMany({
    orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }],
    include: {
      products: { where: { available: true }, orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }] },
    },
  })
  const data: CategoryDTO[] = categories
    .filter((c) => c.products.length > 0)
    .map((c) => ({
      id: c.id,
      name: c.name,
      emoji: c.emoji,
      products: c.products.map((p) => ({
        id: p.id,
        categoryId: p.categoryId,
        name: p.name,
        description: p.description,
        price: p.price,
        emoji: p.emoji,
        available: p.available,
        popular: p.popular,
      })),
    }))
  return data
})
