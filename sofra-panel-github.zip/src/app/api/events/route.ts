import { requireUser } from '@/lib/auth'
import { subscribe } from '@/lib/events'
import { handle } from '@/lib/http'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'

// Server-Sent Events: sipariş/masa/menü değişikliklerini bağlı ekranlara iletir.
export const GET = handle(async (req) => {
  await requireUser()
  const encoder = new TextEncoder()
  let cleanup = () => {}

  const stream = new ReadableStream({
    start(controller) {
      const send = (chunk: string) => {
        try {
          controller.enqueue(encoder.encode(chunk))
        } catch {
          cleanup()
        }
      }
      send('retry: 3000\n\n')
      const unsubscribe = subscribe((e) => send(`data: ${JSON.stringify(e)}\n\n`))
      const ping = setInterval(() => send(': ping\n\n'), 25_000)
      cleanup = () => {
        clearInterval(ping)
        unsubscribe()
        try {
          controller.close()
        } catch {
          /* zaten kapalı */
        }
      }
      req.signal.addEventListener('abort', cleanup)
    },
    cancel() {
      cleanup()
    },
  })

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
      'X-Accel-Buffering': 'no',
    },
  })
})
