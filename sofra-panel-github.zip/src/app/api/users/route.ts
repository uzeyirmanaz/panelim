import { z } from 'zod'
import { db } from '@/lib/db'
import { hashPassword, requireCan } from '@/lib/auth'
import { userSelect } from '@/lib/user-select'
import { handle, readJson } from '@/lib/http'
import { ROLES } from '@/lib/constants'

export const GET = handle(async () => {
  await requireCan('users.manage')
  return db.user.findMany({ select: userSelect, orderBy: { createdAt: 'asc' } })
})

const createSchema = z.object({
  username: z
    .string()
    .trim()
    .toLowerCase()
    .regex(/^[a-z0-9._-]{3,32}$/, 'Kullanıcı adı 3-32 karakter; harf, rakam, . _ - kullanılabilir'),
  name: z.string().trim().min(1).max(80),
  password: z.string().min(6, 'Şifre en az 6 karakter olmalı').max(100),
  role: z.enum(ROLES),
  active: z.boolean().default(true),
})

export const POST = handle(async (req) => {
  await requireCan('users.manage')
  const body = createSchema.parse(await readJson(req))
  const { password, ...rest } = body
  return db.user.create({ data: { ...rest, passwordHash: await hashPassword(password) }, select: userSelect })
})
