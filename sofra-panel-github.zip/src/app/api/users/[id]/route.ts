import { z } from 'zod'
import { db } from '@/lib/db'
import { hashPassword, requireCan } from '@/lib/auth'
import { handle, HttpError, readJson } from '@/lib/http'
import { ROLES } from '@/lib/constants'
import { userSelect } from '@/lib/user-select'

const patchSchema = z.object({
  name: z.string().trim().min(1).max(80).optional(),
  role: z.enum(ROLES).optional(),
  active: z.boolean().optional(),
  password: z.string().min(6, 'Şifre en az 6 karakter olmalı').max(100).optional().or(z.literal('')),
})

async function assertNotLastAdmin(id: string) {
  const target = await db.user.findUnique({ where: { id } })
  if (target?.role !== 'ADMIN' || !target.active) return
  const others = await db.user.count({ where: { role: 'ADMIN', active: true, id: { not: id } } })
  if (others === 0) throw new HttpError(409, 'Son aktif yönetici değiştirilemez veya silinemez.')
}

export const PATCH = handle<{ id: string }>(async (req, { params }) => {
  const me = await requireCan('users.manage')
  const { id } = await params
  const { password, ...body } = patchSchema.parse(await readJson(req))

  if (id === me.id && body.active === false) throw new HttpError(409, 'Kendi hesabınızı pasifleştiremezsiniz.')
  if ((body.role && body.role !== 'ADMIN') || body.active === false) await assertNotLastAdmin(id)

  const user = await db.user.update({
    where: { id },
    data: { ...body, ...(password ? { passwordHash: await hashPassword(password) } : {}) },
    select: userSelect,
  })
  // Şifre/aktiflik/rol değişince açık oturumları düşür (kendi oturumu hariç)
  if (password || body.active === false) {
    await db.session.deleteMany({ where: { userId: id } })
  }
  return user
})

export const DELETE = handle<{ id: string }>(async (_req, { params }) => {
  const me = await requireCan('users.manage')
  const { id } = await params
  if (id === me.id) throw new HttpError(409, 'Kendi hesabınızı silemezsiniz.')
  await assertNotLastAdmin(id)
  await db.user.delete({ where: { id } })
  return { ok: true }
})
