'use client'

import Link from 'next/link'
import { useApi } from '@/hooks/use-api'
import { formatMoney, formatNumber } from '@/lib/format'
import { Icon } from '@/components/ui/icon'
import { Bar, Card, PageHeader, Spinner } from '@/components/ui/misc'
import { useLive } from './live-provider'

type Stats = {
  today: { revenue: number; orders: number; average: number }
  open: { count: number; total: number }
  tableCount: number
  productCount: number
  week: { date: string; revenue: number; orders: number }[]
  hours: number[]
  topProducts: { name: string; quantity: number; revenue: number }[]
}

function Kpi({ label, value, sub, icon }: { label: string; value: string; sub?: string; icon: string }) {
  return (
    <Card className="flex items-start justify-between p-4">
      <div>
        <p className="text-[13px] text-slate-500">{label}</p>
        <p className="mt-1 text-2xl font-semibold tabular-nums tracking-tight">{value}</p>
        {sub && <p className="mt-0.5 text-xs text-slate-400">{sub}</p>}
      </div>
      <span className="grid size-9 place-items-center rounded-lg bg-brand-50 text-brand-600">
        <Icon name={icon} />
      </span>
    </Card>
  )
}

export function Dashboard() {
  const { data, loading, reload } = useApi<Stats>('/api/stats')
  useLive((e) => (e === null || e.type === 'orders') && void reload())

  if (loading || !data) return <Spinner />

  const weekMax = Math.max(...data.week.map((d) => d.revenue), 1)
  const hourMax = Math.max(...data.hours, 1)
  const topMax = Math.max(...data.topProducts.map((p) => p.quantity), 1)
  const dayLabel = (iso: string) => new Date(`${iso}T12:00:00`).toLocaleDateString('tr-TR', { weekday: 'short' })

  return (
    <>
      <PageHeader title="Ana Sayfa" subtitle="Bugünün özeti" />

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi label="Bugünkü ciro" value={formatMoney(data.today.revenue)} sub={`${formatNumber(data.today.orders)} kapanan adisyon`} icon="Banknote" />
        <Kpi label="Ortalama adisyon" value={formatMoney(data.today.average)} icon="ReceiptText" />
        <Kpi label="Açık adisyonlar" value={formatNumber(data.open.count)} sub={`${formatMoney(data.open.total)} bekleyen`} icon="LayoutGrid" />
        <Kpi label="Menü" value={`${formatNumber(data.productCount)} ürün`} sub={`${formatNumber(data.tableCount)} masa`} icon="UtensilsCrossed" />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Card className="p-4 lg:col-span-2">
          <h2 className="mb-4 text-sm font-semibold">Son 7 gün ciro</h2>
          <div className="flex h-44 items-end gap-2">
            {data.week.map((d) => (
              <div key={d.date} className="flex flex-1 flex-col items-center gap-1.5" title={`${d.date}: ${formatMoney(d.revenue)} · ${d.orders} adisyon`}>
                <span className="text-[11px] tabular-nums text-slate-400">{d.revenue > 0 ? formatNumber(Math.round(d.revenue / 100)) : ''}</span>
                <div className="flex w-full flex-1 items-end">
                  <div className="w-full rounded-t-md bg-brand-500/90" style={{ height: `${Math.max(d.revenue > 0 ? 4 : 0, (d.revenue / weekMax) * 100)}%` }} />
                </div>
                <span className="text-xs text-slate-500">{dayLabel(d.date)}</span>
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-4">
          <h2 className="mb-3 text-sm font-semibold">En çok satanlar (7 gün)</h2>
          {data.topProducts.length === 0 ? (
            <p className="py-6 text-center text-sm text-slate-400">Henüz satış yok.</p>
          ) : (
            <ul className="space-y-3">
              {data.topProducts.map((p) => (
                <li key={p.name}>
                  <div className="mb-1 flex justify-between text-sm">
                    <span className="truncate font-medium">{p.name}</span>
                    <span className="ml-2 tabular-nums text-slate-500">{p.quantity}×</span>
                  </div>
                  <Bar value={p.quantity} max={topMax} />
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card className="p-4 lg:col-span-3">
          <h2 className="mb-3 text-sm font-semibold">Bugün saatlik satış</h2>
          <div className="flex h-24 items-end gap-1">
            {data.hours.map((v, h) => (
              <div key={h} className="flex flex-1 flex-col items-center gap-1" title={`${String(h).padStart(2, '0')}:00 — ${formatMoney(v)}`}>
                <div className="flex w-full flex-1 items-end">
                  <div className="w-full rounded-t bg-brand-400/80" style={{ height: `${v > 0 ? Math.max(6, (v / hourMax) * 100) : 0}%` }} />
                </div>
                <span className="text-[10px] text-slate-400">{h % 3 === 0 ? h : ''}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="mt-5 flex flex-wrap gap-2">
        <Link href="/panel/masalar" className="inline-flex h-10 items-center gap-2 rounded-lg bg-brand-600 px-4 text-sm font-medium text-white hover:bg-brand-700">
          <Icon name="LayoutGrid" size={16} /> Masalara git
        </Link>
      </div>
    </>
  )
}
