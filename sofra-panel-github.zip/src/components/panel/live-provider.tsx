'use client'

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react'
import type { LiveEvent } from '@/lib/types'

type Listener = (e: LiveEvent | null) => void
type Ctx = { connected: boolean; subscribe: (l: Listener) => () => void }

const LiveContext = createContext<Ctx>({ connected: false, subscribe: () => () => {} })

/**
 * Sekme başına tek bir SSE bağlantısı açar; sayfalar useLive() ile dinler.
 * (Tarayıcıların origin başına bağlantı sınırı nedeniyle sayfa başına ayrı bağlantı açılmaz.)
 * Dinleyiciye `null` gelirse "bağlantı (yeniden) kuruldu, verileri yenile" demektir.
 */
export function LiveProvider({ children }: { children: ReactNode }) {
  const [connected, setConnected] = useState(false)
  const listeners = useRef(new Set<Listener>())

  useEffect(() => {
    const source = new EventSource('/api/events')
    const fire = (e: LiveEvent | null) => listeners.current.forEach((l) => l(e))
    source.onopen = () => {
      setConnected(true)
      fire(null)
    }
    source.onerror = () => setConnected(false)
    source.onmessage = (m) => {
      try {
        fire(JSON.parse(m.data) as LiveEvent)
      } catch {
        /* geçersiz mesajı yok say */
      }
    }
    return () => source.close()
  }, [])

  const subscribe = useCallback((l: Listener) => {
    listeners.current.add(l)
    return () => {
      listeners.current.delete(l)
    }
  }, [])

  const value = useMemo(() => ({ connected, subscribe }), [connected, subscribe])
  return <LiveContext.Provider value={value}>{children}</LiveContext.Provider>
}

export function useLive(onEvent: Listener) {
  const { subscribe } = useContext(LiveContext)
  const ref = useRef(onEvent)
  ref.current = onEvent
  useEffect(() => subscribe((e) => ref.current(e)), [subscribe])
}

export const useLiveStatus = () => useContext(LiveContext).connected
