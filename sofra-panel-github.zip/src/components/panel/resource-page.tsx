'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import { toast } from 'sonner'
import { api } from '@/lib/api-client'
import { can } from '@/lib/permissions'
import { moneyToInput, parseMoney } from '@/lib/format'
import { findResourceUI, type FieldDef, type FieldType, type ResourceUI, type Row } from '@/lib/resource-ui'
import { Button } from '@/components/ui/button'
import { Dialog } from '@/components/ui/dialog'
import { Checkbox, Field, Input, Select, Textarea } from '@/components/ui/field'
import { Icon } from '@/components/ui/icon'
import { Card, EmptyState, PageHeader, Spinner } from '@/components/ui/misc'

type Form = Record<string, string | boolean>
type Options = Record<string, { value: string; label: string }[]>

const todayInput = () => {
  const d = new Date()
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
}

const typeOf = (f: FieldDef, form: Form): FieldType => f.typeFrom?.(form) ?? f.type ?? 'text'

/** Satırdaki (veya yeni kayıt için varsayılan) değerleri form metinlerine çevirir */
function rowToForm(ui: ResourceUI, row: Row | null): Form {
  const form: Form = {}
  // Dinamik türler (typeFrom) diğer alanlara bağlı olduğundan önce ham değerler okunur
  for (const f of ui.fields) {
    const raw = row ? row[f.key] : f.defaultValue
    const type = f.type ?? 'text'
    if (type === 'checkbox') form[f.key] = Boolean(raw)
    else if (type === 'password') form[f.key] = ''
    else if (type === 'date') form[f.key] = raw ? localDateInput(String(raw)) : todayInput()
    else form[f.key] = raw === null || raw === undefined ? '' : String(raw)
  }
  // Para alanları: kuruş → "12,50"
  if (row) {
    for (const f of ui.fields) {
      if (typeOf(f, form) === 'money' && typeof row[f.key] === 'number') form[f.key] = moneyToInput(row[f.key])
    }
  }
  return form
}

function localDateInput(iso: string) {
  const d = new Date(iso)
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
}

/** Form metinlerini API gövdesine çevirir; geçersiz alan için hata fırlatır */
function formToPayload(ui: ResourceUI, form: Form, editing: boolean): Record<string, unknown> {
  const body: Record<string, unknown> = {}
  for (const f of ui.fields) {
    if (f.only === 'create' && editing) continue
    if (f.only === 'edit' && !editing) continue
    const type = typeOf(f, form)
    const raw = form[f.key]
    switch (type) {
      case 'checkbox':
        body[f.key] = Boolean(raw)
        break
      case 'money': {
        const kurus = parseMoney(String(raw))
        if (kurus === null) throw new Error(`"${f.label}" geçerli bir tutar olmalı`)
        body[f.key] = kurus
        break
      }
      case 'number': {
        const n = Number(String(raw).replace(',', '.'))
        if (!Number.isFinite(n)) throw new Error(`"${f.label}" sayı olmalı`)
        body[f.key] = n
        break
      }
      case 'date':
        // Yerel öğlen: saat dilimi kayması gün değiştirmesin
        body[f.key] = new Date(`${String(raw) || todayInput()}T12:00:00`).toISOString()
        break
      case 'password':
        if (!String(raw) && (editing || f.skipEmptyOnEdit)) continue
        body[f.key] = String(raw)
        break
      default:
        body[f.key] = String(raw)
    }
  }
  return body
}

const flatten = (v: unknown): string => {
  if (v === null || v === undefined) return ''
  if (typeof v === 'string' || typeof v === 'number') return String(v)
  if (typeof v === 'object') return Object.entries(v as Row).filter(([k]) => k !== 'id').map(([, x]) => flatten(x)).join(' ')
  return ''
}

type Role = import('@/lib/constants').Role

/** role: oturumdaki kullanıcının rolü; yazma yetkisi yoksa ekle/düzenle/sil düğmeleri gizlenir. */
export function ResourcePage({ slug, role = 'ADMIN' }: { slug: string; role?: Role }) {
  const ui = findResourceUI(slug)
  if (!ui) return <EmptyState text="Sayfa bulunamadı." />
  const canWrite = can(role, ui.staffWrite ? 'staff.write' : 'defs.write')
  return <ResourceTable key={ui.slug} ui={ui} canWrite={canWrite} />
}

/** Aynı sayfada birkaç tanımı sekmelerle gösterir (Ürünler | Kategoriler gibi). */
export function ResourceTabs({ slugs, role = 'ADMIN' }: { slugs: string[]; role?: Role }) {
  const [active, setActive] = useState(slugs[0])
  return (
    <>
      <div className="mb-4 flex gap-1.5">
        {slugs.map((s) => (
          <button
            key={s}
            onClick={() => setActive(s)}
            className={`rounded-full px-4 py-1.5 text-sm transition-colors ${active === s ? 'bg-brand-600 font-medium text-white' : 'bg-white text-slate-600 ring-1 ring-line hover:bg-slate-50'}`}
          >
            {findResourceUI(s)?.title}
          </button>
        ))}
      </div>
      <ResourcePage slug={active} role={role} />
    </>
  )
}

function ResourceTable({ ui, canWrite }: { ui: ResourceUI; canWrite: boolean }) {
  const [rows, setRows] = useState<Row[] | null>(null)
  const [options, setOptions] = useState<Options>({})
  const [search, setSearch] = useState('')
  const [editing, setEditing] = useState<Row | null>(null)
  const [dialog, setDialog] = useState<'form' | 'delete' | null>(null)
  const [form, setForm] = useState<Form>({})
  const [busy, setBusy] = useState(false)

  const load = useCallback(async () => {
    try {
      setRows(await api.get<Row[]>(ui.api))
    } catch (e) {
      toast.error((e as Error).message)
      setRows([])
    }
  }, [ui.api])

  useEffect(() => {
    void load()
    // Yabancı anahtar seçeneklerini yükle
    for (const f of ui.fields) {
      if (!f.optionsFrom) continue
      const { url, label } = f.optionsFrom
      api
        .get<Row[]>(url)
        .then((list) => setOptions((o) => ({ ...o, [f.key]: list.map((r) => ({ value: r.id, label: label(r) })) })))
        .catch(() => {})
    }
  }, [load, ui.fields])

  const visible = useMemo(() => {
    if (!rows) return []
    const q = search.trim().toLocaleLowerCase('tr-TR')
    return q ? rows.filter((r) => flatten(r).toLocaleLowerCase('tr-TR').includes(q)) : rows
  }, [rows, search])

  function openForm(row: Row | null) {
    setEditing(row)
    setForm(rowToForm(ui, row))
    setDialog('form')
  }

  async function save(e: React.FormEvent) {
    e.preventDefault()
    setBusy(true)
    try {
      const payload = formToPayload(ui, form, Boolean(editing))
      if (editing) await api.patch(`${ui.api}/${editing.id}`, payload)
      else await api.post(ui.api, payload)
      toast.success(editing ? 'Değişiklikler kaydedildi' : `${ui.singular} eklendi`)
      setDialog(null)
      await load()
    } catch (err) {
      toast.error((err as Error).message)
    } finally {
      setBusy(false)
    }
  }

  async function remove() {
    if (!editing) return
    setBusy(true)
    try {
      await api.del(`${ui.api}/${editing.id}`)
      toast.success('Silindi')
      setDialog(null)
      await load()
    } catch (err) {
      toast.error((err as Error).message)
    } finally {
      setBusy(false)
    }
  }

  const set = (key: string, value: string | boolean) => setForm((f) => ({ ...f, [key]: value }))

  return (
    <>
      <PageHeader
        title={ui.title}
        subtitle={ui.description}
        actions={
          <>
            <div className="relative">
              <Icon name="Search" size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Ara…" className="w-48 pl-9" aria-label="Ara" />
            </div>
            {canWrite && (
              <Button onClick={() => openForm(null)}>
                <Icon name="Plus" size={16} /> {ui.singular} ekle
              </Button>
            )}
          </>
        }
      />

      <Card className="overflow-hidden">
        {rows === null ? (
          <Spinner />
        ) : visible.length === 0 ? (
          <EmptyState icon={ui.icon} text={search ? 'Aramanızla eşleşen kayıt yok.' : (ui.emptyText ?? 'Henüz kayıt yok.')} />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b border-line bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-500">
                <tr>
                  {ui.columns.map((c) => (
                    <th key={c.header} className={`px-4 py-2.5 font-medium ${c.className ?? ''}`}>{c.header}</th>
                  ))}
                  <th className="w-24 px-4 py-2.5" />
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {visible.map((row) => (
                  <tr key={row.id} className="hover:bg-slate-50/70">
                    {ui.columns.map((c) => (
                      <td key={c.header} className={`px-4 py-2.5 ${c.className ?? ''}`}>{c.cell(row)}</td>
                    ))}
                    <td className="px-4 py-2.5">
                      {canWrite && <div className="flex justify-end gap-1">
                        <button onClick={() => openForm(row)} className="rounded-md p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-700" aria-label="Düzenle">
                          <Icon name="Pencil" size={16} />
                        </button>
                        <button
                          onClick={() => {
                            setEditing(row)
                            setDialog('delete')
                          }}
                          className="rounded-md p-1.5 text-slate-400 hover:bg-rose-50 hover:text-rose-600"
                          aria-label="Sil"
                        >
                          <Icon name="Trash2" size={16} />
                        </button>
                      </div>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Dialog
        open={dialog === 'form'}
        onClose={() => setDialog(null)}
        title={editing ? `${ui.singular} düzenle` : `${ui.singular} ekle`}
        footer={
          <>
            <Button variant="secondary" onClick={() => setDialog(null)}>Vazgeç</Button>
            <Button type="submit" form="resource-form" disabled={busy}>{busy ? 'Kaydediliyor…' : 'Kaydet'}</Button>
          </>
        }
      >
        <form id="resource-form" onSubmit={save} className="grid grid-cols-2 gap-x-4 gap-y-3.5">
          {ui.fields
            .filter((f) => !(f.only === 'create' && editing) && !(f.only === 'edit' && !editing))
            .map((f) => (
              <FieldInput key={f.key} f={f} form={form} set={set} options={options[f.key]} editing={Boolean(editing)} />
            ))}
        </form>
      </Dialog>

      <Dialog
        open={dialog === 'delete'}
        onClose={() => setDialog(null)}
        title="Silmeyi onayla"
        size="max-w-sm"
        footer={
          <>
            <Button variant="secondary" onClick={() => setDialog(null)}>Vazgeç</Button>
            <Button variant="danger" onClick={remove} disabled={busy}>Sil</Button>
          </>
        }
      >
        <p className="text-sm text-slate-600">
          <strong>{editing ? ui.nameOf(editing) : ''}</strong> kalıcı olarak silinecek. Bu işlem geri alınamaz.
        </p>
      </Dialog>
    </>
  )
}

function FieldInput({
  f,
  form,
  set,
  options,
  editing,
}: {
  f: FieldDef
  form: Form
  set: (k: string, v: string | boolean) => void
  options?: { value: string; label: string }[]
  editing: boolean
}) {
  const type = typeOf(f, form)
  const span = f.wide || type === 'textarea' || type === 'checkbox' ? 'col-span-2' : 'col-span-2 sm:col-span-1'
  const required = f.required || (type === 'password' && !editing)
  const value = form[f.key]

  if (type === 'checkbox') {
    return (
      <div className={span}>
        <Checkbox label={f.label} checked={Boolean(value)} onChange={(e) => set(f.key, e.target.checked)} />
      </div>
    )
  }

  return (
    <Field label={f.label + (required ? ' *' : '')} hint={f.hint} className={span}>
      {type === 'select' ? (
        <Select value={String(value ?? '')} onChange={(e) => set(f.key, e.target.value)} required={required && !f.nullable}>
          {f.nullable ? <option value="">— Yok —</option> : <option value="" disabled>Seçin…</option>}
          {(f.options ?? options ?? []).map((o) => (
            <option key={o.value} value={o.value}>{o.label}</option>
          ))}
        </Select>
      ) : type === 'textarea' ? (
        <Textarea value={String(value ?? '')} onChange={(e) => set(f.key, e.target.value)} placeholder={f.placeholder} />
      ) : (
        <Input
          type={type === 'money' || type === 'number' ? 'text' : type}
          inputMode={type === 'money' ? 'decimal' : type === 'number' ? 'numeric' : undefined}
          value={String(value ?? '')}
          onChange={(e) => set(f.key, e.target.value)}
          placeholder={f.placeholder}
          required={required}
          autoComplete={type === 'password' ? 'new-password' : 'off'}
        />
      )}
    </Field>
  )
}
