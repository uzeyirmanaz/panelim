'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import { api } from '@/lib/api-client'
import { useApi } from '@/hooks/use-api'
import { formatMoney, minutesAgo } from '@/lib/format'
import { orderHref } from '@/lib/order-link'
import { ORDER_STATUS_LABELS, ORDER_TYPE_LABELS } from '@/lib/constants'
import type { FloorTableDTO, FloorZoneDTO, OrderDTO } from '@/lib/types'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Dialog } from '@/components/ui/dialog'
import { Icon } from '@/components/ui/icon'
import { Card, EmptyState, PageHeader, Spinner, StatusBadge } from '@/components/ui/misc'
import { useLive } from './live-provider'

// Kart rengi: boş → beyaz, son 20 dakikada hareket gören → yeşil, daha eski → kırmızı
type Heat = 'empty' | 'fresh' | 'stale'
const heat = (t: FloorTableDTO): Heat => (!t.order ? 'empty' : minutesAgo(t.order.updatedAt) < 20 ? 'fresh' : 'stale')
const HEAT_STYLE: Record<Heat, string> = {
  empty: 'border-line bg-white hover:border-slate-300',
  fresh: 'border-emerald-300 bg-emerald-50',
  stale: 'border-brand-300 bg-brand-50',
}

function elapsed(iso: string) {
  const m = minutesAgo(iso)
  return m >= 60 ? `${Math.floor(m / 60)} sa ${m % 60} dk` : `${m} dk`
}

type Flat = FloorTableDTO & { zoneName: string }

export function Floor() {
  const router = useRouter()
  const floor = useApi<FloorZoneDTO[]>('/api/floor')
  const open = useApi<OrderDTO[]>('/api/orders?scope=open')
  const [zone, setZone] = useState('all')
  const [view, setView] = useState<'grid' | 'list'>('grid')
  const [menuFor, setMenuFor] = useState<string | null>(null)
  const [cancelFor, setCancelFor] = useState<Flat | null>(null)
  const [, tick] = useState(0)

  useLive(() => {
    void floor.reload()
    void open.reload()
  })
  useEffect(() => {
    const t = setInterval(() => tick((n) => n + 1), 30_000) // süre ve renkleri tazele
    return () => clearInterval(t)
  }, [])

  const zones = floor.data ?? []
  const tables: Flat[] = useMemo(
    () => zones.filter((z) => zone === 'all' || z.id === zone).flatMap((z) => z.tables.map((t) => ({ ...t, zoneName: z.name }))),
    [zones, zone]
  )
  const offTable = (open.data ?? []).filter((o) => o.type !== 'TABLE')

  async function cancel() {
    if (!cancelFor?.order) return
    try {
      await api.del(`/api/orders/${cancelFor.order.id}`)
      toast.success('Adisyon iptal edildi')
      setCancelFor(null)
    } catch (e) {
      toast.error((e as Error).message)
    }
  }

  const go = (t: Flat, islem?: 'ode' | 'tasi') =>
    router.push(t.order ? orderHref({ tableId: t.id, type: 'TABLE' }, islem) : `/panel/siparis/${t.id}`)

  return (
    <>
      <PageHeader
        title="Masa / Bölgeler"
        subtitle="Bir masaya dokunarak adisyon açın veya devam edin."
        actions={
          <>
            <div className="flex rounded-lg bg-slate-100 p-1" role="group" aria-label="Görünüm">
              {([['grid', 'LayoutGrid', 'Masa gruplaması'], ['list', 'List', 'Liste görünümü']] as const).map(([k, icon, label]) => (
                <button
                  key={k}
                  onClick={() => setView(k)}
                  title={label}
                  aria-label={label}
                  className={cn('rounded-md p-2 transition-colors', view === k ? 'bg-white text-brand-700 shadow-sm' : 'text-slate-500')}
                >
                  <Icon name={icon} size={16} />
                </button>
              ))}
            </div>
            <Link href="/panel/siparis/paket" className="inline-flex h-10 items-center gap-2 rounded-lg border border-line bg-white px-4 text-sm font-medium hover:bg-slate-50">
              <Icon name="Truck" size={16} /> Paket
            </Link>
            <Link href="/panel/siparis/gelal" className="inline-flex h-10 items-center gap-2 rounded-lg border border-line bg-white px-4 text-sm font-medium hover:bg-slate-50">
              <Icon name="ShoppingBag" size={16} /> Gel-Al
            </Link>
            <Link href="/panel/masalar/duzenle" className="inline-flex h-10 items-center gap-2 rounded-lg border border-line bg-white px-4 text-sm font-medium hover:bg-slate-50">
              <Icon name="Pencil" size={16} /> Masa tanımları
            </Link>
          </>
        }
      />

      {floor.loading ? (
        <Spinner />
      ) : zones.length === 0 ? (
        <Card>
          <EmptyState icon="LayoutGrid" text="Henüz masa tanımlı değil. “Masa tanımları” ile bölge ve masa ekleyin." />
        </Card>
      ) : (
        <>
          <div className="mb-4 flex flex-wrap gap-1.5">
            {[{ id: 'all', name: 'Tümü' }, ...zones].map((z) => (
              <button
                key={z.id}
                onClick={() => setZone(z.id)}
                className={cn(
                  'rounded-full px-3.5 py-1.5 text-sm transition-colors',
                  zone === z.id ? 'bg-brand-600 text-white' : 'bg-white text-slate-600 ring-1 ring-line hover:bg-slate-50'
                )}
              >
                {z.name}
              </button>
            ))}
          </div>

          <div className="mb-3 flex flex-wrap gap-4 text-xs text-slate-500">
            <Legend color="bg-white ring-1 ring-line" label="Boş" />
            <Legend color="bg-emerald-200" label="Yeni hareket (20 dk içinde)" />
            <Legend color="bg-brand-200" label="Adisyon açık" />
          </div>

          {view === 'grid' ? (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6">
              {tables.map((t) => (
                <div key={t.id} className={cn('relative rounded-xl border-2 transition-colors', HEAT_STYLE[heat(t)])}>
                  <button onClick={() => go(t)} className="flex min-h-28 w-full flex-col justify-between p-3 text-left">
                    <span className="pr-6 font-semibold">{t.name}</span>
                    {t.order ? (
                      <span>
                        <span className="block text-lg font-semibold tabular-nums">{formatMoney(t.order.total)}</span>
                        <span className="block text-xs text-slate-500">
                          {ORDER_STATUS_LABELS[t.order.status]} · {elapsed(t.order.createdAt)}
                        </span>
                      </span>
                    ) : (
                      <span className="text-xs text-slate-400">
                        {t.zoneName} · {t.seats} kişi
                      </span>
                    )}
                  </button>
                  {t.order && <RowMenu open={menuFor === t.id} setOpen={(o) => setMenuFor(o ? t.id : null)} onPick={(a) => (a === 'iptal' ? setCancelFor(t) : go(t, a))} />}
                </div>
              ))}
            </div>
          ) : (
            <Card className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b border-line bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-500">
                  <tr>
                    <th className="px-4 py-2.5 font-medium">Masa</th>
                    <th className="px-4 py-2.5 font-medium">Bölge</th>
                    <th className="px-4 py-2.5 font-medium">Durum</th>
                    <th className="px-4 py-2.5 font-medium">Süre</th>
                    <th className="px-4 py-2.5 text-right font-medium">Tutar</th>
                    <th className="w-12" />
                  </tr>
                </thead>
                <tbody className="divide-y divide-line">
                  {tables.map((t) => (
                    <tr key={t.id} className="cursor-pointer hover:bg-slate-50/70" onClick={() => go(t)}>
                      <td className="px-4 py-2.5 font-medium">{t.name}</td>
                      <td className="px-4 py-2.5 text-slate-500">{t.zoneName}</td>
                      <td className="px-4 py-2.5">{t.order ? <StatusBadge status={t.order.status} /> : <span className="text-slate-400">Boş</span>}</td>
                      <td className="px-4 py-2.5 text-slate-500">{t.order ? elapsed(t.order.createdAt) : '—'}</td>
                      <td className="px-4 py-2.5 text-right font-medium tabular-nums">{t.order ? formatMoney(t.order.total) : '—'}</td>
                      <td className="relative px-2" onClick={(e) => e.stopPropagation()}>
                        {t.order && <RowMenu inline open={menuFor === t.id} setOpen={(o) => setMenuFor(o ? t.id : null)} onPick={(a) => (a === 'iptal' ? setCancelFor(t) : go(t, a))} />}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </Card>
          )}
        </>
      )}

      {offTable.length > 0 && (
        <section className="mt-8">
          <h2 className="mb-2 text-sm font-semibold text-slate-500">Açık paket / gel-al siparişleri</h2>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {offTable.map((o) => (
              <Link key={o.id} href={orderHref(o)} className="rounded-xl border border-line bg-white p-3 hover:border-brand-300">
                <div className="flex items-center justify-between">
                  <span className="font-medium">#{o.number} · {ORDER_TYPE_LABELS[o.type]}</span>
                  <StatusBadge status={o.status} />
                </div>
                <p className="mt-1 text-sm text-slate-500">{o.customerName ?? 'Müşteri belirtilmedi'}</p>
                <p className="mt-1 font-semibold tabular-nums">{formatMoney(o.total)}</p>
              </Link>
            ))}
          </div>
        </section>
      )}

      <Dialog
        open={Boolean(cancelFor)}
        onClose={() => setCancelFor(null)}
        title="Adisyonu iptal et"
        size="max-w-sm"
        footer={
          <>
            <Button variant="secondary" onClick={() => setCancelFor(null)}>Vazgeç</Button>
            <Button variant="danger" onClick={cancel}>İptal et</Button>
          </>
        }
      >
        <p className="text-sm text-slate-600">
          <strong>{cancelFor?.name}</strong> masasındaki adisyon iptal edilecek ve masa boşalacak. Raporlarda ciroya yansımaz.
        </p>
      </Dialog>
    </>
  )
}

function Legend({ color, label }: { color: string; label: string }) {
  return (
    <span className="flex items-center gap-1.5">
      <span className={cn('size-3 rounded-sm', color)} /> {label}
    </span>
  )
}

type Action = 'ode' | 'tasi' | 'iptal'

/** ⋮ işlem menüsü: öde, masa değiştir/birleştir (adisyon aktar), iptal */
function RowMenu({ open, setOpen, onPick, inline }: { open: boolean; setOpen: (o: boolean) => void; onPick: (a: Action) => void; inline?: boolean }) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (!open) return
    const close = (e: MouseEvent) => !ref.current?.contains(e.target as Node) && setOpen(false)
    document.addEventListener('mousedown', close)
    return () => document.removeEventListener('mousedown', close)
  }, [open, setOpen])

  const items: [Action, string, string][] = [
    ['ode', 'Banknote', 'Öde'],
    ['tasi', 'ArrowRightLeft', 'Masa değiştir / birleştir'],
    ['iptal', 'Trash2', 'İptal'],
  ]
  return (
    <div ref={ref} className={cn(inline ? 'relative' : 'absolute right-1 top-1')}>
      <button onClick={() => setOpen(!open)} aria-label="İşlemler" aria-expanded={open} className="rounded-md p-1.5 text-slate-400 hover:bg-black/5 hover:text-slate-700">
        <Icon name="MoreVertical" size={16} />
      </button>
      {open && (
        <ul className="absolute right-0 z-20 mt-1 w-52 rounded-lg border border-line bg-white py-1 shadow-lg">
          {items.map(([a, icon, label]) => (
            <li key={a}>
              <button
                onClick={() => {
                  setOpen(false)
                  onPick(a)
                }}
                className={cn('flex w-full items-center gap-2.5 px-3 py-2 text-left text-sm hover:bg-slate-50', a === 'iptal' && 'text-rose-600')}
              >
                <Icon name={icon} size={15} /> {label}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
