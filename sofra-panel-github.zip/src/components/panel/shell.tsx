'use client'

import { useEffect, useRef, useState } from 'react'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { api } from '@/lib/api-client'
import { BRAND } from '@/lib/brand'
import { activeGroups, titleFor, visibleNav, type NavItem } from '@/lib/nav'
import { ROLE_LABELS } from '@/lib/constants'
import { can } from '@/lib/permissions'
import type { SessionUser } from '@/lib/types'
import { cn } from '@/lib/utils'
import { Icon } from '@/components/ui/icon'
import { LiveProvider, useLiveStatus } from './live-provider'

export function Shell({ user, children }: { user: SessionUser; children: React.ReactNode }) {
  return (
    <LiveProvider>
      <ShellInner user={user}>{children}</ShellInner>
    </LiveProvider>
  )
}

function flattenHrefs(items: NavItem[]): string[] {
  return items.flatMap((i) => (i.children ? flattenHrefs(i.children) : i.href ? [i.href] : []))
}

function useOutsideClose(open: boolean, close: () => void) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (!open) return
    const onDown = (e: MouseEvent) => ref.current && !ref.current.contains(e.target as Node) && close()
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && close()
    document.addEventListener('mousedown', onDown)
    document.addEventListener('keydown', onKey)
    return () => {
      document.removeEventListener('mousedown', onDown)
      document.removeEventListener('keydown', onKey)
    }
  }, [open, close])
  return ref
}

function ShellInner({ user, children }: { user: SessionUser; children: React.ReactNode }) {
  const pathname = usePathname()
  const router = useRouter()
  const connected = useLiveStatus()
  const nav = visibleNav(user.role)

  const [collapsed, setCollapsed] = useState(false) // masaüstü kenar çubuğu
  const [drawer, setDrawer] = useState(false) // mobil çekmece
  const [openGroups, setOpenGroups] = useState<Set<string>>(() => new Set(activeGroups(pathname)))
  const [menu, setMenu] = useState<'more' | 'profile' | null>(null)
  const menuRef = useOutsideClose(menu !== null, () => setMenu(null))

  useEffect(() => {
    setOpenGroups((prev) => new Set([...prev, ...activeGroups(pathname)]))
    setDrawer(false)
    setMenu(null)
  }, [pathname])

  // En uzun eşleşen menü yolu aktif sayılır (örn. /panel/masalar/duzenle iken /panel/masalar değil)
  const allHrefs = flattenHrefs(nav)
  const isActive = (href: string) => {
    if (href === '/panel') return pathname === '/panel'
    const best = allHrefs.filter((h) => h !== '/panel' && (pathname === h || pathname.startsWith(h + '/'))).sort((a, b) => b.length - a.length)[0]
    return best === href
  }
  const toggle = (label: string) =>
    setOpenGroups((s) => {
      const n = new Set(s)
      if (!n.delete(label)) n.add(label)
      return n
    })

  async function logout() {
    await api.post('/api/auth/logout').catch(() => {})
    router.replace('/giris')
    router.refresh()
  }

  function renderItem(item: NavItem, depth = 0) {
    const pad = depth === 0 ? 'px-2.5' : depth === 1 ? 'pl-8 pr-2.5' : 'pl-12 pr-2.5'
    if (item.children) {
      const open = openGroups.has(item.label)
      return (
        <li key={item.label}>
          <button
            onClick={() => toggle(item.label)}
            aria-expanded={open}
            className={cn('flex w-full items-center gap-2.5 rounded-lg py-2 text-sm text-slate-600 hover:bg-slate-100', pad)}
          >
            <Icon name={item.icon} size={17} />
            <span className="flex-1 text-left">{item.label}</span>
            <Icon name="ChevronDown" size={15} className={cn('transition-transform', open && 'rotate-180')} />
          </button>
          {open && <ul className="mt-0.5 space-y-0.5">{item.children.map((c) => renderItem(c, depth + 1))}</ul>}
        </li>
      )
    }
    const active = isActive(item.href!)
    return (
      <li key={item.href}>
        <Link
          href={item.href!}
          className={cn(
            'flex items-center gap-2.5 rounded-lg py-2 text-sm transition-colors',
            pad,
            active ? 'bg-brand-50 font-medium text-brand-700' : 'text-slate-600 hover:bg-slate-100'
          )}
        >
          <Icon name={item.icon} size={depth ? 16 : 17} />
          {item.label}
        </Link>
      </li>
    )
  }

  const sidebar = (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-2.5 px-5 py-4">
        <span className="grid size-9 place-items-center rounded-xl bg-brand-600 text-white">
          <Icon name="UtensilsCrossed" size={19} />
        </span>
        <div className="min-w-0 leading-tight">
          <p className="text-[15px] font-semibold">{BRAND.appName}</p>
          <p className="truncate text-xs text-slate-400">
            {BRAND.restaurantName} · {BRAND.accountCode}
          </p>
        </div>
      </div>
      <nav className="scroll-thin flex-1 overflow-y-auto px-3 pb-4">
        <ul className="space-y-0.5">{nav.map((i) => renderItem(i))}</ul>
      </nav>
    </div>
  )

  const menuItem = 'flex h-10 w-full items-center gap-3 px-4 text-left text-[13px] text-slate-600 hover:bg-slate-50'

  return (
    <div className={cn('min-h-dvh transition-[padding]', collapsed ? 'lg:pl-0' : 'lg:pl-64')}>
      <aside className={cn('no-print fixed inset-y-0 left-0 hidden w-64 border-r border-line bg-white', !collapsed && 'lg:block')}>{sidebar}</aside>

      {drawer && (
        <div className="no-print fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-slate-900/40" onClick={() => setDrawer(false)} />
          <aside className="absolute inset-y-0 left-0 w-72 bg-white shadow-xl">{sidebar}</aside>
        </div>
      )}

      <header className="no-print sticky top-0 z-30 flex h-14 items-center gap-3 border-b border-line bg-white/90 px-4 backdrop-blur">
        <button
          onClick={() => (window.matchMedia('(min-width: 1024px)').matches ? setCollapsed((c) => !c) : setDrawer(true))}
          className="rounded-md p-1.5 text-slate-600 hover:bg-slate-100"
          aria-label="Menüyü aç/kapat"
        >
          <Icon name="Menu" size={22} />
        </button>
        <h2 className="truncate text-[15px] font-semibold">{titleFor(pathname)}</h2>

        <div className="ml-auto flex items-center gap-1" ref={menuRef}>
          <span
            className="mr-1 hidden items-center gap-1.5 text-xs text-slate-500 sm:flex"
            title={connected ? 'Canlı bağlantı aktif' : 'Bağlantı yeniden kuruluyor…'}
          >
            <Icon name={connected ? 'Wifi' : 'WifiOff'} size={15} className={connected ? 'text-emerald-500' : 'text-amber-500'} />
            {connected ? 'Canlı' : 'Bağlanıyor…'}
          </span>

          <button onClick={() => router.refresh()} className="rounded-md p-2 text-slate-500 hover:bg-slate-100" aria-label="Yenile">
            <Icon name="RefreshCw" size={17} />
          </button>

          {can(user.role, 'panel.view') && (
            <div className="relative">
              <button
                onClick={() => setMenu(menu === 'more' ? null : 'more')}
                className="rounded-md p-2 text-slate-500 hover:bg-slate-100"
                aria-label="Daha fazla"
                aria-expanded={menu === 'more'}
              >
                <Icon name="EllipsisVertical" size={17} />
              </button>
              {menu === 'more' && (
                <div role="menu" className="absolute right-0 top-full mt-1 w-52 overflow-hidden rounded-xl border border-line bg-white py-1 shadow-lg">
                  <Link href="/panel/dijital-menu" role="menuitem" className={menuItem}><Icon name="QrCode" size={16} /> Dijital Menü</Link>
                  <Link href="/panel/siparisler" role="menuitem" className={menuItem}><Icon name="ReceiptText" size={16} /> Siparişler</Link>
                  <Link href="/panel/mutfak" role="menuitem" className={menuItem}><Icon name="ChefHat" size={16} /> Mutfak Ekranı</Link>
                </div>
              )}
            </div>
          )}

          <div className="relative">
            <button
              onClick={() => setMenu(menu === 'profile' ? null : 'profile')}
              className="flex items-center gap-2 rounded-lg py-1 pl-1 pr-2 hover:bg-slate-100"
              aria-expanded={menu === 'profile'}
            >
              <span className="grid size-8 place-items-center rounded-full bg-brand-100 text-xs font-semibold text-brand-700">
                {user.name.slice(0, 1).toLocaleUpperCase('tr-TR')}
              </span>
              <span className="hidden text-left leading-tight sm:block">
                <span className="block text-[13px] font-medium">{user.name}</span>
                <span className="block text-[11px] text-slate-400">{ROLE_LABELS[user.role]}</span>
              </span>
            </button>
            {menu === 'profile' && (
              <div role="menu" className="absolute right-0 top-full mt-1 w-52 overflow-hidden rounded-xl border border-line bg-white py-1 shadow-lg">
                <Link href="/panel/hesabim" role="menuitem" className={menuItem}><Icon name="UserCog" size={16} /> Hesabım</Link>
                {can(user.role, 'panel.view') && (
                  <Link href="/panel/ayarlar" role="menuitem" className={menuItem}><Icon name="Settings" size={16} /> Ayarlar</Link>
                )}
                {can(user.role, 'users.manage') && (
                  <Link href="/panel/kullanicilar" role="menuitem" className={menuItem}><Icon name="Users" size={16} /> Kullanıcılar</Link>
                )}
                <button role="menuitem" onClick={logout} className={cn(menuItem, 'border-t border-line text-rose-600')}>
                  <Icon name="LogOut" size={16} /> Çıkış yap
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl p-4 sm:p-6">{children}</main>
    </div>
  )
}
