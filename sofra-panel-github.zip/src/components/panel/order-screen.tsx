'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import { api } from '@/lib/api-client'
import { useApi } from '@/hooks/use-api'
import { orderHref } from '@/lib/order-link'
import { formatMoney, formatTime, parseMoney } from '@/lib/format'
import {
  ORDER_TYPE_LABELS,
  OPEN_STATUSES,
  PAYMENT_LABELS,
  PAYMENT_METHODS,
  ORDER_STATUS_LABELS,
  type OrderType,
  type PaymentMethod,
} from '@/lib/constants'
import type { CategoryDTO, FloorZoneDTO, OrderDTO, ProductDTO } from '@/lib/types'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Dialog } from '@/components/ui/dialog'
import { Field, Input, Select, Textarea } from '@/components/ui/field'
import { Icon } from '@/components/ui/icon'
import { Spinner, StatusBadge } from '@/components/ui/misc'
import { useLive } from './live-provider'

type Line = { productId: string; name: string; unitPrice: number; quantity: number; note: string }
type Row = { id: string; name: string; kind?: 'PERCENT' | 'AMOUNT'; value?: number }

type Props = { orderId?: string; tableId?: string; type?: OrderType; initialDialog?: 'pay' | 'move' }

export function OrderScreen({ orderId, tableId, type, initialDialog }: Props) {
  const router = useRouter()
  const menu = useApi<CategoryDTO[]>('/api/menu')
  const tables = useApi<{ id: string; name: string }[]>(tableId ? '/api/r/tables' : null)

  const [order, setOrder] = useState<OrderDTO | null>(null)
  const [loading, setLoading] = useState(Boolean(orderId || tableId))
  const [cart, setCart] = useState<Line[]>([])
  const [category, setCategory] = useState<string>('all')
  const [search, setSearch] = useState('')
  const [busy, setBusy] = useState(false)
  const [dialog, setDialog] = useState<'pay' | 'move' | 'cancel' | 'note' | null>(initialDialog ?? null)
  const [guests, setGuests] = useState(2)
  const notes = useApi<{ id: string; name: string }[]>('/api/r/note-templates')
  // yeni paket / gel-al siparişi için müşteri bilgisi
  const [customerName, setCustomerName] = useState('')
  const [customerId, setCustomerId] = useState('')
  const customers = useApi<Row[]>(!orderId && (type === 'DELIVERY' || type === 'PICKUP') ? '/api/r/customers' : null)

  const loadOrder = useCallback(async () => {
    try {
      if (orderId) setOrder(await api.get<OrderDTO>(`/api/orders/${orderId}`))
      else if (tableId) {
        const list = await api.get<OrderDTO[]>(`/api/orders?scope=open&tableId=${tableId}`)
        setOrder(list[0] ?? null)
      }
    } catch (e) {
      toast.error((e as Error).message)
    } finally {
      setLoading(false)
    }
  }, [orderId, tableId])

  useEffect(() => {
    void loadOrder()
  }, [loadOrder])

  useLive((e) => {
    if (e === null || (e.type === 'orders' && (!e.orderId || e.orderId === order?.id || e.tableId === tableId))) void loadOrder()
  })

  const orderType: OrderType | undefined = order?.type ?? type ?? (tableId ? 'TABLE' : undefined)
  const closed = order ? !OPEN_STATUSES.includes(order.status) : false
  const tableName = order?.tableName ?? tables.data?.find((t) => t.id === tableId)?.name ?? null

  // ── Ürün seçimi ──────────────────────────────────────────────────────────
  const products = useMemo(() => {
    const q = search.trim().toLocaleLowerCase('tr-TR')
    const all = (menu.data ?? []).flatMap((c) => (category === 'all' || category === c.id ? c.products : []))
    return q ? all.filter((p) => p.name.toLocaleLowerCase('tr-TR').includes(q)) : all
  }, [menu.data, category, search])

  function addToCart(p: ProductDTO) {
    setCart((lines) => {
      const i = lines.findIndex((l) => l.productId === p.id && !l.note)
      if (i >= 0) return lines.map((l, idx) => (idx === i ? { ...l, quantity: Math.min(99, l.quantity + 1) } : l))
      return [...lines, { productId: p.id, name: p.name, unitPrice: p.price, quantity: 1, note: '' }]
    })
  }
  const changeLine = (idx: number, patch: Partial<Line>) =>
    setCart((lines) => lines.flatMap((l, i) => (i !== idx ? [l] : patch.quantity !== undefined && patch.quantity <= 0 ? [] : [{ ...l, ...patch }])))

  const cartTotal = cart.reduce((s, l) => s + l.unitPrice * l.quantity, 0)

  // ── Sunucu işlemleri ─────────────────────────────────────────────────────
  async function run<T>(fn: () => Promise<T>, success?: string): Promise<T | undefined> {
    setBusy(true)
    try {
      const result = await fn()
      if (success) toast.success(success)
      return result
    } catch (e) {
      toast.error((e as Error).message)
    } finally {
      setBusy(false)
    }
  }

  async function sendCart() {
    if (cart.length === 0 || !orderType) return
    const items = cart.map((l) => ({ productId: l.productId, quantity: l.quantity, note: l.note || null }))
    const result = await run(
      () =>
        order
          ? api.post<OrderDTO>(`/api/orders/${order.id}/items`, { items })
          : api.post<OrderDTO>('/api/orders', {
              type: orderType,
              tableId: orderType === 'TABLE' ? tableId : null,
              customerId: customerId || null,
              customerName: customerName || null,
              guests: orderType === 'TABLE' ? guests : null,
              items,
            }),
      'Mutfağa gönderildi'
    )
    if (!result) return
    setOrder(result)
    setCart([])
    if (!orderId && !tableId) router.replace(orderHref(result))
  }

  const patchItem = (itemId: string, quantity: number) =>
    run(async () => setOrder(await api.patch<OrderDTO>(`/api/orders/${order!.id}/items/${itemId}`, { quantity })))

  const setStatus = (status: string) =>
    run(async () => setOrder(await api.patch<OrderDTO>(`/api/orders/${order!.id}`, { status })))

  async function cancelOrder() {
    const ok = await run(() => api.del(`/api/orders/${order!.id}`), 'Adisyon iptal edildi')
    if (ok) router.replace('/panel/masalar')
  }

  // ── Görünüm ──────────────────────────────────────────────────────────────
  if (loading || menu.loading) return <Spinner />

  if (!orderType) {
    return (
      <div className="py-16 text-center text-slate-500">
        <p>Önce bir masa veya sipariş türü seçin.</p>
        <Link href="/panel/masalar" className="mt-3 inline-block text-brand-700 underline">Masalara dön</Link>
      </div>
    )
  }

  const title = order
    ? `#${order.number} · ${order.tableName ?? ORDER_TYPE_LABELS[order.type]}`
    : `Yeni adisyon · ${tableName ?? ORDER_TYPE_LABELS[orderType]}`
  const canSend = !closed && cart.length > 0

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_390px]">
      {/* ─── Ürün seçici ─── */}
      <div className="min-w-0">
        <div className="mb-3 flex items-center gap-3">
          <Link href="/panel/masalar" className="rounded-lg p-2 text-slate-500 hover:bg-slate-100" aria-label="Masalara dön">
            <Icon name="ArrowLeft" />
          </Link>
          <h1 className="text-lg font-semibold">{title}</h1>
          {order && <StatusBadge status={order.status} />}
          {orderType === 'TABLE' && !closed && (
            <div className="ml-auto flex items-center gap-1 rounded-lg border border-line bg-white px-1" title="Kişi sayısı">
              <Icon name="Users" size={15} className="ml-1 text-slate-400" />
              <Stepper
                value={order?.guests ?? guests}
                onChange={(g) => {
                  const n = Math.max(1, g)
                  if (order) void run(async () => setOrder(await api.patch<OrderDTO>(`/api/orders/${order.id}`, { guests: n })))
                  else setGuests(n)
                }}
              />
            </div>
          )}
        </div>

        {closed ? (
          <p className="rounded-xl border border-line bg-white p-6 text-center text-slate-500">
            Bu adisyon {ORDER_STATUS_LABELS[order!.status].toLocaleLowerCase('tr-TR')} durumunda; değiştirilemez.
          </p>
        ) : (
          <>
            <div className="relative mb-3">
              <Icon name="Search" size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Ürün ara…" className="pl-9" aria-label="Ürün ara" />
            </div>
            <div className="scroll-thin mb-3 flex gap-1.5 overflow-x-auto pb-1">
              {[{ id: 'all', name: 'Tümü', emoji: null }, ...(menu.data ?? [])].map((c) => (
                <button
                  key={c.id}
                  onClick={() => setCategory(c.id)}
                  className={cn(
                    'shrink-0 rounded-full px-3.5 py-1.5 text-sm transition-colors',
                    category === c.id ? 'bg-brand-600 text-white' : 'bg-white text-slate-600 ring-1 ring-line hover:bg-slate-50'
                  )}
                >
                  {'emoji' in c && c.emoji ? `${c.emoji} ` : ''}
                  {c.name}
                </button>
              ))}
            </div>

            {products.length === 0 ? (
              <p className="py-10 text-center text-sm text-slate-400">Ürün bulunamadı.</p>
            ) : (
              <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 xl:grid-cols-4">
                {products.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => addToCart(p)}
                    className="flex min-h-24 flex-col justify-between rounded-xl border border-line bg-white p-3 text-left transition hover:border-brand-400 hover:shadow-sm active:scale-[0.98]"
                  >
                    <span className="text-sm font-medium leading-snug">
                      {p.emoji && <span className="mr-1">{p.emoji}</span>}
                      {p.name}
                    </span>
                    <span className="mt-2 text-sm font-semibold tabular-nums text-brand-700">{formatMoney(p.price)}</span>
                  </button>
                ))}
              </div>
            )}
          </>
        )}
      </div>

      {/* ─── Adisyon ─── */}
      <aside id="ticket" className="lg:sticky lg:top-20 lg:self-start">
        <div className="flex max-h-[calc(100dvh-7rem)] flex-col rounded-2xl border border-line bg-white shadow-sm">
          {!order && (orderType === 'DELIVERY' || orderType === 'PICKUP') && (
            <div className="space-y-2 border-b border-line p-3">
              <Select value={customerId} onChange={(e) => {
                setCustomerId(e.target.value)
                const c = customers.data?.find((x) => x.id === e.target.value)
                if (c) setCustomerName(c.name)
              }} aria-label="Kayıtlı müşteri">
                <option value="">Kayıtlı müşteri seç (isteğe bağlı)</option>
                {(customers.data ?? []).map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </Select>
              <Input value={customerName} onChange={(e) => setCustomerName(e.target.value)} placeholder="Müşteri adı" aria-label="Müşteri adı" />
            </div>
          )}
          {order?.customerName && <p className="border-b border-line px-4 py-2 text-sm text-slate-500">Müşteri: {order.customerName}</p>}

          <div className="scroll-thin flex-1 overflow-y-auto">
            {/* Kayıtlı kalemler */}
            {order?.items.map((i) => (
              <div key={i.id} className="flex items-center gap-2 border-b border-line px-4 py-2.5">
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{i.name}</p>
                  {i.note && <p className="truncate text-xs text-amber-600">{i.note}</p>}
                  <p className="text-xs text-slate-400 tabular-nums">{formatMoney(i.unitPrice)}</p>
                </div>
                {closed ? (
                  <span className="text-sm tabular-nums">{i.quantity}×</span>
                ) : (
                  <Stepper
                    value={i.quantity}
                    disabled={busy}
                    onChange={(q) => patchItem(i.id, q)}
                  />
                )}
                <span className="w-20 text-right text-sm font-medium tabular-nums">{formatMoney(i.unitPrice * i.quantity)}</span>
              </div>
            ))}

            {/* Henüz gönderilmemiş kalemler */}
            {cart.length > 0 && (
              <div className="bg-brand-50/40">
                <p className="px-4 pt-2 text-[11px] font-semibold uppercase tracking-wider text-brand-700">Gönderilecek</p>
                {cart.map((l, idx) => (
                  <div key={idx} className="border-b border-brand-100 px-4 py-2.5">
                    <div className="flex items-center gap-2">
                      <p className="min-w-0 flex-1 truncate text-sm font-medium">{l.name}</p>
                      <Stepper value={l.quantity} onChange={(q) => changeLine(idx, { quantity: q })} />
                      <span className="w-20 text-right text-sm font-medium tabular-nums">{formatMoney(l.unitPrice * l.quantity)}</span>
                    </div>
                    <input
                      value={l.note}
                      onChange={(e) => changeLine(idx, { note: e.target.value })}
                      list="note-templates"
                      placeholder="Not (az pişmiş, soğansız…)"
                      maxLength={200}
                      className="mt-1.5 w-full rounded-md border border-transparent bg-white/70 px-2 py-1 text-xs placeholder:text-slate-400 focus:border-brand-300 focus:outline-none"
                    />
                  </div>
                ))}
              </div>
            )}

            {!order?.items.length && cart.length === 0 && <p className="px-4 py-10 text-center text-sm text-slate-400">Ürün eklemek için soldan seçin.</p>}
          </div>

          <div className="space-y-3 border-t border-line p-4">
            {order && (
              <div className="space-y-1 text-sm">
                {order.discountTotal > 0 && (
                  <>
                    <Sum label="Ara toplam" value={order.subtotal} />
                    <Sum label="İndirim" value={-order.discountTotal} tone="text-emerald-600" />
                  </>
                )}
                <div className="flex items-baseline justify-between">
                  <span className="font-medium">Toplam</span>
                  <span className="text-xl font-semibold tabular-nums">{formatMoney(order.total)}</span>
                </div>
                {order.paidAt && (
                  <p className="text-xs text-slate-400">
                    {order.paymentMethod ? PAYMENT_LABELS[order.paymentMethod] : ''} · {formatTime(order.paidAt)} ödendi
                  </p>
                )}
              </div>
            )}

            {!closed && (
              <>
                {cart.length > 0 && (
                  <Button size="lg" className="w-full" onClick={sendCart} disabled={busy || !canSend}>
                    <Icon name="ChefHat" size={18} />
                    {order ? 'Siparişe ekle' : 'Siparişi kaydet'} · {formatMoney(cartTotal)}
                  </Button>
                )}

                {order && (
                  <>
                    <div className="flex flex-wrap gap-1.5" role="group" aria-label="Durum">
                      {(['NEW', 'PREPARING', 'READY', 'SERVED'] as const).map((s) => (
                        <button
                          key={s}
                          disabled={busy}
                          onClick={() => setStatus(s)}
                          className={cn(
                            'rounded-full px-2.5 py-1 text-xs transition-colors',
                            order.status === s ? 'bg-brand-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                          )}
                        >
                          {ORDER_STATUS_LABELS[s]}
                        </button>
                      ))}
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <Button
                        variant={cart.length === 0 ? 'primary' : 'secondary'}
                        onClick={() => setDialog('pay')}
                        disabled={busy || cart.length > 0 || order.items.length === 0}
                        title={cart.length > 0 ? 'Önce gönderilmemiş ürünleri kaydedin' : undefined}
                      >
                        <Icon name="Banknote" size={16} /> Ödeme al
                      </Button>
                      {order.type === 'TABLE' ? (
                        <Button variant="secondary" onClick={() => setDialog('move')} disabled={busy}>
                          <Icon name="ArrowRightLeft" size={16} /> Masa taşı
                        </Button>
                      ) : (
                        <Button variant="secondary" onClick={() => setDialog('note')} disabled={busy}>
                          <Icon name="StickyNote" size={16} /> Not
                        </Button>
                      )}
                      {order.type === 'TABLE' && (
                        <Button variant="secondary" onClick={() => setDialog('note')} disabled={busy}>
                          <Icon name="StickyNote" size={16} /> Not
                        </Button>
                      )}
                      <Button variant="ghost" className="text-rose-600 hover:bg-rose-50" onClick={() => setDialog('cancel')} disabled={busy}>
                        <Icon name="Trash2" size={16} /> İptal et
                      </Button>
                    </div>
                  </>
                )}
              </>
            )}
            {order?.note && <p className="rounded-lg bg-amber-50 px-3 py-2 text-xs text-amber-800">Not: {order.note}</p>}
          </div>
        </div>
      </aside>

      <datalist id="note-templates">{(notes.data ?? []).map((n) => <option key={n.id} value={n.name} />)}</datalist>
      {order && dialog === 'pay' && (
        <PayDialog order={order} onClose={() => setDialog(null)} onPaid={() => { toast.success('Ödeme alındı'); router.replace('/panel/masalar') }} />
      )}
      {order && dialog === 'move' && (
        <MoveDialog order={order} onClose={() => setDialog(null)} onMoved={(o, merged) => {
          setDialog(null)
          toast.success(merged ? 'Adisyonlar birleştirildi' : 'Masa değiştirildi')
          router.replace(orderHref(o))
          setOrder(o)
        }} />
      )}
      {order && dialog === 'note' && (
        <NoteDialog templates={notes.data ?? []} order={order} onClose={() => setDialog(null)} onSaved={(o) => { setOrder(o); setDialog(null) }} />
      )}
      <Dialog
        open={dialog === 'cancel'}
        onClose={() => setDialog(null)}
        title="Adisyonu iptal et"
        size="max-w-sm"
        footer={
          <>
            <Button variant="secondary" onClick={() => setDialog(null)}>Vazgeç</Button>
            <Button variant="danger" onClick={cancelOrder} disabled={busy}>İptal et</Button>
          </>
        }
      >
        <p className="text-sm text-slate-600">Bu adisyon iptal edilecek ve masa boşalacak. Raporlarda ciroya yansımaz.</p>
      </Dialog>
    </div>
  )
}

function Sum({ label, value, tone }: { label: string; value: number; tone?: string }) {
  return (
    <div className={cn('flex justify-between text-slate-500', tone)}>
      <span>{label}</span>
      <span className="tabular-nums">{value < 0 ? '−' : ''}{formatMoney(Math.abs(value))}</span>
    </div>
  )
}

function Stepper({ value, onChange, disabled }: { value: number; onChange: (q: number) => void; disabled?: boolean }) {
  return (
    <div className="flex items-center rounded-lg border border-line">
      <button disabled={disabled} onClick={() => onChange(value - 1)} className="grid size-7 place-items-center text-slate-500 hover:bg-slate-100 disabled:opacity-40" aria-label="Azalt">
        <Icon name={value <= 1 ? 'Trash2' : 'Minus'} size={14} />
      </button>
      <span className="w-6 text-center text-sm tabular-nums">{value}</span>
      <button disabled={disabled || value >= 99} onClick={() => onChange(value + 1)} className="grid size-7 place-items-center text-slate-500 hover:bg-slate-100 disabled:opacity-40" aria-label="Artır">
        <Icon name="Plus" size={14} />
      </button>
    </div>
  )
}

// ───────── Ödeme ─────────
function PayDialog({ order, onClose, onPaid }: { order: OrderDTO; onClose: () => void; onPaid: () => void }) {
  const discounts = useApi<Required<Row>[]>('/api/r/discounts')
  const [method, setMethod] = useState<PaymentMethod>('CASH')
  const [discount, setDiscount] = useState(order.discountTotal)
  const [custom, setCustom] = useState('')
  const [busy, setBusy] = useState(false)

  const total = Math.max(0, order.subtotal - discount)

  function applyPreset(d: Required<Row>) {
    const amount = d.kind === 'PERCENT' ? Math.round((order.subtotal * Math.min(100, d.value)) / 100) : d.value
    setDiscount(Math.min(order.subtotal, amount))
    setCustom('')
  }

  function applyCustom(v: string) {
    setCustom(v)
    const kurus = parseMoney(v)
    setDiscount(Math.min(order.subtotal, kurus ?? 0))
  }

  async function pay() {
    setBusy(true)
    try {
      await api.post(`/api/orders/${order.id}/pay`, { method, discountTotal: discount })
      onPaid()
    } catch (e) {
      toast.error((e as Error).message)
      setBusy(false)
    }
  }

  return (
    <Dialog
      open
      onClose={onClose}
      title="Ödeme al"
      size="max-w-md"
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>Vazgeç</Button>
          <Button onClick={pay} disabled={busy}>{formatMoney(total)} tahsil et</Button>
        </>
      }
    >
      <div className="space-y-4">
        <div className="rounded-xl bg-slate-50 p-4 text-center">
          <p className="text-sm text-slate-500">Ödenecek tutar</p>
          <p className="text-3xl font-semibold tabular-nums">{formatMoney(total)}</p>
          {discount > 0 && <p className="mt-1 text-xs text-emerald-600">{formatMoney(discount)} indirim uygulandı</p>}
        </div>

        <div>
          <p className="mb-1.5 text-[13px] font-medium text-slate-600">Ödeme yöntemi</p>
          <div className="grid grid-cols-3 gap-2">
            {PAYMENT_METHODS.map((m) => (
              <button
                key={m}
                onClick={() => setMethod(m)}
                className={cn(
                  'flex flex-col items-center gap-1 rounded-xl border-2 py-3 text-sm transition-colors',
                  method === m ? 'border-brand-500 bg-brand-50 text-brand-700' : 'border-line hover:border-slate-300'
                )}
              >
                <Icon name={m === 'CASH' ? 'Banknote' : m === 'CARD' ? 'CreditCard' : 'Wallet'} />
                {PAYMENT_LABELS[m]}
              </button>
            ))}
          </div>
        </div>

        <div>
          <p className="mb-1.5 text-[13px] font-medium text-slate-600">İndirim</p>
          <div className="mb-2 flex flex-wrap gap-1.5">
            <button onClick={() => { setDiscount(0); setCustom('') }} className={cn('rounded-full px-3 py-1 text-xs', discount === 0 ? 'bg-brand-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200')}>
              Yok
            </button>
            {(discounts.data ?? []).map((d) => (
              <button key={d.id} onClick={() => applyPreset(d)} className="rounded-full bg-slate-100 px-3 py-1 text-xs text-slate-600 hover:bg-slate-200">
                {d.name} ({d.kind === 'PERCENT' ? `%${d.value}` : formatMoney(d.value)})
              </button>
            ))}
          </div>
          <Input value={custom} onChange={(e) => applyCustom(e.target.value)} inputMode="decimal" placeholder="Özel indirim tutarı (₺)" aria-label="Özel indirim" />
        </div>
      </div>
    </Dialog>
  )
}

// ───────── Masa taşı / birleştir ─────────
function MoveDialog({ order, onClose, onMoved }: { order: OrderDTO; onClose: () => void; onMoved: (o: OrderDTO, merged: boolean) => void }) {
  const floor = useApi<FloorZoneDTO[]>('/api/floor')
  const [busy, setBusy] = useState(false)

  async function move(tableId: string) {
    setBusy(true)
    try {
      const res = await api.post<{ order: OrderDTO; merged: boolean }>(`/api/orders/${order.id}/move`, { tableId })
      onMoved(res.order, res.merged)
    } catch (e) {
      toast.error((e as Error).message)
      setBusy(false)
    }
  }

  return (
    <Dialog open onClose={onClose} title="Masayı değiştir" size="max-w-xl">
      <p className="mb-3 text-sm text-slate-500">Dolu bir masayı seçerseniz adisyonlar birleştirilir.</p>
      {floor.loading ? (
        <Spinner />
      ) : (
        <div className="space-y-4">
          {(floor.data ?? []).map((z) => (
            <section key={z.id}>
              <h3 className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-slate-400">{z.name}</h3>
              <div className="grid grid-cols-3 gap-2 sm:grid-cols-4">
                {z.tables
                  .filter((t) => t.id !== order.tableId)
                  .map((t) => (
                    <button
                      key={t.id}
                      disabled={busy}
                      onClick={() => move(t.id)}
                      className={cn(
                        'rounded-lg border p-2 text-sm transition-colors hover:border-brand-400',
                        t.order ? 'border-amber-300 bg-amber-50' : 'border-line'
                      )}
                    >
                      <span className="font-medium">{t.name}</span>
                      <span className="block text-xs text-slate-400">{t.order ? formatMoney(t.order.total) : 'Boş'}</span>
                    </button>
                  ))}
              </div>
            </section>
          ))}
        </div>
      )}
    </Dialog>
  )
}

// ───────── Adisyon notu ─────────
function NoteDialog({ order, templates, onClose, onSaved }: { templates: { id: string; name: string }[]; order: OrderDTO; onClose: () => void; onSaved: (o: OrderDTO) => void }) {
  const [note, setNote] = useState(order.note ?? '')
  const [busy, setBusy] = useState(false)

  async function save() {
    setBusy(true)
    try {
      onSaved(await api.patch<OrderDTO>(`/api/orders/${order.id}`, { note }))
    } catch (e) {
      toast.error((e as Error).message)
      setBusy(false)
    }
  }

  return (
    <Dialog
      open
      onClose={onClose}
      title="Adisyon notu"
      size="max-w-sm"
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>Vazgeç</Button>
          <Button onClick={save} disabled={busy}>Kaydet</Button>
        </>
      }
    >
      {templates.length > 0 && (
        <div className="mb-3 flex flex-wrap gap-1.5">
          {templates.map((t) => (
            <button key={t.id} type="button" onClick={() => setNote((n) => (n ? `${n}, ${t.name}` : t.name))} className="rounded-full bg-slate-100 px-3 py-1 text-xs text-slate-600 hover:bg-slate-200">
              + {t.name}
            </button>
          ))}
        </div>
      )}
      <Field label="Not">
        <Textarea value={note} onChange={(e) => setNote(e.target.value)} maxLength={300} autoFocus />
      </Field>
    </Dialog>
  )
}
