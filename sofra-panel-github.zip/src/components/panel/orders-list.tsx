'use client'

import { useMemo, useState } from 'react'
import Link from 'next/link'
import { useApi } from '@/hooks/use-api'
import { orderHref } from '@/lib/order-link'
import { formatMoney, formatDateTime } from '@/lib/format'
import { ORDER_TYPE_LABELS, ORDER_TYPES } from '@/lib/constants'
import type { OrderDTO } from '@/lib/types'
import { cn } from '@/lib/utils'
import { Icon } from '@/components/ui/icon'
import { Input, Select } from '@/components/ui/field'
import { Card, EmptyState, PageHeader, Spinner, StatusBadge } from '@/components/ui/misc'
import { useLive } from './live-provider'

const SCOPES = [
  { id: 'open', label: 'Açık' },
  { id: 'closed', label: 'Kapanan' },
  { id: 'all', label: 'Tümü' },
] as const

export function OrdersList() {
  const [scope, setScope] = useState<(typeof SCOPES)[number]['id']>('open')
  const [type, setType] = useState('')
  const [search, setSearch] = useState('')
  const url = `/api/orders?scope=${scope}${type ? `&type=${type}` : ''}`
  const { data, loading, reload } = useApi<OrderDTO[]>(url)

  useLive((e) => (e === null || e.type === 'orders') && void reload())

  const rows = useMemo(() => {
    const q = search.trim().toLocaleLowerCase('tr-TR')
    if (!q) return data ?? []
    return (data ?? []).filter((o) =>
      [String(o.number), o.tableName, o.customerName, o.note].some((v) => v?.toLocaleLowerCase('tr-TR').includes(q))
    )
  }, [data, search])

  return (
    <>
      <PageHeader title="Siparişler" subtitle="Son 300 sipariş gösterilir." />

      <div className="mb-4 flex flex-wrap items-center gap-2">
        <div className="flex rounded-lg bg-slate-100 p-1">
          {SCOPES.map((s) => (
            <button
              key={s.id}
              onClick={() => setScope(s.id)}
              className={cn('rounded-md px-3.5 py-1.5 text-sm transition-colors', scope === s.id ? 'bg-white font-medium shadow-sm' : 'text-slate-500')}
            >
              {s.label}
            </button>
          ))}
        </div>
        <Select value={type} onChange={(e) => setType(e.target.value)} className="w-36" aria-label="Sipariş türü">
          <option value="">Tüm türler</option>
          {ORDER_TYPES.map((t) => (
            <option key={t} value={t}>{ORDER_TYPE_LABELS[t]}</option>
          ))}
        </Select>
        <div className="relative">
          <Icon name="Search" size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="No, masa, müşteri…" className="w-56 pl-9" aria-label="Ara" />
        </div>
      </div>

      <Card className="overflow-hidden">
        {loading ? (
          <Spinner />
        ) : rows.length === 0 ? (
          <EmptyState icon="ReceiptText" text="Sipariş bulunamadı." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="border-b border-line bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-500">
                <tr>
                  <th className="px-4 py-2.5 font-medium">No</th>
                  <th className="px-4 py-2.5 font-medium">Tür</th>
                  <th className="px-4 py-2.5 font-medium">Masa / Müşteri</th>
                  <th className="px-4 py-2.5 font-medium">Durum</th>
                  <th className="px-4 py-2.5 font-medium">Zaman</th>
                  <th className="px-4 py-2.5 text-right font-medium">Tutar</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {rows.map((o) => (
                  <tr key={o.id} className="hover:bg-slate-50/70">
                    <td className="px-4 py-2.5 font-medium">
                      <Link href={orderHref(o)} className="text-brand-700 hover:underline">#{o.number}</Link>
                    </td>
                    <td className="px-4 py-2.5">{ORDER_TYPE_LABELS[o.type]}</td>
                    <td className="px-4 py-2.5">{o.tableName ?? o.customerName ?? '—'}</td>
                    <td className="px-4 py-2.5"><StatusBadge status={o.status} /></td>
                    <td className="px-4 py-2.5 text-slate-500">{formatDateTime(o.paidAt ?? o.createdAt)}</td>
                    <td className="px-4 py-2.5 text-right font-medium tabular-nums">{formatMoney(o.total)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </>
  )
}
