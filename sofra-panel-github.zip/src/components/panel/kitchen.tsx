'use client'

import { useEffect, useMemo, useState } from 'react'
import { toast } from 'sonner'
import { api } from '@/lib/api-client'
import { useApi } from '@/hooks/use-api'
import { minutesAgo } from '@/lib/format'
import { ORDER_STATUS_LABELS, ORDER_TYPE_LABELS, type OrderStatus } from '@/lib/constants'
import type { OrderDTO } from '@/lib/types'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Select } from '@/components/ui/field'
import { PageHeader, Spinner } from '@/components/ui/misc'
import { useLive } from './live-provider'

const COLUMNS: { status: OrderStatus; tone: string }[] = [
  { status: 'NEW', tone: 'border-sky-300 bg-sky-50' },
  { status: 'PREPARING', tone: 'border-amber-300 bg-amber-50' },
  { status: 'READY', tone: 'border-emerald-300 bg-emerald-50' },
]

const NEXT: Partial<Record<OrderStatus, { to: OrderStatus; label: string }>> = {
  NEW: { to: 'PREPARING', label: 'Hazırlamaya başla' },
  PREPARING: { to: 'READY', label: 'Hazır' },
  READY: { to: 'SERVED', label: 'Servis edildi' },
}

/** canServe=false (mutfak rolü) ise "Servis edildi" düğmesi gösterilmez. */
export function Kitchen({ canServe }: { canServe: boolean }) {
  const orders = useApi<OrderDTO[]>('/api/orders?scope=kitchen')
  const groups = useApi<{ id: string; name: string }[]>('/api/r/kitchen-groups')
  const [group, setGroup] = useState('')
  const [, tick] = useState(0)

  useLive((e) => (e === null || e.type === 'orders') && void orders.reload())
  useEffect(() => {
    const t = setInterval(() => tick((n) => n + 1), 30_000) // geçen süreleri tazele
    return () => clearInterval(t)
  }, [])

  // Mutfak grubu seçiliyse yalnızca o gruptaki kalemler gösterilir
  const visible = useMemo(
    () =>
      (orders.data ?? [])
        .map((o) => ({ ...o, items: group ? o.items.filter((i) => i.kitchenGroupId === group) : o.items }))
        .filter((o) => o.items.length > 0),
    [orders.data, group]
  )

  async function advance(o: OrderDTO, to: OrderStatus) {
    try {
      await api.patch(`/api/orders/${o.id}`, { status: to })
      await orders.reload()
    } catch (e) {
      toast.error((e as Error).message)
    }
  }

  return (
    <>
      <PageHeader
        title="Mutfak"
        subtitle="Bekleyen siparişler eskiden yeniye sıralanır."
        actions={
          (groups.data?.length ?? 0) > 0 ? (
            <Select value={group} onChange={(e) => setGroup(e.target.value)} className="w-48" aria-label="Mutfak grubu">
              <option value="">Tüm gruplar</option>
              {groups.data!.map((g) => (
                <option key={g.id} value={g.id}>{g.name}</option>
              ))}
            </Select>
          ) : undefined
        }
      />

      {orders.loading ? (
        <Spinner />
      ) : (
        <div className="grid gap-4 lg:grid-cols-3">
          {COLUMNS.map(({ status, tone }) => {
            const list = visible.filter((o) => o.status === status)
            return (
              <section key={status}>
                <h2 className="mb-2 flex items-center gap-2 text-sm font-semibold">
                  {ORDER_STATUS_LABELS[status]}
                  <span className="rounded-full bg-slate-200 px-2 py-0.5 text-xs font-medium text-slate-600">{list.length}</span>
                </h2>
                <div className="space-y-3">
                  {list.length === 0 && <p className="rounded-xl border border-dashed border-line py-8 text-center text-sm text-slate-400">Boş</p>}
                  {list.map((o) => {
                    const mins = minutesAgo(o.createdAt)
                    const next = NEXT[o.status]
                    return (
                      <article key={o.id} className={cn('rounded-xl border-2 p-3', tone)}>
                        <header className="mb-2 flex items-center justify-between">
                          <span className="font-semibold">
                            #{o.number} · {o.tableName ?? ORDER_TYPE_LABELS[o.type]}
                          </span>
                          <span className={cn('text-xs tabular-nums', mins >= 15 ? 'font-semibold text-rose-600' : 'text-slate-500')}>{mins} dk</span>
                        </header>
                        <ul className="space-y-1">
                          {o.items.map((i) => (
                            <li key={i.id} className="text-sm">
                              <span className="font-semibold tabular-nums">{i.quantity}×</span> {i.name}
                              {i.note && <span className="block pl-6 text-xs text-amber-700">↳ {i.note}</span>}
                            </li>
                          ))}
                        </ul>
                        {o.note && <p className="mt-2 rounded-md bg-white/70 px-2 py-1 text-xs text-slate-600">Not: {o.note}</p>}
                        {next && (next.to !== 'SERVED' || canServe) && (
                          <Button size="sm" className="mt-3 w-full" onClick={() => advance(o, next.to)}>
                            {next.label}
                          </Button>
                        )}
                      </article>
                    )
                  })}
                </div>
              </section>
            )
          })}
        </div>
      )}
    </>
  )
}
