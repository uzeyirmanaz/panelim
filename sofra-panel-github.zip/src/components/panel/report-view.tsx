'use client'

import { useMemo, useState } from 'react'
import { useApi } from '@/hooks/use-api'
import { dayKey, formatDate, formatMoney, formatNumber } from '@/lib/format'
import { Button } from '@/components/ui/button'
import { Field, Input } from '@/components/ui/field'
import { Icon } from '@/components/ui/icon'
import { Bar, Card, EmptyState, PageHeader, Spinner } from '@/components/ui/misc'

export type ReportType = 'urun-satis' | 'gun-sonu' | 'vardiya' | 'istatistik' | 'fire' | 'maliyet'

export const REPORT_TITLES: Record<ReportType, string> = {
  'urun-satis': 'Ürün Satış Raporu',
  'gun-sonu': 'Gün Sonu Raporu',
  vardiya: 'Vardiya Satış Raporu',
  istatistik: 'Restoran İstatistikleri',
  fire: 'Fire Raporu',
  maliyet: 'Maliyet-Karlılık Raporu',
}
const TITLES = REPORT_TITLES

const daysAgo = (n: number) => {
  const d = new Date()
  d.setDate(d.getDate() - n)
  return dayKey(d)
}

export function ReportView({ type }: { type: ReportType }) {
  const [range, setRange] = useState(() => ({ from: type === 'gun-sonu' ? daysAgo(6) : daysAgo(0), to: daysAgo(0) }))
  const { data, loading, error } = useApi<Record<string, any>>(`/api/reports/${type}?from=${range.from}&to=${range.to}`) // eslint-disable-line @typescript-eslint/no-explicit-any

  const presets = useMemo(() => {
    const now = new Date()
    return [
      { label: 'Bugün', from: daysAgo(0), to: daysAgo(0) },
      { label: 'Dün', from: daysAgo(1), to: daysAgo(1) },
      { label: 'Son 7 gün', from: daysAgo(6), to: daysAgo(0) },
      { label: 'Son 30 gün', from: daysAgo(29), to: daysAgo(0) },
      { label: 'Bu ay', from: dayKey(new Date(now.getFullYear(), now.getMonth(), 1)), to: daysAgo(0) },
    ]
  }, [])

  return (
    <>
      <PageHeader
        title={TITLES[type]}
        subtitle={`${formatDate(`${range.from}T12:00:00`)} – ${formatDate(`${range.to}T12:00:00`)}`}
        actions={
          <Button variant="secondary" onClick={() => window.print()} className="no-print">
            <Icon name="ReceiptText" size={16} /> Yazdır
          </Button>
        }
      />

      <Card className="no-print mb-4 flex flex-wrap items-end gap-3 p-4">
        <Field label="Başlangıç">
          <Input type="date" value={range.from} max={range.to} onChange={(e) => e.target.value && setRange((r) => ({ ...r, from: e.target.value }))} />
        </Field>
        <Field label="Bitiş">
          <Input type="date" value={range.to} min={range.from} onChange={(e) => e.target.value && setRange((r) => ({ ...r, to: e.target.value }))} />
        </Field>
        <div className="flex flex-wrap gap-1.5">
          {presets.map((p) => (
            <button
              key={p.label}
              onClick={() => setRange({ from: p.from, to: p.to })}
              className="rounded-full bg-slate-100 px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-200"
            >
              {p.label}
            </button>
          ))}
        </div>
      </Card>

      {loading ? (
        <Spinner />
      ) : error || !data ? (
        <Card><EmptyState icon="BarChart3" text={error ?? 'Rapor yüklenemedi.'} /></Card>
      ) : type === 'gun-sonu' ? (
        <DaySummary data={data} />
      ) : type === 'vardiya' ? (
        <Shifts data={data} />
      ) : type === 'istatistik' ? (
        <Stats data={data} />
      ) : type === 'fire' ? (
        <Waste data={data} />
      ) : (
        <Ranking data={data} showCategory={type === 'urun-satis'} note={type === 'maliyet' ? 'Ürün maliyeti girilmediği için kategori bazında ciro payı gösterilir.' : undefined} />
      )}
    </>
  )
}

function Stat({ label, value, tone }: { label: string; value: string; tone?: string }) {
  return (
    <Card className="p-4">
      <p className="text-[13px] text-slate-500">{label}</p>
      <p className={`mt-1 text-xl font-semibold tabular-nums ${tone ?? ''}`}>{value}</p>
    </Card>
  )
}

/* eslint-disable @typescript-eslint/no-explicit-any */
function DaySummary({ data }: { data: any }) {
  const t = data.totals
  if (data.rows.length === 0) return <Card><EmptyState icon="CalendarCheck" text="Seçilen aralıkta kayıt yok." /></Card>
  return (
    <>
      <div className="mb-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label="Ciro" value={formatMoney(t.revenue)} />
        <Stat label="Gider + zayi" value={formatMoney(t.expenses + t.wasteCost)} tone="text-rose-600" />
        <Stat label="Net" value={formatMoney(t.net)} tone={t.net < 0 ? 'text-rose-600' : 'text-emerald-600'} />
        <Stat label="Adisyon" value={formatNumber(t.orders)} />
      </div>
      <Card className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="border-b border-line bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-500">
            <tr>
              <th className="px-4 py-2.5 font-medium">Gün</th>
              <th className="px-4 py-2.5 text-right font-medium">Adisyon</th>
              <th className="px-4 py-2.5 text-right font-medium">Nakit</th>
              <th className="px-4 py-2.5 text-right font-medium">Kart</th>
              <th className="px-4 py-2.5 text-right font-medium">Diğer</th>
              <th className="px-4 py-2.5 text-right font-medium">İndirim</th>
              <th className="px-4 py-2.5 text-right font-medium">Gider</th>
              <th className="px-4 py-2.5 text-right font-medium">Ciro</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line tabular-nums">
            {data.rows.map((r: any) => (
              <tr key={r.date}>
                <td className="px-4 py-2.5 font-medium">{formatDate(`${r.date}T12:00:00`)}</td>
                <td className="px-4 py-2.5 text-right">{r.orders}</td>
                <td className="px-4 py-2.5 text-right">{formatMoney(r.cash)}</td>
                <td className="px-4 py-2.5 text-right">{formatMoney(r.card)}</td>
                <td className="px-4 py-2.5 text-right">{formatMoney(r.other)}</td>
                <td className="px-4 py-2.5 text-right text-slate-500">{formatMoney(r.discount)}</td>
                <td className="px-4 py-2.5 text-right text-rose-600">{formatMoney(r.expenses)}</td>
                <td className="px-4 py-2.5 text-right font-semibold">{formatMoney(r.revenue)}</td>
              </tr>
            ))}
          </tbody>
          <tfoot className="border-t-2 border-line bg-slate-50 font-semibold tabular-nums">
            <tr>
              <td className="px-4 py-2.5">Toplam</td>
              <td className="px-4 py-2.5 text-right">{t.orders}</td>
              <td className="px-4 py-2.5 text-right">{formatMoney(t.cash)}</td>
              <td className="px-4 py-2.5 text-right">{formatMoney(t.card)}</td>
              <td className="px-4 py-2.5 text-right">{formatMoney(t.other)}</td>
              <td className="px-4 py-2.5 text-right">{formatMoney(t.discount)}</td>
              <td className="px-4 py-2.5 text-right">{formatMoney(t.expenses)}</td>
              <td className="px-4 py-2.5 text-right">{formatMoney(t.revenue)}</td>
            </tr>
          </tfoot>
        </table>
      </Card>
      {t.wasteCost > 0 && <p className="mt-2 text-xs text-slate-400">Net hesabına {formatMoney(t.wasteCost)} zayi maliyeti dahildir.</p>}
    </>
  )
}

function Ranking({ data, showCategory, note }: { data: any; showCategory: boolean; note?: string }) {
  if (data.rows.length === 0) return <Card><EmptyState icon="BarChart3" text="Seçilen aralıkta satış yok." /></Card>
  return (
    <>
      <div className="mb-4 grid gap-3 sm:grid-cols-3">
        <Stat label="Toplam ciro" value={formatMoney(data.totalRevenue)} />
        {data.totalQuantity !== undefined && <Stat label="Satılan adet" value={formatNumber(data.totalQuantity)} />}
        <Stat label="Adisyon" value={formatNumber(data.orderCount)} />
      </div>
      {note && <p className="mb-3 text-xs text-slate-400">{note}</p>}
      <Card className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="border-b border-line bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-500">
            <tr>
              <th className="px-4 py-2.5 font-medium">{showCategory ? 'Ürün' : 'Kategori'}</th>
              {showCategory && <th className="px-4 py-2.5 font-medium">Kategori</th>}
              <th className="px-4 py-2.5 text-right font-medium">Adet</th>
              <th className="px-4 py-2.5 text-right font-medium">Tutar</th>
              <th className="w-44 px-4 py-2.5 font-medium">Pay</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line tabular-nums">
            {data.rows.map((r: any) => (
              <tr key={r.name}>
                <td className="px-4 py-2.5 font-medium">{r.name}</td>
                {showCategory && <td className="px-4 py-2.5 text-slate-500">{r.category}</td>}
                <td className="px-4 py-2.5 text-right">{formatNumber(r.quantity)}</td>
                <td className="px-4 py-2.5 text-right font-medium">{formatMoney(r.revenue)}</td>
                <td className="px-4 py-2.5">
                  <div className="flex items-center gap-2">
                    <Bar value={r.revenue} max={data.rows[0].revenue} className="flex-1" />
                    <span className="w-9 text-right text-xs text-slate-400">{data.totalRevenue ? Math.round((r.revenue / data.totalRevenue) * 100) : 0}%</span>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </>
  )
}

function Shifts({ data }: { data: any }) {
  if (data.orderCount === 0) return <Card><EmptyState icon="Clock" text="Seçilen aralıkta satış yok." /></Card>
  const max = Math.max(...data.rows.map((r: any) => r.revenue), 1)
  return (
    <>
      <div className="mb-4 grid gap-3 sm:grid-cols-2">
        <Stat label="Toplam ciro" value={formatMoney(data.totalRevenue)} />
        <Stat label="Adisyon" value={formatNumber(data.orderCount)} />
      </div>
      <Card className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="border-b border-line bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-500">
            <tr>
              <th className="px-4 py-2.5 font-medium">Vardiya</th>
              <th className="px-4 py-2.5 text-right font-medium">Adisyon</th>
              <th className="px-4 py-2.5 text-right font-medium">Ciro</th>
              <th className="w-48 px-4 py-2.5 font-medium">Pay</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line tabular-nums">
            {data.rows.map((r: any) => (
              <tr key={r.name}>
                <td className="px-4 py-2.5 font-medium">{r.name}</td>
                <td className="px-4 py-2.5 text-right">{r.orders}</td>
                <td className="px-4 py-2.5 text-right font-medium">{formatMoney(r.revenue)}</td>
                <td className="px-4 py-2.5"><Bar value={r.revenue} max={max} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </>
  )
}

const TYPE_LABELS: Record<string, string> = { TABLE: 'Masa', DELIVERY: 'Paket', PICKUP: 'Gel-Al' }

function Stats({ data }: { data: any }) {
  if (data.orderCount === 0) return <Card><EmptyState icon="BarChart3" text="Seçilen aralıkta satış yok." /></Card>
  const max = Math.max(...data.hours.map((r: any) => r.revenue), 1)
  const zoneMax = Math.max(...data.byZone.map((z: any) => z.revenue), 1)
  return (
    <>
      <div className="mb-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label="Toplam ciro" value={formatMoney(data.totalRevenue)} />
        <Stat label="Adisyon" value={formatNumber(data.orderCount)} />
        <Stat label="Ortalama adisyon" value={formatMoney(data.average)} />
        <Stat label="En yoğun saat" value={data.busiestHour === null ? '—' : `${String(data.busiestHour).padStart(2, '0')}:00`} />
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="p-4">
          <h2 className="mb-3 text-sm font-semibold">Sipariş türü</h2>
          <ul className="space-y-3">
            {Object.entries(data.byType).map(([k, v]: [string, any]) => (
              <li key={k}>
                <div className="mb-1 flex justify-between text-sm">
                  <span className="font-medium">{TYPE_LABELS[k]}</span>
                  <span className="tabular-nums text-slate-500">{v.orders} adisyon · {formatMoney(v.revenue)}</span>
                </div>
                <Bar value={v.revenue} max={data.totalRevenue} />
              </li>
            ))}
          </ul>
        </Card>
        <Card className="p-4">
          <h2 className="mb-3 text-sm font-semibold">Bölge dağılımı</h2>
          <ul className="space-y-3">
            {data.byZone.map((z: any) => (
              <li key={z.zone}>
                <div className="mb-1 flex justify-between text-sm">
                  <span className="font-medium">{z.zone}</span>
                  <span className="tabular-nums text-slate-500">{formatMoney(z.revenue)}</span>
                </div>
                <Bar value={z.revenue} max={zoneMax} />
              </li>
            ))}
          </ul>
        </Card>
        <Card className="p-4 lg:col-span-2">
          <h2 className="mb-3 text-sm font-semibold">Saatlik satış</h2>
          <div className="flex h-44 items-end gap-1">
            {data.hours.map((r: any) => (
              <div key={r.hour} className="flex flex-1 flex-col items-center gap-1" title={`${String(r.hour).padStart(2, '0')}:00 — ${formatMoney(r.revenue)} · ${r.orders} adisyon`}>
                <div className="flex w-full flex-1 items-end">
                  <div className="w-full rounded-t bg-brand-500/90" style={{ height: `${r.revenue > 0 ? Math.max(4, (r.revenue / max) * 100) : 0}%` }} />
                </div>
                <span className="text-[10px] text-slate-400">{String(r.hour).padStart(2, '0')}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </>
  )
}

function Waste({ data }: { data: any }) {
  if (data.rows.length === 0) return <Card><EmptyState icon="PackageX" text="Seçilen aralıkta zayi kaydı yok." /></Card>
  return (
    <>
      <div className="mb-4 grid gap-3 sm:grid-cols-3">
        <Stat label="Toplam zayi maliyeti" value={formatMoney(data.totalCost)} tone="text-rose-600" />
        <Stat label="Toplam miktar" value={formatNumber(data.totalQuantity)} />
        <Stat label="Kayıt" value={formatNumber(data.recordCount)} />
      </div>
      <Card className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="border-b border-line bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-500">
            <tr>
              <th className="px-4 py-2.5 font-medium">Ürün / malzeme</th>
              <th className="px-4 py-2.5 text-right font-medium">Kayıt</th>
              <th className="px-4 py-2.5 text-right font-medium">Miktar</th>
              <th className="px-4 py-2.5 text-right font-medium">Maliyet</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line tabular-nums">
            {data.rows.map((r: any) => (
              <tr key={r.name}>
                <td className="px-4 py-2.5 font-medium">{r.name}</td>
                <td className="px-4 py-2.5 text-right">{r.count}</td>
                <td className="px-4 py-2.5 text-right">{formatNumber(r.quantity)}</td>
                <td className="px-4 py-2.5 text-right font-medium">{formatMoney(r.cost)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </>
  )
}
