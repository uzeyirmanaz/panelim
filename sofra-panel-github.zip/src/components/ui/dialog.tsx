'use client'

import { useEffect, useRef, type ReactNode } from 'react'
import { Icon } from './icon'
import { cn } from '@/lib/utils'

type Props = {
  open: boolean
  onClose: () => void
  title: string
  children: ReactNode
  footer?: ReactNode
  /** Tailwind max-width sınıfı */
  size?: string
}

/** Yerel <dialog>: odak tuzağı, Esc ile kapanma ve erişilebilirlik tarayıcıdan gelir. */
export function Dialog({ open, onClose, title, children, footer, size = 'max-w-lg' }: Props) {
  const ref = useRef<HTMLDialogElement>(null)

  useEffect(() => {
    const el = ref.current
    if (!el) return
    if (open && !el.open) el.showModal()
    if (!open && el.open) el.close()
  }, [open])

  return (
    <dialog
      ref={ref}
      onClose={onClose}
      onClick={(e) => e.target === ref.current && onClose()}
      className="w-full p-3 sm:p-6"
      aria-label={title}
    >
      {open && (
        <div className={cn('mx-auto flex max-h-[calc(100dvh-3rem)] w-full flex-col rounded-2xl bg-white shadow-2xl', size)}>
          <header className="flex items-center justify-between border-b border-line px-5 py-3.5">
            <h2 className="text-base font-semibold">{title}</h2>
            <button onClick={onClose} className="rounded-md p-1 text-slate-400 hover:bg-slate-100 hover:text-slate-600" aria-label="Kapat">
              <Icon name="X" />
            </button>
          </header>
          <div className="scroll-thin overflow-y-auto px-5 py-4">{children}</div>
          {footer && <footer className="flex justify-end gap-2 border-t border-line px-5 py-3">{footer}</footer>}
        </div>
      )}
    </dialog>
  )
}
