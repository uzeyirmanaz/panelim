import {
  Activity, CheckCircle2, LineChart, Link2, MoreVertical, Armchair, ArrowLeft, BadgePercent, BarChart3, Banknote, Bell, CalendarCheck, Check, ChefHat, ChevronDown,
  ChevronRight, ClipboardCheck, Clock, Contact, Copy, CreditCard, EllipsisVertical, ExternalLink, Flame, Gift, HandCoins,
  Home, Inbox, Layers, LayoutGrid, ListChecks, ListPlus, List, LogOut, Map as MapIcon, Menu, Minus, Package, PackageX,
  Pencil, Percent, PieChart, Plus, Puzzle, QrCode, ReceiptText, RefreshCw, Ruler, Search, Settings, ShieldCheck,
  ShoppingBag, ShoppingBasket, Sparkles, StickyNote, Store, Tags, Trash2, TrendingDown, TrendingUp, Truck, UserCog,
  Users, UtensilsCrossed, Wallet, Wifi, WifiOff, X, ArrowRightLeft, Download, type LucideIcon,
} from 'lucide-react'

// Yalnızca kullanılan ikonlar paketlenir (tüm kütüphane istemciye gitmez).
const ICONS = {
  Activity, CheckCircle2, LineChart, Link2, MoreVertical, Armchair, ArrowLeft, BadgePercent, BarChart3, Banknote, Bell, CalendarCheck, Check, ChefHat, ChevronDown,
  ChevronRight, ClipboardCheck, Clock, Contact, Copy, CreditCard, EllipsisVertical, ExternalLink, Flame, Gift, HandCoins,
  Home, Inbox, Layers, LayoutGrid, ListChecks, ListPlus, List, LogOut, Map: MapIcon, Menu, Minus, Package, PackageX,
  Pencil, Percent, PieChart, Plus, Puzzle, QrCode, ReceiptText, RefreshCw, Ruler, Search, Settings, ShieldCheck,
  ShoppingBag, ShoppingBasket, Sparkles, StickyNote, Store, Tags, Trash2, TrendingDown, TrendingUp, Truck, UserCog,
  Users, UtensilsCrossed, Wallet, Wifi, WifiOff, X, ArrowRightLeft, Download,
} satisfies Record<string, LucideIcon>

export type IconName = keyof typeof ICONS

export function Icon({ name, className, size = 18 }: { name: string; className?: string; size?: number }) {
  const Cmp = (ICONS as Record<string, LucideIcon>)[name] ?? Inbox
  return <Cmp className={className} size={size} aria-hidden />
}
