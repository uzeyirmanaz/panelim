import type { ReactNode } from 'react'
import { cn } from '@/lib/utils'
import { Icon } from './icon'
import { ORDER_STATUS_LABELS, type OrderStatus } from '@/lib/constants'

export function PageHeader({ title, subtitle, actions }: { title: string; subtitle?: string; actions?: ReactNode }) {
  return (
    <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
      <div>
        <h1 className="text-xl font-semibold tracking-tight">{title}</h1>
        {subtitle && <p className="mt-0.5 text-sm text-slate-500">{subtitle}</p>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  )
}

export function Card({ className, children }: { className?: string; children: ReactNode }) {
  return <section className={cn('rounded-xl border border-line bg-white', className)}>{children}</section>
}

export function EmptyState({ icon = 'Inbox', text }: { icon?: string; text: string }) {
  return (
    <div className="flex flex-col items-center gap-2 py-14 text-slate-400">
      <Icon name={icon} size={36} />
      <p className="text-sm">{text}</p>
    </div>
  )
}

export function Spinner({ label = 'Yükleniyor…' }: { label?: string }) {
  return <p className="py-12 text-center text-sm text-slate-400">{label}</p>
}

const TONES = {
  slate: 'bg-slate-100 text-slate-600',
  green: 'bg-emerald-50 text-emerald-700',
  amber: 'bg-amber-50 text-amber-700',
  blue: 'bg-sky-50 text-sky-700',
  rose: 'bg-rose-50 text-rose-700',
  brand: 'bg-brand-50 text-brand-700',
}
export type Tone = keyof typeof TONES

export function Badge({ tone = 'slate', children }: { tone?: Tone; children: ReactNode }) {
  return <span className={cn('inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium', TONES[tone])}>{children}</span>
}

export const STATUS_TONE: Record<OrderStatus, Tone> = {
  NEW: 'blue',
  PREPARING: 'amber',
  READY: 'green',
  SERVED: 'brand',
  PAID: 'slate',
  CANCELLED: 'rose',
}

export function StatusBadge({ status }: { status: OrderStatus }) {
  return <Badge tone={STATUS_TONE[status]}>{ORDER_STATUS_LABELS[status]}</Badge>
}

/** Sağda toplamı olan basit yatay çubuk (grafik kütüphanesi gerektirmez) */
export function Bar({ value, max, className }: { value: number; max: number; className?: string }) {
  const pct = max > 0 ? Math.max(2, Math.round((value / max) * 100)) : 0
  return (
    <div className={cn('h-2 overflow-hidden rounded-full bg-slate-100', className)}>
      <div className="h-full rounded-full bg-brand-500" style={{ width: `${value > 0 ? pct : 0}%` }} />
    </div>
  )
}
