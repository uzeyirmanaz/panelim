// İstemci + sunucu ortak sabitler. Prisma enum'larıyla birebir aynı değerleri taşır
// (istemci paketine @prisma/client dahil etmemek için ayrıca tanımlanır).

export const ROLES = ['ADMIN', 'CASHIER', 'KITCHEN'] as const
export type Role = (typeof ROLES)[number]
export const ROLE_LABELS: Record<Role, string> = {
  ADMIN: 'Yönetici',
  CASHIER: 'Personel',
  KITCHEN: 'Mutfak',
}

export const ORDER_TYPES = ['TABLE', 'DELIVERY', 'PICKUP'] as const
export type OrderType = (typeof ORDER_TYPES)[number]
export const ORDER_TYPE_LABELS: Record<OrderType, string> = {
  TABLE: 'Masa',
  DELIVERY: 'Paket',
  PICKUP: 'Gel-Al',
}

export const ORDER_STATUSES = ['NEW', 'PREPARING', 'READY', 'SERVED', 'PAID', 'CANCELLED'] as const
export type OrderStatus = (typeof ORDER_STATUSES)[number]
export const ORDER_STATUS_LABELS: Record<OrderStatus, string> = {
  NEW: 'Yeni',
  PREPARING: 'Hazırlanıyor',
  READY: 'Hazır',
  SERVED: 'Servis Edildi',
  PAID: 'Ödendi',
  CANCELLED: 'İptal',
}
/** Açık (henüz kapanmamış) adisyon durumları */
export const OPEN_STATUSES: OrderStatus[] = ['NEW', 'PREPARING', 'READY', 'SERVED']

export const PAYMENT_METHODS = ['CASH', 'CARD', 'OTHER'] as const
export type PaymentMethod = (typeof PAYMENT_METHODS)[number]
export const PAYMENT_LABELS: Record<PaymentMethod, string> = {
  CASH: 'Nakit',
  CARD: 'Kart',
  OTHER: 'Diğer',
}

export const DISCOUNT_KINDS = ['PERCENT', 'AMOUNT'] as const
export type DiscountKind = (typeof DISCOUNT_KINDS)[number]
