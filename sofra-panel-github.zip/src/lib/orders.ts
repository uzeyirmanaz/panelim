import 'server-only'
import { Prisma, type PaymentMethod as PrismaPayment } from '@prisma/client'
import { db } from './db'
import { HttpError } from './http'
import { publish } from './events'
import { OPEN_STATUSES, type OrderStatus, type OrderType } from './constants'
import type { OrderDTO } from './types'

// ───────── Seçim & dönüştürme ─────────
export const orderInclude = {
  items: {
    orderBy: { createdAt: 'asc' },
    include: { product: { select: { kitchenGroupId: true } } },
  },
} satisfies Prisma.OrderInclude

type OrderRow = Prisma.OrderGetPayload<{ include: typeof orderInclude }>

export function toOrderDTO(o: OrderRow): OrderDTO {
  return {
    id: o.id,
    number: o.number,
    type: o.type,
    status: o.status,
    tableId: o.tableId,
    tableName: o.tableName,
    customerId: o.customerId,
    customerName: o.customerName,
    note: o.note,
    guests: o.guests,
    subtotal: o.subtotal,
    discountTotal: o.discountTotal,
    total: o.total,
    paymentMethod: o.paymentMethod,
    paidAt: o.paidAt?.toISOString() ?? null,
    createdAt: o.createdAt.toISOString(),
    items: o.items.map((i) => ({
      id: i.id,
      productId: i.productId,
      name: i.name,
      unitPrice: i.unitPrice,
      quantity: i.quantity,
      note: i.note,
      kitchenGroupId: i.product?.kitchenGroupId ?? null,
    })),
  }
}

type Tx = Prisma.TransactionClient

async function load(tx: Tx, id: string): Promise<OrderRow> {
  const order = await tx.order.findUnique({ where: { id }, include: orderInclude })
  if (!order) throw new HttpError(404, 'Sipariş bulunamadı.')
  return order
}

function assertOpen(order: { status: OrderStatus }) {
  if (order.status === 'PAID' || order.status === 'CANCELLED') {
    throw new HttpError(409, 'Kapanmış adisyon değiştirilemez.')
  }
}

/** Ara toplamı kalemlerden yeniden hesaplar; indirim ara toplamı aşamaz. */
async function recalc(tx: Tx, orderId: string, discountTotal?: number) {
  const items = await tx.orderItem.findMany({ where: { orderId }, select: { unitPrice: true, quantity: true } })
  const subtotal = items.reduce((s, i) => s + i.unitPrice * i.quantity, 0)
  const current = discountTotal ?? (await tx.order.findUniqueOrThrow({ where: { id: orderId } })).discountTotal
  const discount = Math.min(Math.max(0, current), subtotal)
  await tx.order.update({
    where: { id: orderId },
    data: { subtotal, discountTotal: discount, total: subtotal - discount },
  })
}

async function nextNumber(tx: Tx): Promise<number> {
  const last = await tx.order.aggregate({ _max: { number: true } })
  return (last._max.number ?? 0) + 1
}

// ───────── Kalem çözümleme ─────────
export type NewItem = { productId: string; quantity: number; note?: string | null }

async function resolveItems(tx: Tx, items: NewItem[]) {
  const ids = [...new Set(items.map((i) => i.productId))]
  const products = await tx.product.findMany({ where: { id: { in: ids } } })
  const byId = new Map(products.map((p) => [p.id, p]))
  return items.map((i) => {
    const p = byId.get(i.productId)
    if (!p) throw new HttpError(400, 'Ürün bulunamadı.')
    if (!p.available) throw new HttpError(409, `"${p.name}" şu an satışta değil.`)
    return {
      productId: p.id,
      name: p.name,
      unitPrice: p.price,
      quantity: i.quantity,
      note: i.note?.trim() || null,
    }
  })
}

const emit = (order: { id: string; tableId: string | null }) =>
  publish({ type: 'orders', orderId: order.id, tableId: order.tableId ?? undefined })

// ───────── Servisler ─────────
export async function createOrder(
  input: {
    type: OrderType
    tableId?: string | null
    customerId?: string | null
    customerName?: string | null
    note?: string | null
    guests?: number | null
    items: NewItem[]
  },
  userId: string
): Promise<OrderDTO> {
  // Sipariş numarası max+1 ile üretildiği için eşzamanlı iki kayıtta çakışma olabilir; birkaç kez yeniden dene.
  for (let attempt = 0; ; attempt++) {
    try {
      return await createOrderOnce(input, userId)
    } catch (e) {
      const collision = e instanceof Prisma.PrismaClientKnownRequestError && (e.code === 'P2002' || e.code === 'P2034')
      if (!collision || attempt >= 3) throw e
    }
  }
}

async function createOrderOnce(
  input: Parameters<typeof createOrder>[0],
  userId: string
): Promise<OrderDTO> {
  const created = await db.$transaction(async (tx) => {
    let tableName: string | null = null
    if (input.type === 'TABLE') {
      if (!input.tableId) throw new HttpError(400, 'Masa seçilmeli.')
      const table = await tx.table.findUnique({ where: { id: input.tableId } })
      if (!table) throw new HttpError(404, 'Masa bulunamadı.')
      const open = await tx.order.findFirst({
        where: { tableId: table.id, status: { in: OPEN_STATUSES } },
        select: { id: true },
      })
      if (open) throw new HttpError(409, 'Bu masada zaten açık bir adisyon var.', { orderId: open.id })
      tableName = table.name
    }

    let customerName = input.customerName?.trim() || null
    if (input.customerId) {
      const c = await tx.customer.findUnique({ where: { id: input.customerId } })
      if (!c) throw new HttpError(404, 'Müşteri bulunamadı.')
      customerName = customerName ?? c.name
    }

    const rows = await resolveItems(tx, input.items)
    const order = await tx.order.create({
      data: {
        number: await nextNumber(tx),
        type: input.type,
        tableId: input.type === 'TABLE' ? input.tableId : null,
        tableName,
        customerId: input.customerId || null,
        customerName,
        note: input.note?.trim() || null,
        guests: input.guests ?? null,
        createdById: userId,
        items: { create: rows },
      },
    })
    await recalc(tx, order.id)
    return load(tx, order.id)
  })
  emit(created)
  return toOrderDTO(created)
}

export async function addItems(orderId: string, items: NewItem[]): Promise<OrderDTO> {
  const updated = await db.$transaction(async (tx) => {
    const order = await load(tx, orderId)
    assertOpen(order)
    const rows = await resolveItems(tx, items)
    await tx.orderItem.createMany({ data: rows.map((r) => ({ ...r, orderId })) })
    // Yeni ürün eklenince mutfağın görmesi için adisyon yeniden "Yeni" olur.
    await tx.order.update({ where: { id: orderId }, data: { status: 'NEW' } })
    await recalc(tx, orderId)
    return load(tx, orderId)
  })
  emit(updated)
  return toOrderDTO(updated)
}

export async function updateItem(
  orderId: string,
  itemId: string,
  patch: { quantity?: number; note?: string | null }
): Promise<OrderDTO> {
  const updated = await db.$transaction(async (tx) => {
    assertOpen(await load(tx, orderId))
    const item = await tx.orderItem.findFirst({ where: { id: itemId, orderId } })
    if (!item) throw new HttpError(404, 'Kalem bulunamadı.')
    if (patch.quantity !== undefined && patch.quantity <= 0) {
      await tx.orderItem.delete({ where: { id: itemId } })
    } else {
      await tx.orderItem.update({
        where: { id: itemId },
        data: {
          ...(patch.quantity !== undefined ? { quantity: patch.quantity } : {}),
          ...(patch.note !== undefined ? { note: patch.note?.trim() || null } : {}),
        },
      })
    }
    await recalc(tx, orderId)
    return load(tx, orderId)
  })
  emit(updated)
  return toOrderDTO(updated)
}

export async function removeItem(orderId: string, itemId: string) {
  return updateItem(orderId, itemId, { quantity: 0 })
}

/** Mutfağın dokunabildiği durumlar: servis edilmiş bir adisyonu mutfak geri çeviremez. */
const KITCHEN_EDITABLE: OrderStatus[] = ['NEW', 'PREPARING', 'READY']

export async function setStatus(
  orderId: string,
  status: OrderStatus,
  opts: { kitchenOnly?: boolean } = {}
): Promise<OrderDTO> {
  if (status === 'PAID') throw new HttpError(400, 'Ödeme için /pay kullanın.')
  if (status === 'CANCELLED') throw new HttpError(400, 'İptal için adisyonu iptal edin.')
  const updated = await db.$transaction(async (tx) => {
    const current = await load(tx, orderId)
    assertOpen(current)
    if (opts.kitchenOnly && !KITCHEN_EDITABLE.includes(current.status)) {
      throw new HttpError(409, 'Bu adisyon servis edildi; mutfak durumunu değiştiremez.')
    }
    await tx.order.update({ where: { id: orderId }, data: { status } })
    return load(tx, orderId)
  })
  emit(updated)
  return toOrderDTO(updated)
}

export async function updateMeta(
  orderId: string,
  patch: { note?: string | null; guests?: number | null; customerId?: string | null; customerName?: string | null; discountTotal?: number }
): Promise<OrderDTO> {
  const updated = await db.$transaction(async (tx) => {
    assertOpen(await load(tx, orderId))
    await tx.order.update({
      where: { id: orderId },
      data: {
        ...(patch.note !== undefined ? { note: patch.note?.trim() || null } : {}),
        ...(patch.guests !== undefined ? { guests: patch.guests } : {}),
        ...(patch.customerId !== undefined ? { customerId: patch.customerId || null } : {}),
        ...(patch.customerName !== undefined ? { customerName: patch.customerName?.trim() || null } : {}),
      },
    })
    if (patch.discountTotal !== undefined) await recalc(tx, orderId, patch.discountTotal)
    return load(tx, orderId)
  })
  emit(updated)
  return toOrderDTO(updated)
}

export async function payOrder(
  orderId: string,
  input: { method: PrismaPayment; discountTotal?: number }
): Promise<OrderDTO> {
  const updated = await db.$transaction(async (tx) => {
    const order = await load(tx, orderId)
    assertOpen(order)
    if (order.items.length === 0) throw new HttpError(409, 'Boş adisyon kapatılamaz; iptal edin.')
    if (input.discountTotal !== undefined) await recalc(tx, orderId, input.discountTotal)
    await tx.order.update({
      where: { id: orderId },
      data: { status: 'PAID', paymentMethod: input.method, paidAt: new Date() },
    })
    return load(tx, orderId)
  })
  emit(updated)
  publish({ type: 'tables' })
  return toOrderDTO(updated)
}

export async function cancelOrder(orderId: string): Promise<OrderDTO> {
  const updated = await db.$transaction(async (tx) => {
    assertOpen(await load(tx, orderId))
    await tx.order.update({ where: { id: orderId }, data: { status: 'CANCELLED' } })
    return load(tx, orderId)
  })
  emit(updated)
  publish({ type: 'tables' })
  return toOrderDTO(updated)
}

/** Adisyonu başka masaya taşır; hedef masada açık adisyon varsa ikisini birleştirir. */
export async function moveToTable(orderId: string, targetTableId: string): Promise<{ order: OrderDTO; merged: boolean }> {
  const result = await db.$transaction(async (tx) => {
    const order = await load(tx, orderId)
    assertOpen(order)
    if (order.type !== 'TABLE') throw new HttpError(400, 'Yalnızca masa adisyonları taşınabilir.')
    if (order.tableId === targetTableId) throw new HttpError(400, 'Zaten bu masada.')
    const target = await tx.table.findUnique({ where: { id: targetTableId } })
    if (!target) throw new HttpError(404, 'Hedef masa bulunamadı.')

    const targetOrder = await tx.order.findFirst({
      where: { tableId: targetTableId, status: { in: OPEN_STATUSES } },
    })

    if (targetOrder) {
      await tx.orderItem.updateMany({ where: { orderId: order.id }, data: { orderId: targetOrder.id } })
      await tx.order.update({ where: { id: order.id }, data: { status: 'CANCELLED', note: `Birleştirildi → #${targetOrder.number}` } })
      await tx.order.update({ where: { id: targetOrder.id }, data: { status: 'NEW' } })
      await recalc(tx, targetOrder.id)
      await recalc(tx, order.id)
      return { id: targetOrder.id, merged: true }
    }

    await tx.order.update({ where: { id: order.id }, data: { tableId: target.id, tableName: target.name } })
    return { id: order.id, merged: false }
  })
  const order = await load(db, result.id)
  emit(order)
  publish({ type: 'tables' })
  return { order: toOrderDTO(order), merged: result.merged }
}
