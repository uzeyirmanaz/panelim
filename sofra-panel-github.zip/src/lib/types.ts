import type { OrderStatus, OrderType, PaymentMethod } from './constants'

export type OrderItemDTO = {
  id: string
  productId: string | null
  name: string
  unitPrice: number
  quantity: number
  note: string | null
  kitchenGroupId: string | null
}

export type OrderDTO = {
  id: string
  number: number
  type: OrderType
  status: OrderStatus
  tableId: string | null
  tableName: string | null
  customerId: string | null
  customerName: string | null
  note: string | null
  guests: number | null
  subtotal: number
  discountTotal: number
  total: number
  paymentMethod: PaymentMethod | null
  paidAt: string | null
  createdAt: string
  items: OrderItemDTO[]
}

export type FloorTableDTO = {
  id: string
  name: string
  seats: number
  order: {
    id: string
    status: OrderStatus
    total: number
    itemCount: number
    createdAt: string
    updatedAt: string
  } | null
}

export type FloorZoneDTO = {
  id: string
  name: string
  tables: FloorTableDTO[]
}

export type ProductDTO = {
  id: string
  categoryId: string
  name: string
  description: string | null
  price: number
  emoji: string | null
  available: boolean
  popular: boolean
}

export type CategoryDTO = {
  id: string
  name: string
  emoji: string | null
  products: ProductDTO[]
}

export type SessionUser = {
  id: string
  username: string
  name: string
  role: import('./constants').Role
}

export type LiveEvent = {
  type: 'orders' | 'tables' | 'menu'
  orderId?: string
  tableId?: string
}
