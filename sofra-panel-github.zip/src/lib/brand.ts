// Marka ve işletme bilgisi tek yerde. Kendi adınızı ve işletmenizi buradan değiştirin.
export const BRAND = {
  appName: 'Sofra',
  tagline: 'Restoran paneli',
  restaurantName: 'DEMO RESTORAN',
  accountCode: '10001',
} as const
