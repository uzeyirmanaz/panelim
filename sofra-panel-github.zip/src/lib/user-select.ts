export const userSelect = { id: true, username: true, name: true, role: true, active: true, createdAt: true } as const
