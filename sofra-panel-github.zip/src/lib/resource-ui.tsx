import type { ReactNode } from 'react'
import { Badge } from '@/components/ui/misc'
import { formatDate, formatMoney, formatNumber } from '@/lib/format'
import { ROLE_LABELS, type Role } from '@/lib/constants'

// Tanım sayfalarının arayüz sözleşmesi. Sunucu tarafı şemaları lib/resources.ts'tedir;
// buradaki alan adları o şemalarla birebir eşleşmelidir.

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type Row = Record<string, any>

export type FieldType = 'text' | 'tel' | 'number' | 'money' | 'select' | 'checkbox' | 'date' | 'textarea' | 'password'

export type FieldDef = {
  key: string
  label: string
  type?: FieldType
  /** Forma bağlı dinamik tür (örn. indirimde tür seçimine göre yüzde/tutar) */
  typeFrom?: (form: Record<string, string | boolean>) => FieldType
  required?: boolean
  placeholder?: string
  hint?: string
  options?: { value: string; label: string }[]
  /** Seçenekleri başka bir API'den yükler (yabancı anahtar alanları) */
  optionsFrom?: { url: string; label: (row: Row) => string }
  /** Seçimde "— Yok —" seçeneği ekler */
  nullable?: boolean
  defaultValue?: string | number | boolean
  only?: 'create' | 'edit'
  /** Düzenlemede boş bırakılırsa gönderilmez (şifre gibi) */
  skipEmptyOnEdit?: boolean
  wide?: boolean
}

export type ColumnDef = { header: string; cell: (row: Row) => ReactNode; className?: string }

export type ResourceUI = {
  slug: string
  api: string
  title: string
  singular: string
  icon: string
  description?: string
  emptyText?: string
  fields: FieldDef[]
  columns: ColumnDef[]
  /** Silme onayında kayıt adı olarak gösterilir */
  nameOf: (row: Row) => string
  /** true: personel (kasiyer) de ekleyip düzenleyebilir; değilse yalnızca yönetici (sunucu tarafı lib/resources.ts ile aynı olmalı) */
  staffWrite?: boolean
}

const yesNo = (v: boolean) => (v ? <Badge tone="green">Evet</Badge> : <Badge>Hayır</Badge>)
const dash = (v: unknown) => (v ? String(v) : <span className="text-slate-300">—</span>)

export const RESOURCE_UI: ResourceUI[] = [
  {
    slug: 'urunler',
    api: '/api/r/products',
    title: 'Ürünler',
    singular: 'Ürün',
    icon: 'UtensilsCrossed',
    description: 'Menüde satılan ürünler. Satışta olmayanlar sipariş ekranında görünmez.',
    nameOf: (r) => r.name,
    columns: [
      { header: 'Ürün', cell: (r) => <span className="font-medium">{r.emoji ? `${r.emoji} ` : ''}{r.name}</span> },
      { header: 'Kategori', cell: (r) => r.category?.name },
      { header: 'Fiyat', cell: (r) => <span className="tabular-nums">{formatMoney(r.price)}</span>, className: 'text-right' },
      { header: 'KDV', cell: (r) => (r.vatRate ? `%${r.vatRate.rate}` : dash(null)) },
      { header: 'Mutfak', cell: (r) => dash(r.kitchenGroup?.name) },
      { header: 'Satışta', cell: (r) => yesNo(r.available) },
    ],
    fields: [
      { key: 'name', label: 'Ürün adı', required: true, wide: true },
      { key: 'categoryId', label: 'Kategori', type: 'select', required: true, optionsFrom: { url: '/api/r/categories', label: (r) => r.name } },
      { key: 'price', label: 'Fiyat (₺)', type: 'money', required: true, defaultValue: '' },
      { key: 'emoji', label: 'Emoji', placeholder: '🍕' },
      { key: 'sortOrder', label: 'Sıra', type: 'number', defaultValue: 0 },
      { key: 'unitId', label: 'Birim', type: 'select', nullable: true, optionsFrom: { url: '/api/r/units', label: (r) => r.name } },
      { key: 'vatRateId', label: 'KDV oranı', type: 'select', nullable: true, optionsFrom: { url: '/api/r/vat-rates', label: (r) => `%${r.rate}` } },
      { key: 'kitchenGroupId', label: 'Mutfak grubu', type: 'select', nullable: true, optionsFrom: { url: '/api/r/kitchen-groups', label: (r) => r.name } },
      { key: 'externalCode', label: 'Harici ürün kodu', hint: 'Paket servis / entegrasyon eşleştirmesi için' },
      { key: 'description', label: 'Açıklama', type: 'textarea', wide: true },
      { key: 'available', label: 'Satışta', type: 'checkbox', defaultValue: true },
      { key: 'popular', label: 'Popüler ürün', type: 'checkbox', defaultValue: false },
    ],
  },
  {
    slug: 'kategoriler',
    api: '/api/r/categories',
    title: 'Kategoriler',
    singular: 'Kategori',
    icon: 'Tags',
    nameOf: (r) => r.name,
    columns: [
      { header: 'Kategori', cell: (r) => <span className="font-medium">{r.emoji ? `${r.emoji} ` : ''}{r.name}</span> },
      { header: 'Sıra', cell: (r) => r.sortOrder, className: 'w-24' },
    ],
    fields: [
      { key: 'name', label: 'Kategori adı', required: true },
      { key: 'emoji', label: 'Emoji', placeholder: '🍔' },
      { key: 'sortOrder', label: 'Sıra', type: 'number', defaultValue: 0 },
    ],
  },
  {
    slug: 'masalar',
    api: '/api/r/tables',
    title: 'Masa Tanımları',
    singular: 'Masa',
    icon: 'Armchair',
    nameOf: (r) => r.name,
    columns: [
      { header: 'Masa', cell: (r) => <span className="font-medium">{r.name}</span> },
      { header: 'Bölge', cell: (r) => r.zone?.name },
      { header: 'Kapasite', cell: (r) => `${r.seats} kişi` },
    ],
    fields: [
      { key: 'name', label: 'Masa adı', required: true, placeholder: 'Masa 7' },
      { key: 'zoneId', label: 'Bölge', type: 'select', required: true, optionsFrom: { url: '/api/r/zones', label: (r) => r.name } },
      { key: 'seats', label: 'Kapasite', type: 'number', defaultValue: 4 },
    ],
  },
  {
    slug: 'bolgeler',
    api: '/api/r/zones',
    title: 'Bölgeler',
    singular: 'Bölge',
    icon: 'Map',
    description: 'Salon, bahçe, teras gibi masa grupları.',
    nameOf: (r) => r.name,
    columns: [
      { header: 'Bölge', cell: (r) => <span className="font-medium">{r.name}</span> },
      { header: 'Sıra', cell: (r) => r.sortOrder, className: 'w-24' },
    ],
    fields: [
      { key: 'name', label: 'Bölge adı', required: true, placeholder: 'Bahçe' },
      { key: 'sortOrder', label: 'Sıra', type: 'number', defaultValue: 0 },
    ],
  },
  {
    slug: 'birimler',
    api: '/api/r/units',
    title: 'Birimler',
    singular: 'Birim',
    icon: 'Ruler',
    nameOf: (r) => r.name,
    columns: [{ header: 'Birim', cell: (r) => <span className="font-medium">{r.name}</span> }],
    fields: [{ key: 'name', label: 'Birim adı', required: true, placeholder: 'Adet, Porsiyon, Kg…' }],
  },
  {
    slug: 'ozellikler',
    api: '/api/r/features',
    title: 'Özellikler',
    singular: 'Özellik',
    icon: 'ListPlus',
    description: 'Ürünlere eklenebilen seçenekler (ekstra peynir, az acı vb.).',
    nameOf: (r) => r.name,
    columns: [
      { header: 'Özellik', cell: (r) => <span className="font-medium">{r.name}</span> },
      { header: 'Ek ücret', cell: (r) => <span className="tabular-nums">{formatMoney(r.price)}</span>, className: 'text-right' },
    ],
    fields: [
      { key: 'name', label: 'Özellik adı', required: true },
      { key: 'price', label: 'Ek ücret (₺)', type: 'money', defaultValue: '0,00' },
    ],
  },
  {
    slug: 'kdv-oranlari',
    api: '/api/r/vat-rates',
    title: 'KDV Oranları',
    singular: 'KDV oranı',
    icon: 'Percent',
    nameOf: (r) => `%${r.rate}`,
    columns: [{ header: 'Oran', cell: (r) => <span className="font-medium">%{r.rate}</span> }],
    fields: [{ key: 'rate', label: 'Oran (%)', type: 'number', required: true, defaultValue: 10 }],
  },
  {
    slug: 'indirimler',
    api: '/api/r/discounts',
    title: 'İndirimler',
    singular: 'İndirim',
    icon: 'BadgePercent',
    description: 'Ödeme ekranında tek dokunuşla uygulanabilen hazır indirimler.',
    nameOf: (r) => r.name,
    columns: [
      { header: 'İndirim', cell: (r) => <span className="font-medium">{r.name}</span> },
      { header: 'Değer', cell: (r) => (r.kind === 'PERCENT' ? `%${r.value}` : formatMoney(r.value)) },
    ],
    fields: [
      { key: 'name', label: 'İndirim adı', required: true, placeholder: 'Personel indirimi' },
      {
        key: 'kind',
        label: 'Tür',
        type: 'select',
        required: true,
        defaultValue: 'PERCENT',
        options: [
          { value: 'PERCENT', label: 'Yüzde (%)' },
          { value: 'AMOUNT', label: 'Tutar (₺)' },
        ],
      },
      { key: 'value', label: 'Değer', type: 'number', typeFrom: (f) => (f.kind === 'AMOUNT' ? 'money' : 'number'), required: true, hint: 'Yüzde için 1–100, tutar için ₺' },
    ],
  },
  {
    slug: 'mutfak-gruplari',
    api: '/api/r/kitchen-groups',
    title: 'Mutfak Grupları',
    singular: 'Mutfak grubu',
    icon: 'Flame',
    description: 'Ürünlerin hangi hazırlık istasyonuna gideceğini belirler (Izgara, Soğuk, Tatlı…).',
    nameOf: (r) => r.name,
    columns: [{ header: 'Grup', cell: (r) => <span className="font-medium">{r.name}</span> }],
    fields: [{ key: 'name', label: 'Grup adı', required: true }],
  },
  {
    slug: 'siparis-tanimlari',
    api: '/api/r/note-templates',
    staffWrite: true,
    title: 'Sipariş',
    singular: 'Hazır not',
    icon: 'ShoppingBag',
    description: 'Sipariş ekranında tek dokunuşla eklenen hazır notlar (Servis notu, Acısız, Paket notu…).',
    nameOf: (r) => r.name,
    columns: [{ header: 'Not', cell: (r) => <span className="font-medium">{r.name}</span> }],
    fields: [{ key: 'name', label: 'Not', required: true, placeholder: 'Örn: Servis notu, Az pişmiş, Paket notu' }],
  },
  {
    slug: 'musteriler',
    staffWrite: true,
    api: '/api/r/customers',
    title: 'Müşteriler',
    singular: 'Müşteri',
    icon: 'Contact',
    nameOf: (r) => r.name,
    columns: [
      { header: 'Ad', cell: (r) => <span className="font-medium">{r.name}</span> },
      { header: 'Telefon', cell: (r) => dash(r.phone) },
      { header: 'Adres', cell: (r) => dash(r.address), className: 'max-w-xs truncate' },
    ],
    fields: [
      { key: 'name', label: 'Ad soyad', required: true },
      { key: 'phone', label: 'Telefon', type: 'tel' },
      { key: 'address', label: 'Adres', type: 'textarea', wide: true },
      { key: 'note', label: 'Not', type: 'textarea', wide: true },
    ],
  },
  {
    slug: 'odenmeyenler',
    staffWrite: true,
    api: '/api/r/defaulters',
    title: 'Ödenmeyenler',
    singular: 'Kayıt',
    icon: 'HandCoins',
    description: 'Hesabını ödemeden ayrılan veya veresiye bırakılan tutarlar.',
    nameOf: (r) => r.name,
    columns: [
      { header: 'Ad', cell: (r) => <span className="font-medium">{r.name}</span> },
      { header: 'Tutar', cell: (r) => <span className="tabular-nums">{formatMoney(r.amount)}</span>, className: 'text-right' },
      { header: 'Durum', cell: (r) => (r.resolved ? <Badge tone="green">Tahsil edildi</Badge> : <Badge tone="amber">Bekliyor</Badge>) },
      { header: 'Tarih', cell: (r) => formatDate(r.createdAt) },
    ],
    fields: [
      { key: 'name', label: 'Ad soyad', required: true },
      { key: 'amount', label: 'Tutar (₺)', type: 'money', required: true, defaultValue: '' },
      { key: 'note', label: 'Not', type: 'textarea', wide: true },
      { key: 'resolved', label: 'Tahsil edildi', type: 'checkbox', defaultValue: false },
    ],
  },
  {
    slug: 'giderler',
    staffWrite: true,
    api: '/api/r/expenses',
    title: 'Gider / Masraf',
    singular: 'Gider',
    icon: 'Wallet',
    description: 'Gün sonu raporunda ciro ile birlikte net sonuca yansır.',
    nameOf: (r) => r.title,
    columns: [
      { header: 'Gider', cell: (r) => <span className="font-medium">{r.title}</span> },
      { header: 'Grup', cell: (r) => <Badge>{r.group}</Badge> },
      { header: 'Tutar', cell: (r) => <span className="tabular-nums">{formatMoney(r.amount)}</span>, className: 'text-right' },
      { header: 'Tarih', cell: (r) => formatDate(r.spentAt) },
    ],
    fields: [
      { key: 'title', label: 'Açıklama', required: true, placeholder: 'Aralık kirası' },
      { key: 'amount', label: 'Tutar (₺)', type: 'money', required: true, defaultValue: '' },
      {
        key: 'group',
        label: 'Grup',
        type: 'select',
        required: true,
        defaultValue: 'Diğer',
        options: ['Kira', 'Personel', 'Fatura', 'Malzeme', 'Bakım', 'Diğer'].map((v) => ({ value: v, label: v })),
      },
      { key: 'spentAt', label: 'Tarih', type: 'date', required: true },
      { key: 'note', label: 'Not', type: 'textarea', wide: true },
    ],
  },
  {
    slug: 'zayi',
    staffWrite: true,
    api: '/api/r/wastes',
    title: 'Zayi',
    singular: 'Zayi kaydı',
    icon: 'Trash2',
    description: 'Bozulan, dökülen veya satılamayan ürünler.',
    nameOf: (r) => r.productName,
    columns: [
      { header: 'Ürün', cell: (r) => <span className="font-medium">{r.productName}</span> },
      { header: 'Miktar', cell: (r) => formatNumber(r.quantity) },
      { header: 'Maliyet', cell: (r) => <span className="tabular-nums">{formatMoney(r.cost)}</span>, className: 'text-right' },
      { header: 'Neden', cell: (r) => dash(r.reason) },
      { header: 'Tarih', cell: (r) => formatDate(r.wastedAt) },
    ],
    fields: [
      { key: 'productName', label: 'Ürün / malzeme', required: true },
      { key: 'quantity', label: 'Miktar', type: 'number', required: true, defaultValue: 1 },
      { key: 'cost', label: 'Maliyet (₺)', type: 'money', defaultValue: '0,00' },
      { key: 'wastedAt', label: 'Tarih', type: 'date', required: true },
      { key: 'reason', label: 'Neden', type: 'textarea', wide: true },
    ],
  },
  {
    slug: 'kullanicilar',
    api: '/api/users',
    title: 'Kullanıcılar',
    singular: 'Kullanıcı',
    icon: 'Users',
    description: 'Yönetici her şeyi görür; kasiyer sipariş ve tanımları yönetir; mutfak yalnızca mutfak ekranını kullanır.',
    nameOf: (r) => r.username,
    columns: [
      { header: 'Ad', cell: (r) => <span className="font-medium">{r.name}</span> },
      { header: 'Kullanıcı adı', cell: (r) => r.username },
      { header: 'Rol', cell: (r) => <Badge tone="brand">{ROLE_LABELS[r.role as Role]}</Badge> },
      { header: 'Durum', cell: (r) => (r.active ? <Badge tone="green">Aktif</Badge> : <Badge tone="rose">Pasif</Badge>) },
    ],
    fields: [
      { key: 'name', label: 'Ad soyad', required: true },
      { key: 'username', label: 'Kullanıcı adı', required: true, only: 'create', hint: 'Küçük harf, rakam, . _ -' },
      {
        key: 'role',
        label: 'Rol',
        type: 'select',
        required: true,
        defaultValue: 'CASHIER',
        options: (Object.keys(ROLE_LABELS) as Role[]).map((v) => ({ value: v, label: ROLE_LABELS[v] })),
      },
      { key: 'password', label: 'Şifre', type: 'password', skipEmptyOnEdit: true, hint: 'En az 6 karakter. Düzenlerken boş bırakırsanız değişmez.' },
      { key: 'active', label: 'Aktif', type: 'checkbox', defaultValue: true },
    ],
  },
]

export const findResourceUI = (slug: string) => RESOURCE_UI.find((r) => r.slug === slug)
