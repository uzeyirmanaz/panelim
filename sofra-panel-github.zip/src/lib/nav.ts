import type { Role } from './constants'
import { can, type Capability } from './permissions'

export type NavItem = {
  label: string
  icon: string
  href?: string
  children?: NavItem[]
  /** Gereken yetenek (lib/permissions.ts); tanımsız = üst grubun yeteneği, o da yoksa herkes. */
  cap?: Capability
}

// Kenar çubuğu menü ağacı
export const NAV: NavItem[] = [
  { label: 'Ana Sayfa', icon: 'Home', href: '/panel', cap: 'panel.view' },
  { label: 'Siparişler', icon: 'ReceiptText', href: '/panel/siparisler', cap: 'order.write' },
  { label: 'Mutfak Ekranı', icon: 'ChefHat', href: '/panel/mutfak', cap: 'kitchen.view' },
  {
    label: 'Entegrasyon İşlemleri',
    icon: 'Puzzle',
    cap: 'defs.read',
    children: [
      { label: 'Ürün Eşleştirme Ekranı', icon: 'ListChecks', href: '/panel/urun-eslestirme' },
      { label: 'Entegrasyon İşlemleri', icon: 'Puzzle', href: '/panel/entegrasyon' },
    ],
  },
  { label: 'Dijital Menü', icon: 'QrCode', href: '/panel/dijital-menu', cap: 'defs.read' },
  {
    label: 'Tanımlamalar',
    icon: 'ClipboardCheck',
    cap: 'defs.read',
    children: [
      { label: 'Masa / Bölgeler', icon: 'LayoutGrid', href: '/panel/masalar' },
      { label: 'Masa / Bölge Tanımları', icon: 'Armchair', href: '/panel/masalar/duzenle' },
      { label: 'Menü / Ürünler', icon: 'UtensilsCrossed', href: '/panel/menu' },
      { label: 'Birimler', icon: 'Ruler', href: '/panel/birimler' },
      { label: 'Özellikler', icon: 'ListPlus', href: '/panel/ozellikler' },
      { label: 'Kdv Oranları', icon: 'Percent', href: '/panel/kdv-oranlari' },
      { label: 'İndirimler', icon: 'BadgePercent', href: '/panel/indirimler' },
      { label: 'Mutfak Grupları', icon: 'Flame', href: '/panel/mutfak-gruplari' },
      { label: 'Müşteriler', icon: 'Contact', href: '/panel/musteriler' },
      { label: 'Ödenmezler', icon: 'HandCoins', href: '/panel/odenmezler' },
      { label: 'Sipariş', icon: 'ShoppingBasket', href: '/panel/siparis-tanimlari' },
      {
        label: 'İşlemler',
        icon: 'Layers',
        children: [
          { label: 'Gider / Masraf İşlemleri', icon: 'TrendingDown', href: '/panel/gider-masraf' },
          { label: 'Zayi İşlemleri', icon: 'Trash2', href: '/panel/zayi' },
        ],
      },
      { label: 'Kullanıcılar', icon: 'Users', href: '/panel/kullanicilar', cap: 'users.manage' },
      { label: 'Yetkiler', icon: 'ShieldCheck', href: '/panel/yetkiler', cap: 'users.manage' },
    ],
  },
  {
    label: 'Raporlar',
    icon: 'PieChart',
    cap: 'reports.read',
    children: [
      { label: 'Ürün Satış Raporu', icon: 'BarChart3', href: '/panel/raporlar/urun-satis' },
      { label: 'Gün Sonu Raporu', icon: 'CalendarCheck', href: '/panel/raporlar/gun-sonu' },
      { label: 'Vardiya Satış Raporu', icon: 'Clock', href: '/panel/raporlar/vardiya' },
      { label: 'Restoran İstatistikleri', icon: 'Activity', href: '/panel/raporlar/istatistik' },
      { label: 'Fire Raporu', icon: 'PackageX', href: '/panel/raporlar/fire' },
      { label: 'Rapor Sihirbazı', icon: 'Sparkles', href: '/panel/raporlar/sihirbaz' },
      { label: 'Maliyet-Karlılık Raporu', icon: 'TrendingUp', href: '/panel/raporlar/maliyet' },
    ],
  },
  { label: 'Uygulama Mağazası', icon: 'Store', href: '/panel/uygulama-magazasi', cap: 'defs.read' },
]

// Menüde olmayan sayfaların başlıkları
const EXTRA_TITLES: [string, string][] = [
  ['/panel/hesabim', 'Hesabım'],
  ['/panel/ayarlar', 'Ayarlar'],
  ['/panel/siparis', 'Sipariş'],
]

export function visibleNav(role: Role): NavItem[] {
  const filter = (items: NavItem[], inherited?: Capability): NavItem[] =>
    items
      .filter((i) => {
        const cap = i.cap ?? inherited
        return !cap || can(role, cap)
      })
      .map((i) => (i.children ? { ...i, children: filter(i.children, i.cap ?? inherited) } : i))
      .filter((i) => !i.children || i.children.length > 0)
  return filter(NAV)
}

function flatten(items: NavItem[]): NavItem[] {
  return items.flatMap((i) => (i.children ? flatten(i.children) : [i]))
}

/** Yol için en uzun eşleşen menü başlığı */
export function titleFor(pathname: string): string {
  const all = [...flatten(NAV).filter((i) => i.href).map((i) => [i.href!, i.label] as [string, string]), ...EXTRA_TITLES]
  const match = all.filter(([href]) => pathname === href || pathname.startsWith(href + '/')).sort((a, b) => b[0].length - a[0].length)[0]
  return match?.[1] ?? BRAND_FALLBACK
}
const BRAND_FALLBACK = 'Panel'

/** Yolun içinde geçtiği grup etiketleri (kenar çubuğunda açık başlasın) */
export function activeGroups(pathname: string, items: NavItem[] = NAV): string[] {
  const out: string[] = []
  for (const i of items) {
    if (!i.children) continue
    const inner = activeGroups(pathname, i.children)
    const hit = flatten(i.children).some((c) => c.href && (pathname === c.href || pathname.startsWith(c.href + '/')))
    if (hit) out.push(i.label, ...inner)
  }
  return out
}
