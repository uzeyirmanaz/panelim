// Tarayıcı tarafı fetch yardımcısı. Hatalarda ApiError fırlatır (mesaj kullanıcıya gösterilebilir).

export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
    public data?: Record<string, unknown>
  ) {
    super(message)
  }
}

async function request<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: { 'Content-Type': 'application/json', ...init?.headers },
    cache: 'no-store',
  })
  const body = await res.json().catch(() => null)
  if (!res.ok) {
    if (res.status === 401 && typeof window !== 'undefined' && !location.pathname.startsWith('/giris')) {
      location.href = '/giris'
    }
    throw new ApiError(body?.error ?? `İstek başarısız (${res.status})`, res.status, body ?? undefined)
  }
  return body as T
}

const send = (method: string) => <T>(url: string, body?: unknown) =>
  request<T>(url, { method, body: body === undefined ? undefined : JSON.stringify(body) })

export const api = {
  get: <T>(url: string) => request<T>(url),
  post: send('POST'),
  patch: send('PATCH'),
  put: send('PUT'),
  del: <T = { ok: true }>(url: string) => request<T>(url, { method: 'DELETE' }),
}
