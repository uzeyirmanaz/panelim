import { NextResponse, type NextRequest } from 'next/server'
import { Prisma } from '@prisma/client'
import { ZodError } from 'zod'

export class HttpError extends Error {
  constructor(
    public status: number,
    message: string,
    public extra?: Record<string, unknown>
  ) {
    super(message)
  }
}

type Ctx<P> = { params: Promise<P> }

/**
 * Route handler sarmalayıcı: HttpError / Zod / Prisma hatalarını tutarlı
 * `{ error: string }` yanıtına çevirir. Başarılı yanıtlar ham JSON döner.
 */
export function handle<P extends Record<string, string> = Record<string, never>>(
  fn: (req: NextRequest, ctx: Ctx<P>) => Promise<Response | unknown>
) {
  return async (req: NextRequest, ctx: Ctx<P>) => {
    try {
      const result = await fn(req, ctx)
      return result instanceof Response ? result : NextResponse.json(result ?? { ok: true })
    } catch (e) {
      return errorResponse(e)
    }
  }
}

function errorResponse(e: unknown) {
  if (e instanceof HttpError) {
    return NextResponse.json({ error: e.message, ...e.extra }, { status: e.status })
  }
  if (e instanceof ZodError) {
    const issue = e.issues[0]
    const field = issue?.path.join('.') || 'istek'
    return NextResponse.json({ error: `Geçersiz değer (${field}): ${issue?.message ?? ''}`.trim() }, { status: 400 })
  }
  if (e instanceof Prisma.PrismaClientKnownRequestError) {
    if (e.code === 'P2002') return NextResponse.json({ error: 'Bu kayıt zaten mevcut.' }, { status: 409 })
    if (e.code === 'P2025') return NextResponse.json({ error: 'Kayıt bulunamadı.' }, { status: 404 })
    if (e.code === 'P2003')
      return NextResponse.json({ error: 'Bu kayıt başka kayıtlarda kullanıldığı için işlem yapılamaz.' }, { status: 409 })
  }
  console.error(e)
  return NextResponse.json({ error: 'Beklenmeyen bir hata oluştu.' }, { status: 500 })
}

export async function readJson(req: NextRequest): Promise<unknown> {
  try {
    return await req.json()
  } catch {
    throw new HttpError(400, 'Geçersiz JSON gövdesi.')
  }
}
