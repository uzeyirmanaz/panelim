// Para birimi kuruş (tamsayı) olarak tutulur; yalnızca gösterirken/girerken dönüştürülür.

const tl = new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY' })
const num = new Intl.NumberFormat('tr-TR')

export const formatMoney = (kurus: number) => tl.format(kurus / 100)
export const formatNumber = (n: number) => num.format(n)

/** "12,5" · "12.50" · "1.250,75" · "₺40" → kuruş. Geçersizse null. */
export function parseMoney(input: string): number | null {
  let s = input.replace(/[₺\sTL]/gi, '')
  if (!s) return null
  if (s.includes(',')) s = s.replace(/\./g, '').replace(',', '.')
  const n = Number(s)
  if (!Number.isFinite(n) || n < 0) return null
  return Math.round(n * 100)
}

/** kuruş → form alanı metni ("12,5" yerine "12,50") */
export function moneyToInput(kurus: number): string {
  return (kurus / 100).toFixed(2).replace('.', ',')
}

export const formatTime = (iso: string | Date) =>
  new Date(iso).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })

export const formatDate = (iso: string | Date) =>
  new Date(iso).toLocaleDateString('tr-TR', { day: '2-digit', month: '2-digit', year: 'numeric' })

export const formatDateTime = (iso: string | Date) => `${formatDate(iso)} ${formatTime(iso)}`

/** Yerel saate göre 'YYYY-MM-DD' (toISOString UTC kaydırması yüzünden gün sınırında yanlış sonuç verir) */
export function dayKey(d: Date): string {
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

export const todayKey = () => dayKey(new Date())

/** 'YYYY-MM-DD' → yerel gün başlangıcı */
export function dayStart(key: string): Date {
  const [y, m, d] = key.split('-').map(Number)
  return new Date(y, (m ?? 1) - 1, d ?? 1, 0, 0, 0, 0)
}

/** 'YYYY-MM-DD' → yerel gün sonu */
export function dayEnd(key: string): Date {
  const d = dayStart(key)
  d.setHours(23, 59, 59, 999)
  return d
}

export function minutesAgo(iso: string): number {
  return Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 60000))
}
