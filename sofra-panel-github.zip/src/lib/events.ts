// Süreç içi olay yayıncısı (tek Node süreci için). Çok süreçli dağıtımda
// Redis pub/sub gibi bir köprüyle değiştirilebilir; arayüz aynı kalır.
import type { LiveEvent } from './types'

type Listener = (e: LiveEvent) => void
const g = globalThis as unknown as { __sofraListeners?: Set<Listener> }
const listeners = (g.__sofraListeners ??= new Set<Listener>())

export function publish(e: LiveEvent) {
  for (const l of listeners) {
    try {
      l(e)
    } catch {
      // bir dinleyicinin hatası diğerlerini etkilemesin
    }
  }
}

export function subscribe(l: Listener): () => void {
  listeners.add(l)
  return () => listeners.delete(l)
}
