import type { Role } from './constants'

/**
 * TÜM rol kuralları burada. API korumaları, sayfa korumaları, menü ve Yetkiler ekranı bu tabloyu okur.
 * Değer = bu yeteneğe sahip roller. ADMIN her yeteneğe her zaman sahiptir (listeye yazmak gerekmez).
 */
export const CAPABILITIES = {
  'panel.view': { label: 'Ana Sayfa özeti', roles: ['CASHIER'] },
  'order.write': { label: 'Masa / Bölgeler, sipariş açma, düzenleme, ödeme alma, indirim, adisyon iptali', roles: ['CASHIER'] },
  'kitchen.view': { label: 'Mutfak ekranı (Hazırlanıyor / Hazır)', roles: ['CASHIER', 'KITCHEN'] },
  'defs.read': { label: 'Tanımları ve menüyü görüntüleme', roles: ['CASHIER'] },
  'defs.write': { label: 'Menü, masa, bölge, birim, KDV, indirim, mutfak grubu düzenleme', roles: [] },
  'staff.write': { label: 'Müşteri, ödenmez, gider, zayi ve hazır not düzenleme', roles: ['CASHIER'] },
  'reports.read': { label: 'Raporlar', roles: [] },
  'users.manage': { label: 'Kullanıcılar ve yetkiler', roles: [] },
} as const satisfies Record<string, { label: string; roles: readonly Role[] }>

export type Capability = keyof typeof CAPABILITIES

/** Rolün yeteneği var mı? (ADMIN her zaman evet) */
export function can(role: Role, cap: Capability): boolean {
  return role === 'ADMIN' || (CAPABILITIES[cap].roles as readonly Role[]).includes(role)
}

/** Yeteneğe sahip roller (ADMIN dahil). */
export function rolesFor(cap: Capability): Role[] {
  return (['ADMIN', 'CASHIER', 'KITCHEN'] as Role[]).filter((r) => can(r, cap))
}

/** Rolün giriş ekranı: mutfak kullanıcısı mutfağa, diğerleri ana sayfaya gider. */
export const homeFor = (role: Role) => (can(role, 'panel.view') ? '/panel' : '/panel/mutfak')
