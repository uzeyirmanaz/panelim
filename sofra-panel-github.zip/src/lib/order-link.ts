import type { OrderType } from './constants'

/** Adisyon ekranı adresi: masa kimliği, "paket" veya "gelal" + isteğe bağlı adisyon kimliği ve açılacak işlem */
export function orderHref(o: { id?: string; tableId: string | null; type: OrderType }, islem?: 'ode' | 'tasi'): string {
  const base = o.tableId ?? (o.type === 'DELIVERY' ? 'paket' : 'gelal')
  const q = new URLSearchParams()
  if (o.id && !o.tableId) q.set('id', o.id)
  if (islem) q.set('islem', islem)
  const qs = q.toString()
  return `/panel/siparis/${base}${qs ? `?${qs}` : ''}`
}
