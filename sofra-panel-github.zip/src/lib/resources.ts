import 'server-only'
import { z } from 'zod'
import { db } from './db'
import type { Role } from './constants'
import { CAPABILITIES } from './permissions'

// Basit "tanım" kayıtları için tek bir sözleşme: şema + prisma modeli + yetki.
// /api/r/[resource] rotaları bu kayıt defterinden beslenir; yeni bir tanım eklemek
// için buraya bir satır ve arayüz tarafında lib/resource-ui.tsx'e bir giriş yeterlidir.
// Yazma yetkisi lib/permissions.ts'ten gelir (STAFF = 'staff.write', ADMIN_ONLY = 'defs.write').

type Delegate = {
  findMany(args?: unknown): Promise<unknown[]>
  create(args: unknown): Promise<unknown>
  update(args: unknown): Promise<unknown>
  delete(args: unknown): Promise<unknown>
}

export type ResourceDef = {
  model: Delegate
  schema: z.ZodObject
  orderBy: unknown
  include?: unknown
  /** Yazma (ekle/düzenle/sil) için izinli roller; ADMIN her zaman geçer. */
  write: readonly Role[]
}

// ── Alan yardımcıları ────────────────────────────────────────────────────────
const text = (max = 120) => z.string().trim().min(1, 'Zorunlu alan').max(max)
const optText = (max = 300) =>
  z.string().trim().max(max).nullish().transform((v) => v || null)
const int = (min = 0, max = 1_000_000) => z.coerce.number().int().min(min).max(max)
/** kuruş */
const money = int(0, 100_000_000)
const optId = z.string().nullish().transform((v) => v || null)

const STAFF = CAPABILITIES['staff.write'].roles
const ADMIN_ONLY = CAPABILITIES['defs.write'].roles

export const RESOURCES: Record<string, ResourceDef> = {
  units: {
    model: db.unit as unknown as Delegate,
    schema: z.object({ name: text(40) }),
    orderBy: { name: 'asc' },
    write: ADMIN_ONLY,
  },
  'vat-rates': {
    model: db.vatRate as unknown as Delegate,
    schema: z.object({ rate: int(0, 100) }),
    orderBy: { rate: 'asc' },
    write: ADMIN_ONLY,
  },
  'kitchen-groups': {
    model: db.kitchenGroup as unknown as Delegate,
    schema: z.object({ name: text(40) }),
    orderBy: { name: 'asc' },
    write: ADMIN_ONLY,
  },
  features: {
    model: db.feature as unknown as Delegate,
    schema: z.object({ name: text(60), price: money }),
    orderBy: { name: 'asc' },
    write: ADMIN_ONLY,
  },
  discounts: {
    model: db.discount as unknown as Delegate,
    schema: z.object({ name: text(60), kind: z.enum(['PERCENT', 'AMOUNT']), value: int(1, 100_000_000) }),
    orderBy: { name: 'asc' },
    write: ADMIN_ONLY,
  },
  'note-templates': {
    model: db.noteTemplate as unknown as Delegate,
    schema: z.object({ name: text(80) }),
    orderBy: { name: 'asc' },
    write: STAFF,
  },
  customers: {
    model: db.customer as unknown as Delegate,
    schema: z.object({ name: text(80), phone: optText(30), address: optText(300), note: optText(300) }),
    orderBy: { createdAt: 'desc' },
    write: STAFF,
  },
  defaulters: {
    model: db.defaulter as unknown as Delegate,
    schema: z.object({ name: text(80), amount: money, note: optText(300), resolved: z.boolean() }),
    orderBy: [{ resolved: 'asc' }, { createdAt: 'desc' }],
    write: STAFF,
  },
  expenses: {
    model: db.expense as unknown as Delegate,
    schema: z.object({ title: text(80), amount: money, group: text(40), note: optText(300), spentAt: z.coerce.date() }),
    orderBy: { spentAt: 'desc' },
    write: STAFF,
  },
  wastes: {
    model: db.waste as unknown as Delegate,
    schema: z.object({
      productName: text(80),
      quantity: z.coerce.number().positive().max(100_000),
      cost: money,
      reason: optText(300),
      wastedAt: z.coerce.date(),
    }),
    orderBy: { wastedAt: 'desc' },
    write: STAFF,
  },
  zones: {
    model: db.zone as unknown as Delegate,
    schema: z.object({ name: text(40), sortOrder: int(0, 1000) }),
    orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }],
    write: ADMIN_ONLY,
  },
  tables: {
    model: db.table as unknown as Delegate,
    schema: z.object({ zoneId: z.string().min(1, 'Bölge seçin'), name: text(40), seats: int(1, 100) }),
    orderBy: [{ zone: { sortOrder: 'asc' } }, { name: 'asc' }],
    include: { zone: { select: { id: true, name: true } } },
    write: ADMIN_ONLY,
  },
  categories: {
    model: db.category as unknown as Delegate,
    schema: z.object({ name: text(60), emoji: optText(8), sortOrder: int(0, 1000) }),
    orderBy: [{ sortOrder: 'asc' }, { name: 'asc' }],
    write: ADMIN_ONLY,
  },
  products: {
    model: db.product as unknown as Delegate,
    schema: z.object({
      categoryId: z.string().min(1, 'Kategori seçin'),
      name: text(80),
      description: optText(300),
      price: money,
      emoji: optText(8),
      available: z.boolean(),
      popular: z.boolean(),
      sortOrder: int(0, 1000),
      unitId: optId,
      vatRateId: optId,
      kitchenGroupId: optId,
      externalCode: optText(60),
    }),
    orderBy: [{ category: { sortOrder: 'asc' } }, { sortOrder: 'asc' }, { name: 'asc' }],
    include: {
      category: { select: { id: true, name: true } },
      unit: { select: { name: true } },
      vatRate: { select: { rate: true } },
      kitchenGroup: { select: { name: true } },
    },
    write: ADMIN_ONLY,
  },
}
