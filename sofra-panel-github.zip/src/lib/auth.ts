import 'server-only'
import { createHash, randomBytes } from 'node:crypto'
import { cache } from 'react'
import { cookies } from 'next/headers'
import { redirect } from 'next/navigation'
import { db } from './db'
import { HttpError } from './http'
import { hashPassword, verifyPassword } from './password'
import type { Role } from './constants'
import { can, homeFor, type Capability } from './permissions'
import type { SessionUser } from './types'

export { hashPassword, verifyPassword }

export const SESSION_COOKIE = 'sofra_session'
const SESSION_DAYS = 14

// ── Oturum ───────────────────────────────────────────────────────────────────
// Çerezde ham token, veritabanında yalnızca sha256 özeti tutulur;
// veritabanı sızsa bile oturumlar ele geçirilemez.
const sha = (s: string) => createHash('sha256').update(s).digest('hex')

export async function createSession(userId: string, userAgent?: string | null) {
  const token = randomBytes(32).toString('hex')
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 86_400_000)
  await db.session.create({
    data: { tokenHash: sha(token), userId, userAgent: userAgent?.slice(0, 250) ?? null, expiresAt },
  })
  await db.session.deleteMany({ where: { expiresAt: { lt: new Date() } } })

  const jar = await cookies()
  jar.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.COOKIE_SECURE !== 'false' && process.env.NODE_ENV === 'production',
    path: '/',
    expires: expiresAt,
  })
}

export async function destroySession() {
  const jar = await cookies()
  const token = jar.get(SESSION_COOKIE)?.value
  if (token) await db.session.deleteMany({ where: { tokenHash: sha(token) } })
  jar.delete(SESSION_COOKIE)
}

/** Geçerli oturumun kullanıcısı (aynı istekte tekrar çağrılırsa önbellekten gelir). */
export const getCurrentUser = cache(async (): Promise<SessionUser | null> => {
  const token = (await cookies()).get(SESSION_COOKIE)?.value
  if (!token) return null
  const session = await db.session.findUnique({
    where: { tokenHash: sha(token) },
    include: { user: true },
  })
  if (!session || session.expiresAt < new Date() || !session.user.active) return null
  const { id, username, name, role } = session.user
  return { id, username, name, role }
})

/** Oturum açmış herkes geçer (rol sınırı yok); yoksa 401. Yetenek için requireCan() kullanın. */
export async function requireUser(): Promise<SessionUser> {
  const user = await getCurrentUser()
  if (!user) throw new HttpError(401, 'Oturum açmanız gerekiyor.')
  return user
}

/** API koruması: oturum yoksa 401, yetenek (lib/permissions.ts) yoksa 403. */
export async function requireCan(cap: Capability): Promise<SessionUser> {
  const user = await requireUser()
  if (!can(user.role, cap)) throw new HttpError(403, 'Bu işlem için yetkiniz yok.')
  return user
}

/** Rol listesi boşsa yalnızca yönetici; doluysa listedekiler (ve yönetici) geçer. */
export async function requireRole(roles: readonly Role[]): Promise<SessionUser> {
  const user = await requireUser()
  if (user.role !== 'ADMIN' && !roles.includes(user.role)) {
    throw new HttpError(403, 'Bu işlem için yetkiniz yok.')
  }
  return user
}

// ── Sayfa (sunucu bileşeni) koruması ─────────────────────────────────────────
/** Yetenek verilmezse tüm oturum açmış roller girebilir; oturum yoksa /giris'e, yetki yoksa rolün ana ekranına yönlendirir. */
export async function requirePage(cap?: Capability): Promise<SessionUser> {
  const user = await getCurrentUser()
  if (!user) redirect('/giris')
  if (cap && !can(user.role, cap)) redirect(homeFor(user.role))
  return user
}
