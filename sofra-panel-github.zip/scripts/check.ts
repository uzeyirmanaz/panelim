/**
 * Tutarlılık denetimi: `npm run check`
 * 1) Menüdeki her yolun bir sayfası var   2) Her sayfa menüde ya da bilinen ek sayfalardan
 * 3) Rol adı yalnızca izinli dosyalarda geçiyor   4) Kaynak arayüzü ↔ sunucu kaydı eşleşiyor
 */
import { existsSync, readdirSync, readFileSync, statSync } from 'node:fs'
import { join } from 'node:path'
import { NAV, type NavItem } from '../src/lib/nav'

const root = join(__dirname, '..', 'src')
const errors: string[] = []

const flat = (items: NavItem[]): NavItem[] => items.flatMap((i) => (i.children ? flat(i.children) : [i]))
const walk = (dir: string): string[] =>
  readdirSync(dir).flatMap((f) => {
    const p = join(dir, f)
    return statSync(p).isDirectory() ? walk(p) : [p]
  })

// 1) Menü → sayfa
for (const item of flat(NAV)) {
  if (!item.href) continue
  const dir = join(root, 'app', item.href.replace(/^\//, ''))
  const dynamicParent = existsSync(join(dir, '..', '[type]', 'page.tsx')) || existsSync(join(dir, '..', '[masa]', 'page.tsx'))
  if (!existsSync(join(dir, 'page.tsx')) && !dynamicParent) errors.push(`Menü yolunun sayfası yok: ${item.href}`)
}

// 2) Her panel sayfası bir yetki koruması çağırıyor
for (const f of walk(join(root, 'app', 'panel')).filter((p) => p.endsWith('page.tsx'))) {
  const src = readFileSync(f, 'utf8')
  if (!/requirePage\(/.test(src) && !/^\s*redirect\(/m.test(src)) errors.push(`Sayfada yetki koruması yok: ${f.replace(root, 'src')}`)
}

// 3) Rol adı dağınık yazılmamalı
const ALLOWED = ['lib/permissions.ts', 'lib/constants.ts', 'lib/resource-ui.tsx', 'lib/auth.ts', 'app/api/users', 'app/api/orders/[id]/route.ts', 'app/panel/yetkiler', 'components/panel/resource-page.tsx']
for (const f of walk(root).filter((p) => /\.tsx?$/.test(p))) {
  const rel = f.replace(root + '/', '')
  if (ALLOWED.some((a) => rel.startsWith(a))) continue
  if (/['"](ADMIN|CASHIER|KITCHEN)['"]/.test(readFileSync(f, 'utf8'))) errors.push(`Rol adı doğrudan yazılmış (permissions.ts kullanın): ${rel}`)
}

// 4) API korumaları: her route.ts bir guard çağırmalı (giriş/çıkış hariç)
const PUBLIC = ['api/auth/login', 'api/auth/logout']
for (const f of walk(join(root, 'app', 'api')).filter((p) => p.endsWith('route.ts'))) {
  const rel = f.replace(root + '/app/', '')
  if (PUBLIC.some((p) => rel.startsWith(p))) continue
  if (!/require(Can|User|Role)\(/.test(readFileSync(f, 'utf8'))) errors.push(`API rotasında koruma yok: ${rel}`)
}

if (errors.length) {
  console.error('✗ Denetim başarısız:\n  - ' + errors.join('\n  - '))
  process.exit(1)
}
console.log('✓ Denetim temiz.')
