# Sistem Kuralları

Amaç: bir şeyi **tek yerde** tanımlamak, her yerde o tanımın kullanılması. Yeni bir özellik eklemek
"şablonu kopyala, alanları doldur" kadar kolay olmalı; bir kural değişince tek dosya değişmeli.

## 1. Altın kurallar

1. **Tek doğruluk kaynağı.** Aynı bilgi iki yerde yazılmaz (alan listesi, rol yetkisi, etiket, rota).
2. **Sunucu karar verir.** Yetki, fiyat, toplam, durum geçişi sunucuda hesaplanır; arayüz sadece gösterir.
3. **Para = kuruş (Int).** Tarih = UTC saklanır, yerel gösterilir. Gün sınırı = `TZ` ayarı.
4. **Sade veri.** Her tablo tek iş yapar; hesaplanabilen değer saklanmaz (istisna: sipariş toplamı, rapor hızı için).
5. **Sihir yok.** Her dosya adından ne yaptığı anlaşılır; bir dosya tek sorumluluk taşır.
6. **Kırılan şey yüksek sesle kırılır.** Hata mesajı Türkçe, ne olduğunu ve ne yapılacağını söyler.

## 2. Klasör düzeni (hedef)

```
src/
  modules/<kaynak>/         Her kaynak için TEK klasör (ör. products, tables, customers)
    schema.ts               Zod şeması (sunucu doğrulaması + tip)
    ui.tsx                  Alanlar, sütunlar, etiketler (arayüz sözleşmesi)
    access.ts               Kim okur / kim yazar
  lib/
    permissions.ts          TÜM rol kuralları tek tabloda (API, menü, sayfa, Yetkiler ekranı bunu okur)
    orders.ts               Sipariş iş kuralları (tek yer)
    brand.ts                Marka / işletme adı
    format.ts constants.ts  Biçimlendirme ve sabitler
  app/
    api/                    İnce rota dosyaları: doğrula → servisi çağır → döndür
    panel/                  İnce sayfa dosyaları: yetkiyi kontrol et → bileşeni göster
  components/               Yalnızca görünüm; iş kuralı içermez
prisma/schema.prisma        Veri modeli
prisma/seed.ts              Demo verisi
scripts/                    check.ts (tutarlılık denetimi), new-resource.ts (iskelet üretici)
```

## 3. Yeni kaynak eklemek (5 adım, ~10 dakika)

1. `prisma/schema.prisma` → modeli ekle.
2. `npm run new:resource <ad>` → `src/modules/<ad>/` iskeletini üretir.
3. `schema.ts` ve `ui.tsx` içindeki alanları doldur.
4. `lib/permissions.ts` → kimin okuyup yazacağını belirt.
5. `npm run check` → eksik/çelişkili her şeyi listeler.

Sayfa, API rotası, menü satırı ve Yetkiler tablosu **otomatik** bu tanımlardan çıkar.

## 4. İsimlendirme

- Dosya/klasör: `kucuk-harf-tire`. Bileşen: `BuyukHarf`. Rota yolları Türkçe, kod İngilizce.
- Veritabanı alanları İngilizce, arayüz metinleri Türkçe. Metinler `lib/labels.ts` (ileride) veya modülün `ui.tsx`'inde.
- Bir API yanıtı: başarıda ham JSON, hatada `{ "error": "mesaj" }`. Durum kodları: 400 geçersiz, 401 oturum yok, 403 yetki yok, 404 yok, 409 çakışma.

## 5. Roller ve yetki

Tek tablo (`permissions.ts`):

| Yetenek | Yönetici | Kasiyer | Mutfak |
|---|---|---|---|
| adisyon.yaz | ✓ | ✓ | – |
| mutfak.durum | ✓ | ✓ | ✓ |
| tanim.oku | ✓ | ✓ | – |
| tanim.yaz | ✓ | – | – |
| rapor.oku | ✓ | – | – |
| kullanici.yonet | ✓ | – | – |

API rotası `requireCan('order.write')`, menü `cap: 'reports.read'`, sayfa `requirePage('defs.read')` der (`src/lib/permissions.ts`).
Rol adı hiçbir yerde doğrudan yazılmaz.

## 6. Veri kuralları

- Silme yerine pasifleştirme (kullanıcı, ürün); sipariş asla silinmez, `CANCELLED` olur.
- Geçmiş siparişte ad ve fiyat **anlık görüntü** olarak kalır (ürün değişse rapor değişmez).
- Seed yalnızca boş veritabanında çalışır; tekrar çalıştırmak zararsızdır.
- Yedek: SQLite dosyası günlük kopyalanır (`DATABASE_URL` yolundaki dosya).

## 7. Kalite kapıları

`npm run check` şunları denetler (geçmezse birleştirilmez):

1. `tsc --noEmit` temiz.
2. Her menü yolunun bir sayfası, her sayfanın bir menü/yetki kaydı var.
3. Her `modules/<ad>` için schema + ui + access var; UI alanları şema alanlarıyla birebir örtüşüyor.
4. Rol adı `permissions.ts` dışında geçmiyor.
5. Sipariş servisi testleri: oluştur, ekle, öde, taşı/birleştir, iptal.

## 8. Çoğaltma (başka restoran / şube)

- `BRAND` + `.env` + boş veritabanı = yeni müşteri. Kod aynı kalır.
- Müşteriye özel ihtiyaç kodu değil **ayar** olur (`settings` tablosu); ayarla çözülemiyorsa modül olarak eklenir.
- Çok şube: her şube kendi veritabanıyla ayrı çalışır (basit); merkezi raporlama gerekirse ayrı bir birleştirme servisi yazılır.

## 9. Geliştirme düzeni

- Aynı klasörde **tek yazar**: aynı anda iki oturum/araç düzenlemesin.
- Küçük adımlarla ilerle; her adımdan sonra `npm run check`.
- Büyük değişiklik öncesi klasörün yedeği (zip) alınır.
