# Sofra — Restoran Paneli

Adisyon, masa yönetimi, mutfak ekranı, tanımlar ve raporlama için Next.js tabanlı restoran paneli.

## Kurulum

```bash
cp .env.example .env      # DATABASE_URL, TZ, COOKIE_SECURE
npm install
npm run db:push           # SQLite şemasını oluşturur
npm run db:seed           # demo verisi (isteğe bağlı)
npm run dev               # http://localhost:3000
```

Demo giriş (seed sonrası): `admin` / `kasiyer` / `mutfak` — şifre `demo1234`
(`SEED_PASSWORD` ile değiştirilebilir). **Canlıya almadan önce şifreleri değiştirin.**

HTTP üzerinden (HTTPS olmadan) üretim modunda çalıştırırsanız `.env` içinde `COOKIE_SECURE="false"` yapın.

## Sayfalar

Menü yapısı ve rotalar özgün panelle aynıdır (kod baştan yazılmıştır).

| Yol | Açıklama | Rol |
|---|---|---|
| `/panel` | Ana Sayfa özeti | Personel+ |
| `/panel/masalar` | Masa / Bölgeler: bölge sekmeleri, grup/liste görünümü, renk kodu, ⋮ menüsü (öde, masa değiştir/birleştir, iptal) | Personel+ |
| `/panel/masalar/duzenle` | Masa ve bölge tanımları | Personel görür, Yönetici düzenler |
| `/panel/siparis/{masa}` | Sipariş ekranı (`paket`, `gelal` de olabilir) | Personel+ |
| `/panel/siparisler` · `/panel/mutfak` | Sipariş listesi · Mutfak ekranı (canlı) | Personel+ · Mutfak |
| `/panel/urun-eslestirme` · `/panel/entegrasyon` | Harici ürün kodu eşleştirme · planlanan entegrasyonlar | Personel+ |
| `/panel/dijital-menu` · `/menu` | QR menü paylaşımı · herkese açık menü (`?masa=` ile masaya özel) | Personel+ · Herkes |
| `/panel/menu` | Ürünler ve Kategoriler | Personel görür, Yönetici düzenler |
| `/panel/birimler` `ozellikler` `kdv-oranlari` `indirimler` `mutfak-gruplari` | Tanımlamalar | Personel görür, Yönetici düzenler |
| `/panel/musteriler` `odenmezler` `siparis-tanimlari` `gider-masraf` `zayi` | Müşteri, ödenmez, hazır sipariş notları, gider, zayi | Personel+ |
| `/panel/kullanicilar` · `/panel/yetkiler` | Kullanıcı yönetimi · rol yetki tablosu (salt okunur) | Yönetici |
| `/panel/raporlar/*` | urun-satis, gun-sonu, vardiya, istatistik, fire, maliyet, sihirbaz | Yönetici |
| `/panel/uygulama-magazasi` · `/panel/ayarlar` · `/panel/hesabim` | Modüller · masa QR kodları · profil/şifre | Personel+ |

### Özgün sürümden bilinçli farklar
- Pazarlama sitesi, fiyat sayfası, logo ve firma iletişim bilgileri yoktur (`/` doğrudan panele yönlenir). Marka adı "Sofra" yer tutucudur.
- "Tavsiye Et ve Kazan" sayfası yoktur (satıcıya özgü kampanya).
- Entegrasyon ve Uygulama Mağazası sayfaları sahte "Bağlan" düğmesi yerine "Yakında" durumunu gösterir.
- Yetkiler sayfası gerçek kuralları gösterir (düzenlenemez); özgün sürümde kaydedilmeyen bir formdu.
- "Sipariş" tanımları artık gerçek bir tablodur (hazır notlar); özgün sürümde indirim tablosunu kullanıyordu.
- Tüm tutarlar kuruş (Int); sipariş no, kişi sayısı, harici ürün kodu eklendi.

## Mimari

```
prisma/schema.prisma        Veri modeli (tüm tutarlar kuruş, Int)
src/lib/
  auth.ts                   Çerez oturumu (token sha256 özetiyle saklanır), rol korumaları
  http.ts                   handle() — tutarlı hata yanıtları (Zod / Prisma / HttpError)
  orders.ts                 Sipariş iş kuralları (tek yer): oluştur, ekle, öde, taşı/birleştir
  resources.ts              Basit tanımlar için Zod şema + yetki kayıt defteri
  resource-ui.tsx           Aynı tanımların arayüz sözleşmesi (alanlar, sütunlar)
  events.ts                 Süreç içi olay yayıncısı → /api/events (SSE) → canlı ekranlar
src/app/api/                REST uçları (/api/r/[resource] tüm basit tanımları karşılar)
src/components/panel/       Ekranlar (kabuk, salon, adisyon, mutfak, raporlar, genel tanım sayfası)
```

Yeni bir basit tanım eklemek için: `schema.prisma`'ya model → `resources.ts`'ye bir giriş →
`resource-ui.tsx`'e bir giriş → `nav.ts`'ye menü satırı. Ayrıca sayfa yazmanız gerekmez.

### Notlar / sınırlar
- Canlı güncellemeler (SSE) tek Node süreci içindir. Birden fazla süreç/sunucu çalıştıracaksanız
  `src/lib/events.ts` içindeki yayıncıyı Redis pub/sub gibi bir köprüyle değiştirin.
- Veritabanı SQLite'tır; PostgreSQL'e geçmek için `schema.prisma` içindeki `provider`/`url` değişir.
- Giriş denemesi sınırlaması süreç içidir (yeniden başlatınca sıfırlanır).
